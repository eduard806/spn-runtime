"""SPN STOICA AI — M1-C01 reference calculation engine V1.25 (V1.24 → V1.25: am.367, titular 09.09.2026 «B, rotunjim in sus» — ANCPI ROTUNJIT IN SUS la leu pe dosarele noi (R-ANCPI-ROTUNJIRE-SUS, supersedeaza am.172/Î14c); comutator ANCPI_ROUNDING floor numai pentru etaloanele inghetate, R-71. V1.23 → V1.24: T36b — `module_version` din ENGINE_RESULT urmează versiunea motorului (era «1.20» de la V1.20 încoace, număr fals în ieșire; audit T36). V1.22 → V1.23: am.282 — R-IMPOZIT-MIXT-COTE: impozitul vânzătorului PF se calculează PE COTE când imobilul a fost dobândit prin mai multe acte la date diferite — `seller_tax_shares` [{cota, tax_percent}], cotele însumate = 1, fiecare cotă cu 1% sau 3% din partea ei de preț, impozitul = suma pe cote; fail-closed INVALID_TAX_SHARES / TAX_SHARES_CONFLICT. V1.21 → V1.22: am.174 — R-REDUCERE-ONORARIU: procentul ajustării poate fi NEGATIV (reducere), pe TOATE procedurile: sale/mortgage/antecontract/opinion/radiere; fail-closed la reducere ≥100%. V1.20 → V1.21: am.172, rotunjirea ANCPI prin trunchiere; lanțul vechi: V1.13 (lanț: V1.9 → V1.11 extrasele de informare la vânzare → V1.12 taxele suplimentare → V1.13 cantități pe taxele suplimentare; V1.10 nu există).

Reference implementation for ChatBuild transfer. It is deterministic and offline:
the runtime must provide the effective FX rate and its source metadata. This file
never fetches external data, never sends an offer, and never propagates rules.

Canonical scope: MODULE M1-C01 V1.13 only. CORE is not modified.
"""
from __future__ import annotations

# am.431 (T59a): scriere LF + stdout UTF-8 + legaturi fara privilegiu, pe orice mediu (R-71: pe Linux, no-op).
import os as _os_am431, sys as _sys_am431  # noqa: E402
_sys_am431.path.insert(0, _os_am431.path.abspath(_os_am431.path.join(_os_am431.path.dirname(_os_am431.path.abspath(__file__)), '..', '..')))
try:
    import SPN_PORTABIL_V1 as _portabil_am431  # noqa: E402,F401
except ImportError:  # runtime-ul livrat singur sau COPIAT in afara bancului (skill spn-taxe-m1c01, fixturile bateriei)
    # Fara modul, se face aici minimul care altfel opreste rularea: fluxurile pe UTF-8. Masurat in T59a —
    # copia runtime-ului din fixtura T56Z cadea cu «'charmap' codec can't encode 'ș'», deci orchestratorul
    # respingea livrarea desi motorul calculase corect. Pe Linux e no-op (fluxurile sunt deja UTF-8).
    _portabil_am431 = None
    for _flux_am431 in (_sys_am431.stdout, _sys_am431.stderr):
        try:
            if _flux_am431 is not None and (getattr(_flux_am431, 'encoding', '') or '').lower().replace('-', '') != 'utf8':
                _flux_am431.reconfigure(encoding='utf-8', errors='backslashreplace')
        except Exception:
            pass

from dataclasses import dataclass, asdict
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP, InvalidOperation
from typing import Any, Dict, Iterable, List, Literal, Mapping, Optional

D = Decimal
ENGINE_VERSION = "1.25"  # am.367: ANCPI rotunjit in sus
ANCPI_ROUNDING = {"mode": "ceil"}  # am.367: `floor` numai la cerere explicita (etaloane inghetate), prin orchestrator
PersonType = Literal["PF", "PJ"]
VAT = D("0.21")


class FailClosedError(ValueError):
    """Materially incomplete, contradictory or unsupported input."""

    def __init__(self, code: str, message: str, missing_fields: Optional[List[str]] = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.missing_fields = missing_fields or []

    def as_result(self) -> Dict[str, Any]:
        return {
            "status": "RESPINS_FAIL_CLOSED",
            "error_code": self.code,
            "message": self.message,
            "missing_fields": self.missing_fields,
            "automatic_propagation": False,
            "human_approval_required": True,
        }


def dec(value: Any, field: str = "value") -> Decimal:
    try:
        result = D(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FailClosedError("INVALID_NUMBER", f"Câmp numeric invalid: {field}.") from exc
    if not result.is_finite() or result < 0:
        raise FailClosedError("INVALID_NUMBER", f"Câmp numeric negativ sau ne-finit: {field}.")
    return result



def parse_share(value: Any) -> Decimal:
    """am.282 (V1.23): cota unei parti din imobil — «1/2», «50%», «0.5», «0,5» → fractie zecimala exacta."""
    if isinstance(value, Decimal):
        return value
    if isinstance(value, (int, float)):
        return D(str(value))
    txt = str(value or "").strip().replace(" ", "")
    if not txt:
        raise ValueError("cota lipsa")
    if "/" in txt:
        a, b = txt.split("/", 1)
        return D(a.replace(",", ".")) / D(b.replace(",", "."))
    if txt.endswith("%"):
        return D(txt[:-1].replace(",", ".")) / D("100")
    return D(txt.replace(",", "."))

def ceil_leu(value: Decimal) -> Decimal:
    return value.quantize(D("1"), rounding=ROUND_CEILING)


def floor_leu(value: Decimal) -> Decimal:
    """PATCH V1.21 (am.172, T25, 31.08.2026 — TIC-M1C01-ROTUNJIRE-ANCPI, ratificat Î14c):
    tariful ANCPI se TRUNCHIAZĂ la leu (763,35 → 763), litera actelor biroului (etalonul D12,
    încheierea 3811/26.11.2025). Onorariile rămân pe ceil_leu (grila neschimbată)."""
    return value.quantize(D("1"), rounding=ROUND_FLOOR)


def money2(value: Decimal) -> Decimal:
    return value.quantize(D("0.01"), rounding=ROUND_HALF_UP)


def count(value: Any, field: str, default: int) -> int:
    if value is None:
        return default
    try:
        d = D(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FailClosedError("INVALID_QUANTITY", f"Cantitate invalidă: {field}.") from exc
    if not d.is_finite() or d < 0 or d != d.to_integral_value():
        raise FailClosedError("INVALID_QUANTITY", f"Cantitatea trebuie să fie un număr întreg nenegativ: {field}.")
    return int(d)


def signed_pct(value: Any, field: str) -> Decimal:
    """PATCH V1.22 (am.174, T25, 31.08.2026 — R-REDUCERE-ONORARIU): procentul ajustării onorariului
    poate fi si NEGATIV (reducere: «scade onorariul cu 30%» → percent -30), pe acelasi principiu cu
    majorarea. Fail-closed: reducerea trebuie sa fie SUB 100% (pct > -100) — onorariul nu poate
    ajunge la zero sau negativ fara o decizie expresa separata a titularului."""
    try:
        result = D(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FailClosedError("INVALID_NUMBER", f"Câmp numeric invalid: {field}.") from exc
    if not result.is_finite():
        raise FailClosedError("INVALID_NUMBER", f"Câmp numeric ne-finit: {field}.")
    if result <= D("-100"):
        raise FailClosedError("INVALID_HONORARIUM_ADJUSTMENT",
                              f"Reducerea onorariului trebuie să fie sub 100% ({field}).")
    return result


def adjusted_honorarium(base: Decimal, percent: Any, field: str) -> tuple[Decimal, Decimal, Decimal]:
    pct = signed_pct(percent if percent is not None else 0, field)  # am.174: accepta si reducere (negativ)
    final = ceil_leu(base * (D("1") + pct / D("100"))) if pct else base
    return pct, final - base, final


def person_verification(person_type: PersonType) -> Decimal:
    if person_type == "PF":
        return D("18.15")  # 15 + TVA 21%
    if person_type == "PJ":
        return D("30.00")  # RECOM, fără TVA
    raise FailClosedError("UNKNOWN_PERSON_TYPE", "Tipul persoanei trebuie să fie PF sau PJ.")


def sale_honorarium(value_lei: Decimal) -> Decimal:
    v = dec(value_lei, "sale_value_lei")
    if v <= D("20000"):
        return ceil_leu(max(D("0.022") * v, D("230")))
    if v <= D("35000"):
        return ceil_leu(D("440") + D("0.019") * (v - D("20001")))
    if v <= D("65000"):
        return ceil_leu(D("725") + D("0.016") * (v - D("35001")))
    if v <= D("100000"):
        return ceil_leu(D("1205") + D("0.015") * (v - D("65001")))
    if v <= D("200000"):
        return ceil_leu(D("1705") + D("0.011") * (v - D("100001")))
    if v <= D("600000"):
        return ceil_leu(D("2805") + D("0.009") * (v - D("200001")))
    if v == D("600001"):
        raise FailClosedError(
            "OPEN_THRESHOLD_600001",
            "Valoarea exactă 600.001 lei rămâne fail-closed până la decizie expresă a titularului.",
        )
    return ceil_leu(D("6405") + D("0.006") * (v - D("600001")))


def mortgage_honorarium(credit_lei: Decimal) -> Decimal:
    v = dec(credit_lei, "credit_lei")
    if v <= D("50000"):
        return ceil_leu(max(D("0.0085") * v, D("150")))
    if v <= D("100000"):
        return ceil_leu(D("425") + D("0.005") * (v - D("50000")))
    if v <= D("200000"):
        return ceil_leu(D("750") + D("0.0046") * (v - D("100001")))
    if v <= D("500000"):
        return ceil_leu(D("1209") + D("0.0019") * (v - D("200001")))
    if v == D("500001"):
        raise FailClosedError(
            "OPEN_THRESHOLD_500001",
            "Valoarea exactă 500.001 lei rămâne fail-closed până la decizie expresă a titularului.",
        )
    return ceil_leu(D("1778") + D("0.0010") * (v - D("500001")))


def opinion_calculation(
    information_extract_quantity: int = 1,
    notation_quantity: int = 0,
    honorarium_increase_percent: Any = 0,
) -> Dict[str, Decimal]:
    qty = count(information_extract_quantity, "opinion_information_extracts", 1)
    extract_total = D("20.00") * qty
    notation_qty = count(notation_quantity, "opinion_notation_count", 0)
    notation_unit = D("75.00")
    notation_total = money2(notation_unit * notation_qty)
    # am.174 (V1.22): ajustarea onorariului (majorare/reducere) si pe opinie
    pct, adj_amount, honorarium = adjusted_honorarium(D("400.00"), honorarium_increase_percent, "opinion_honorarium_adjustment")
    vat = money2(honorarium * VAT)
    return {
        "honorarium_net": honorarium,
        "honorarium_increase_percent": pct,
        "honorarium_adjustment_amount": adj_amount,
        "vat": vat,
        "information_extract_quantity": qty,
        "information_extract_unit": D("20.00"),
        "information_extract": money2(extract_total),
        "notation_quantity": notation_qty,
        "notation_unit": notation_unit,
        "land_book_notation": notation_total,
        "total": money2(honorarium + vat + extract_total + notation_total),
    }

def radiere_calculation(
    information_extract_quantity: int = 1,
    notation_quantity: int = 0,
    honorarium_increase_percent: Any = 0,
) -> Dict[str, Decimal]:
    """V1.14 (SPEC_TAXA_RADIERE_V1, 15.08.2026): Declaratie de Radiere - paritate 1:1 cu opinia,
    onorariu 800 net + TVA, plus taxa ANCPI de radiere, fixa, 75 lei (fara TVA), cantitate 1."""
    qty = count(information_extract_quantity, "radiere_information_extracts", 1)
    extract_total = D("20.00") * qty
    notation_qty = count(notation_quantity, "radiere_notation_count", 0)
    notation_unit = D("75.00")
    notation_total = money2(notation_unit * notation_qty)
    ancpi_radiere = D("75.00")
    # am.174 (V1.22): ajustarea onorariului (majorare/reducere) si pe radiere
    pct, adj_amount, honorarium = adjusted_honorarium(D("800.00"), honorarium_increase_percent, "radiere_honorarium_adjustment")
    vat = money2(honorarium * VAT)
    return {
        "honorarium_net": honorarium,
        "honorarium_increase_percent": pct,
        "honorarium_adjustment_amount": adj_amount,
        "vat": vat,
        "information_extract_quantity": qty,
        "information_extract_unit": D("20.00"),
        "information_extract": money2(extract_total),
        "notation_quantity": notation_qty,
        "notation_unit": notation_unit,
        "land_book_notation": notation_total,
        "ancpi_radiere_fixed": ancpi_radiere,
        "total": money2(honorarium + vat + extract_total + notation_total + ancpi_radiere),
    }

def antecontract_calculation(
    advance_lei: Decimal,
    buyer_type: PersonType,
    seller_type: PersonType,
    *,
    buyer_verification_quantity: int = 1,
    seller_information_extract_quantity: int = 1,
    seller_verification_quantity: int = 1,
    notation_quantity: int = 1,
    honorarium_increase_percent: Any = 0,
) -> Dict[str, Any]:
    advance = dec(advance_lei, "advance_lei")
    base_honorarium = ceil_leu(max(D("0.01") * advance, D("500")))
    # am.174 (V1.22): ajustarea onorariului (majorare/reducere) si pe antecontract — pe onorariul din grila, inainte de TVA
    pct, adj_amount, honorarium = adjusted_honorarium(base_honorarium, honorarium_increase_percent, "antecontract_honorarium_adjustment")
    archive = D("45.00")
    vat = money2((honorarium + archive) * VAT)
    buyer_qty = count(buyer_verification_quantity, "antecontract_buyer_verifications", 1)
    seller_info_qty = count(seller_information_extract_quantity, "antecontract_seller_information_extracts", 1)
    seller_ver_qty = count(seller_verification_quantity, "antecontract_seller_verifications", 1)
    notation_qty = count(notation_quantity, "antecontract_notation_count", 1)
    buyer_verification_unit = person_verification(buyer_type)
    seller_verification_unit = person_verification(seller_type)
    buyer_verification = money2(buyer_verification_unit * buyer_qty)
    seller_information_extract = money2(D("20.00") * seller_info_qty)
    seller_verification = money2(seller_verification_unit * seller_ver_qty)
    notation_unit = D("75.00")
    notation_total = money2(notation_unit * notation_qty)
    buyer_without = honorarium + archive + vat + buyer_verification
    return {
        "advance_lei": money2(advance),
        "honorarium_net": honorarium,
        "honorarium_increase_percent": pct,
        "honorarium_adjustment_amount": adj_amount,
        "archive": archive,
        "vat": vat,
        "buyer_verification_quantity": buyer_qty,
        "buyer_verification_unit": buyer_verification_unit,
        "buyer_verification": buyer_verification,
        "buyer_without_notation": money2(buyer_without),
        "notation_quantity": notation_qty,
        "notation_unit": notation_unit,
        "optional_notation": notation_total,
        "buyer_with_notation": money2(buyer_without + notation_total),
        "seller_information_extract_quantity": seller_info_qty,
        "seller_information_extract_unit": D("20.00"),
        "seller_information_extract": seller_information_extract,
        "seller_verification_quantity": seller_ver_qty,
        "seller_verification_unit": seller_verification_unit,
        "seller_verification": seller_verification,
        "seller_total": money2(seller_information_extract + seller_verification),
    }

def sale_calculation(
    price_lei: Decimal,
    buyer_type: PersonType,
    seller_type: PersonType,
    seller_tax_percent: Optional[int] = None,
    antecontract_honorarium_deduction: Decimal = D("0"),
    include_final_verifications: bool = True,
    *,
    seller_tax_shares: Optional[List[Dict[str, Any]]] = None,
    honorarium_increase_percent: Any = 0,
    usufruct_uplift: bool = False,
    buyer_verification_quantity: Optional[int] = None,
    seller_authentication_extract_quantity: int = 1,
    seller_information_extract_quantity: int = 0,
    seller_verification_quantity: Optional[int] = None,
    land_book_notation_quantity: int = 0,
) -> Dict[str, Any]:
    price = dec(price_lei, "price_lei")
    deduction = dec(antecontract_honorarium_deduction, "antecontract_honorarium_deduction")
    # REGULA 60 (18.08.2026): la M3/uzufruct, BAZA ONORARIULUI = valoarea +20%; taxele (ANCPI, impozit) raman pe pret.
    honorarium_base_value = money2(price * D("1.20")) if usufruct_uplift else price
    gross_honorarium = sale_honorarium(honorarium_base_value)
    if deduction > gross_honorarium:
        raise FailClosedError("DEDUCTION_EXCEEDS_FEE", "Deducerea antecontractului depășește onorariul vânzării.")
    base_after_deduction = gross_honorarium - deduction
    pct, increase_amount, honorarium = adjusted_honorarium(base_after_deduction, honorarium_increase_percent, "sale_honorarium_increase_percent")
    archive = D("45.00")
    vat = money2((honorarium + archive) * VAT)
    ancpi_rate = D("0.0015") if buyer_type == "PF" else D("0.005")
    # am.172 (V1.21): ANCPI = TRUNCHIERE la leu (Î14c ratificat 31.08.2026) — SUPERSEDAT de decizia titularului
    # 09.09.2026 «B, rotunjim in sus» (am.367, V1.25, R-ANCPI-ROTUNJIRE-SUS): ANCPI = ROTUNJIRE IN SUS la leu
    # (631,97 -> 632; 763,35 -> 764) pe dosarele NOI. Actele deja semnate si etaloanele inghetate (1677 = 479,
    # ETALON-VASILE = 1.374) raman pe trunchiere — nu se recalculeaza (R-71); puntea V8 poate cere explicit
    # `ancpi_rounding = floor` pe o sesiune pinuita ca etalon.
    ancpi = floor_leu(price * ancpi_rate) if ANCPI_ROUNDING.get("mode") == "floor" else ceil_leu(price * ancpi_rate)
    default_buyer_qty = 1 if include_final_verifications else 0
    buyer_qty = count(buyer_verification_quantity, "sale_buyer_verifications", default_buyer_qty)
    buyer_verification_unit = person_verification(buyer_type)
    buyer_verification = money2(buyer_verification_unit * buyer_qty)
    notation_qty = count(land_book_notation_quantity, "sale_notation_count", 0)
    notation_unit = D("75.00")
    land_book_notation = money2(notation_unit * notation_qty)
    buyer_total = honorarium + archive + vat + ancpi + buyer_verification + land_book_notation

    default_seller_qty = 1 if include_final_verifications else 0
    seller_ver_qty = count(seller_verification_quantity, "sale_seller_verifications", default_seller_qty)
    auth_qty = count(seller_authentication_extract_quantity, "sale_seller_authentication_extracts", 1)
    info_qty = count(seller_information_extract_quantity, "sale_seller_information_extracts", 0)
    seller_verification_unit = person_verification(seller_type)
    seller_verification = money2(seller_verification_unit * seller_ver_qty)
    authentication_extract = money2(D("40.00") * auth_qty)
    information_extract = money2(D("20.00") * info_qty)
    seller_base = authentication_extract + information_extract + seller_verification
    seller: Dict[str, Decimal] = {
        "authentication_extract_quantity": auth_qty,
        "authentication_extract_unit": D("40.00"),
        "authentication_extract": authentication_extract,
        "information_extract_quantity": info_qty,
        "information_extract_unit": D("20.00"),
        "information_extract": information_extract,
        "seller_verification_quantity": seller_ver_qty,
        "seller_verification_unit": seller_verification_unit,
        "seller_verification": seller_verification,
    }
    if seller_type == "PJ":
        seller["total"] = money2(seller_base)
    elif seller_tax_shares:
        # am.282 (V1.23, T36, titular 03.09.2026, R-IMPOZIT-MIXT-COTE): imobilul dobandit prin mai multe
        # acte la date diferite (vanzare, partaj, succesiune etc. — tipul actului e irelevant) → impozitul
        # se calculeaza PE COTA, nu pe imobil: cota cu vechime > 3 ani → 1% din partea ei de pret, cota sub
        # 3 ani → 3% din partea ei; impozitul = suma pe cote. Cota se rotunjeste ca un transfer distinct
        # (ceil la leu pe fiecare cota), iar suma cotelor trebuie sa fie exact intregul (fail-closed).
        if seller_tax_percent is not None:
            raise FailClosedError("TAX_SHARES_CONFLICT", "Impozitul pe cote (seller_tax_shares) nu se combină cu o cotă unică (seller_tax_percent).")
        shares_out: List[Dict[str, Any]] = []
        total_share = D("0"); tax = D("0")
        for i, sh in enumerate(seller_tax_shares):
            if not isinstance(sh, Mapping):
                raise FailClosedError("INVALID_TAX_SHARES", f"Cota {i + 1} a impozitului nu este un obiect {{cota, tax_percent}}.")
            try:
                cota = parse_share(sh.get("cota"))
            except Exception as exc:
                raise FailClosedError("INVALID_TAX_SHARES", f"Cota {i + 1} a impozitului este invalidă: {sh.get('cota')!r}.") from exc
            if cota <= 0 or cota > 1:
                raise FailClosedError("INVALID_TAX_SHARES", f"Cota {i + 1} a impozitului trebuie să fie în (0, 1]: {sh.get('cota')!r}.")
            try:
                pct = int(sh.get("tax_percent"))
            except (TypeError, ValueError) as exc:
                raise FailClosedError("INVALID_TAX_VARIANT", f"Cota {i + 1}: procentul impozitului pe cotă poate fi numai 1 sau 3.") from exc
            if pct not in (1, 3):
                raise FailClosedError("INVALID_TAX_VARIANT", f"Cota {i + 1}: procentul impozitului pe cotă poate fi numai 1 sau 3.")
            base_i = price * cota
            tax_i = ceil_leu(base_i * D(pct) / D("100"))
            shares_out.append({"cota": str(sh.get("cota")), "cota_fraction": cota, "tax_percent": D(pct),
                               "base_lei": money2(base_i), "tax": tax_i,
                               "label": str(sh.get("label") or sh.get("act") or "")})
            total_share += cota; tax += tax_i
        if abs(total_share - D("1")) > D("0.000001"):
            raise FailClosedError("INVALID_TAX_SHARES", f"Cotele impozitului nu însumează întregul (suma = {total_share}).")
        seller["tax_mode"] = "MIXT"
        seller["tax_percent"] = "MIXT"
        seller["tax_percent_label"] = " + ".join(f"{int(x['tax_percent'])}% pe {x['cota']}" for x in shares_out)
        seller["tax_shares"] = shares_out
        seller["tax"] = money2(tax)
        seller["total"] = money2(seller_base + tax)
    elif seller_tax_percent in (1, 3):
        tax = ceil_leu(price * D(seller_tax_percent) / D("100"))
        seller["tax_percent"] = D(seller_tax_percent)
        seller["tax"] = tax
        seller["total"] = money2(seller_base + tax)
    elif seller_tax_percent is None:
        tax1 = ceil_leu(price * D("0.01"))
        tax3 = ceil_leu(price * D("0.03"))
        seller["tax_1"] = tax1
        seller["tax_3"] = tax3
        seller["total_1"] = money2(seller_base + tax1)
        seller["total_3"] = money2(seller_base + tax3)
    else:
        raise FailClosedError("INVALID_TAX_VARIANT", "Impozitul vânzătorului PF poate fi numai 1%, 3% sau nespecificat.")

    return {
        "price_lei": money2(price),
        "gross_honorarium_before_deduction": gross_honorarium,
        "antecontract_honorarium_deduction": deduction,
        "honorarium_before_increase": base_after_deduction,
        "honorarium_increase_percent": pct,
        "honorarium_increase_amount": increase_amount,
        "honorarium_net": honorarium,
        "usufruct_uplift_applied": usufruct_uplift,
        "honorarium_base_value": honorarium_base_value,
        "archive": archive,
        "vat": vat,
        "ancpi": ancpi,
        "buyer_verification_quantity": buyer_qty,
        "buyer_verification_unit": buyer_verification_unit,
        "buyer_verification": buyer_verification,
        "notation_quantity": notation_qty,
        "notation_unit": notation_unit,
        "land_book_notation": land_book_notation,
        "buyer_total": money2(buyer_total),
        "seller": seller,
    }

def mortgage_calculation(
    credit_lei: Decimal,
    buyer_type: PersonType,
    *,
    standalone: bool = False,
    include_buyer_verification: bool = False,
    honorarium_increase_percent: Any = 0,
    bank_proxy_check_quantity: int = 2,
    legalized_copy_quantity: int = 6,
    buyer_verification_quantity: Optional[int] = None,
    authentication_extract_quantity: Optional[int] = None,
    additional_collateral_property_quantity: int = 0,
    land_book_notation_quantity: int = 0,
) -> Dict[str, Any]:
    credit = dec(credit_lei, "credit_lei")
    base_honorarium = mortgage_honorarium(credit)
    pct, increase_amount, honorarium = adjusted_honorarium(base_honorarium, honorarium_increase_percent, "mortgage_honorarium_increase_percent")
    archive = D("45.00")
    vat = money2((honorarium + archive) * VAT)
    ocpi_base = ceil_leu(D("100") + D("0.001") * credit)
    additional_collateral_qty = count(
        additional_collateral_property_quantity,
        "mortgage_additional_collateral_properties",
        0,
    )
    additional_collateral_unit = D("100.00")
    additional_collateral_fee = money2(additional_collateral_unit * additional_collateral_qty)
    ocpi = money2(ocpi_base + additional_collateral_fee)
    proxy_qty = count(bank_proxy_check_quantity, "mortgage_bank_proxy_checks", 2)
    legal_qty = count(legalized_copy_quantity, "mortgage_legalized_copies", 6)
    default_ver_qty = 1 if include_buyer_verification else 0
    verification_qty = count(buyer_verification_quantity, "mortgage_buyer_verifications", default_ver_qty)
    default_auth_qty = 1 if standalone else 0
    auth_qty = count(authentication_extract_quantity, "mortgage_authentication_extracts", default_auth_qty)
    bank_proxy_check_unit = D("18.15")
    legalized_copy_unit = D("6.05")
    verification_unit = person_verification(buyer_type)
    bank_proxy_checks = money2(bank_proxy_check_unit * proxy_qty)
    bank_proxy_legalization = money2(legalized_copy_unit * legal_qty)
    verification = money2(verification_unit * verification_qty)
    authentication_extract = money2(D("40.00") * auth_qty)
    notation_qty = count(land_book_notation_quantity, "mortgage_notation_count", 0)
    notation_unit = D("75.00")
    land_book_notation = money2(notation_unit * notation_qty)
    total = honorarium + archive + vat + ocpi + bank_proxy_checks + bank_proxy_legalization + verification + authentication_extract + land_book_notation
    return {
        "credit_lei": money2(credit),
        "honorarium_before_increase": base_honorarium,
        "honorarium_increase_percent": pct,
        "honorarium_increase_amount": increase_amount,
        "honorarium_net": honorarium,
        "archive": archive,
        "vat": vat,
        "ocpi_base": money2(ocpi_base),
        "additional_collateral_property_quantity": additional_collateral_qty,
        "additional_collateral_property_unit": additional_collateral_unit,
        "additional_collateral_property_fee": additional_collateral_fee,
        "ocpi": ocpi,
        "bank_proxy_check_quantity": proxy_qty,
        "bank_proxy_check_unit": bank_proxy_check_unit,
        "bank_proxy_checks": bank_proxy_checks,
        "legalized_copy_quantity": legal_qty,
        "legalized_copy_unit": legalized_copy_unit,
        "bank_proxy_legalization": bank_proxy_legalization,
        "buyer_verification_quantity": verification_qty,
        "buyer_verification_unit": verification_unit,
        "buyer_verification": verification,
        "authentication_extract_quantity": auth_qty,
        "authentication_extract_unit": D("40.00"),
        "authentication_extract": authentication_extract,
        "notation_quantity": notation_qty,
        "notation_unit": notation_unit,
        "land_book_notation": land_book_notation,
        "buyer_total": money2(total),
    }

def _effective_money(amount: Any, currency: str, fx_rate: Decimal) -> Decimal:
    value = dec(amount, "amount")
    if currency == "RON":
        return money2(value)
    if currency == "EUR":
        return money2(value * fx_rate)
    raise FailClosedError("UNSUPPORTED_CURRENCY", "Versiunea canonică acceptă RON și EUR.")


def validate_and_calculate(request: Dict[str, Any]) -> Dict[str, Any]:
    """Validate a normalized request and produce a structured internal draft.

    Unknown person types are not guessed. The orchestrator must expand them into PF/PJ
    variants before calling this function, or return a controlled variant request.
    """
    try:
        acts = request.get("acts") or []
        if not isinstance(acts, list) or not acts:
            raise FailClosedError("MISSING_ACTS", "Nu a fost indicat niciun act.", ["acts"])
        allowed = {"opinion", "antecontract", "sale", "mortgage", "radiere"}
        if any(a not in allowed for a in acts):
            raise FailClosedError("UNKNOWN_ACT", "A fost indicat un act neacceptat de M1-C01.")

        buyer_type = request.get("buyer_type")
        seller_type = request.get("seller_type")
        if buyer_type not in ("PF", "PJ") and any(a in acts for a in ("antecontract", "sale", "mortgage")):
            raise FailClosedError(
                "BUYER_TYPE_VARIANTS_REQUIRED",
                "Tipul cumpărătorului nu este precizat; trebuie generate separat variantele PF și PJ.",
                ["buyer_type"],
            )
        if seller_type not in ("PF", "PJ") and any(a in acts for a in ("antecontract", "sale")):
            raise FailClosedError(
                "SELLER_TYPE_VARIANTS_REQUIRED",
                "Tipul vânzătorului nu este precizat; trebuie generate separat variantele PF și PJ.",
                ["seller_type"],
            )

        fx = request.get("fx") or {}
        currency = request.get("currency", "EUR")
        if currency == "EUR":
            if fx.get("rate") is None:
                raise FailClosedError("MISSING_FX_RATE", "Lipsește cursul valutar efectiv.", ["fx.rate"])
            fx_rate = dec(fx["rate"], "fx.rate")
            for f in ("publication_date", "effective_date", "source"):
                if not fx.get(f):
                    raise FailClosedError("MISSING_FX_METADATA", "Metadatele cursului sunt incomplete.", [f"fx.{f}"])
        else:
            fx_rate = D("1")

        if "antecontract" in acts and request.get("advance") is None:
            own_funds_for_confirmation = request.get("own_funds")
            confirmed = request.get("advance_equals_own_funds_confirmed") is True
            if confirmed:
                if own_funds_for_confirmation is None:
                    raise FailClosedError(
                        "INVALID_ADVANCE_CONFIRMATION",
                        "Confirmarea că avansul este egal cu sursele proprii nu poate fi aplicată deoarece lipsesc sursele proprii.",
                        ["own_funds"],
                    )
                request = dict(request)
                request["advance"] = own_funds_for_confirmation
            elif request.get("finalization_requested") is True:
                raise FailClosedError(
                    "UNCONFIRMED_ANTECONTRACT_ADVANCE",
                    "Finalizarea a fost solicitată fără confirmarea sumei achitate la antecontract.",
                    ["advance"],
                )
            else:
                if own_funds_for_confirmation is not None:
                    question = (
                        f"Confirmați că suma achitată la antecontract este {own_funds_for_confirmation} {currency}, "
                        "reprezentând integral sursele proprii?"
                    )
                    proposed = {"advance": str(own_funds_for_confirmation), "currency": currency, "basis": "own_funds"}
                else:
                    question = "Ce sumă se achită la antecontract?"
                    proposed = None
                return {
                    "status": "NECESITA_CLARIFICARE",
                    "clarification_code": "CONFIRM_ANTECONTRACT_ADVANCE",
                    "question": question,
                    "missing_fields": ["advance"],
                    "proposed_value": proposed,
                    "assumption_applied": False,
                    "automatic_propagation": False,
                    "human_approval_required": True,
                }
        if "sale" in acts and request.get("price") is None:
            raise FailClosedError("MISSING_PRICE", "Lipsește prețul vânzării.", ["price"])

        price_lei = None
        if request.get("price") is not None:
            price_lei = _effective_money(request["price"], currency, fx_rate)

        advance_lei = None
        if request.get("advance") is not None:
            advance_lei = _effective_money(request["advance"], currency, fx_rate)
            if price_lei is not None and advance_lei > price_lei:
                raise FailClosedError("ADVANCE_EXCEEDS_PRICE", "Avansul depășește prețul.")

        credit_lei = None
        credit = request.get("credit")
        own_funds = request.get("own_funds")
        if "mortgage" in acts:
            standalone_mortgage = "sale" not in acts
            if standalone_mortgage:
                # Actul autonom are ca bază exclusiv valoarea creditului indicată de operator.
                # Nu se solicită și nu se inventează un preț al vânzării.
                if credit is None:
                    raise FailClosedError("MISSING_CREDIT", "Lipsește valoarea creditului pentru ipoteca/refinanțarea autonomă.", ["credit"])
                credit_lei = _effective_money(credit, currency, fx_rate)
            else:
                if credit is None and own_funds is None:
                    raise FailClosedError("MISSING_CREDIT", "Lipsește valoarea creditului sau a surselor proprii.", ["credit"])
                if price_lei is None:
                    raise FailClosedError("MISSING_PRICE", "Ipoteca din combinație necesită prețul vânzării.", ["price"])
                if credit is not None:
                    credit_lei = _effective_money(credit, currency, fx_rate)
                if own_funds is not None:
                    own_funds_lei = _effective_money(own_funds, currency, fx_rate)
                    derived_credit = money2(price_lei - own_funds_lei)
                    if derived_credit < 0:
                        raise FailClosedError("OWN_FUNDS_EXCEED_PRICE", "Sursele proprii depășesc prețul.")
                    if credit_lei is None:
                        credit_lei = derived_credit
                    elif credit_lei != derived_credit:
                        raise FailClosedError("FINANCING_MISMATCH", "Sursele proprii și creditul nu însumează prețul.")

        adjustment = request.get("honorarium_adjustment") or {}
        if not isinstance(adjustment, dict):
            raise FailClosedError("INVALID_HONORARIUM_ADJUSTMENT", "Ajustarea onorariului trebuie să fie un obiect.")
        increase_percent = adjustment.get("percent", 0)
        increase_scope = adjustment.get("scope") or []
        if isinstance(increase_scope, str):
            increase_scope = [increase_scope]
        if not isinstance(increase_scope, list):
            raise FailClosedError("INVALID_HONORARIUM_SCOPE", "Scope-ul majorării onorariului este invalid.")
        if any(v not in {"sale", "mortgage", "antecontract", "opinion", "radiere"} for v in increase_scope):
            raise FailClosedError("INVALID_HONORARIUM_SCOPE", "Ajustarea onorariului se aplică numai actelor: sale, mortgage, antecontract, opinion, radiere (am.174).")
        if any(v not in acts for v in increase_scope):
            raise FailClosedError("HONORARIUM_SCOPE_NOT_IN_CASE", "Scope-ul ajustării include un act absent din speță.")
        increase_percent_dec = signed_pct(increase_percent, "honorarium_adjustment.percent")  # am.174: si reducere
        quantities = request.get("component_quantities") or {}
        if not isinstance(quantities, dict):
            raise FailClosedError("INVALID_COMPONENT_QUANTITIES", "Cantitățile componentelor trebuie să fie un obiect.")

        tax_percent = request.get("seller_tax_percent")
        if tax_percent is not None:
            try:
                tax_percent = int(tax_percent)
            except (TypeError, ValueError) as exc:
                raise FailClosedError("INVALID_TAX_VARIANT", "Cota de impozit este invalidă.") from exc
        # am.282 (V1.23): impozitul PE COTE — lista cotelor cu procentul fiecareia; validata in sale_calculation
        tax_shares = request.get("seller_tax_shares")
        if tax_shares is not None:
            if not isinstance(tax_shares, list) or not tax_shares:
                raise FailClosedError("INVALID_TAX_SHARES", "seller_tax_shares trebuie să fie o listă nevidă de cote {cota, tax_percent}.")
            if tax_percent is not None:
                raise FailClosedError("TAX_SHARES_CONFLICT", "Impozitul pe cote (seller_tax_shares) nu se combină cu o cotă unică (seller_tax_percent).")
            if "sale" not in acts:
                raise FailClosedError("TAX_SHARES_WITHOUT_SALE", "Impozitul pe cote are sens numai la o vânzare prezentă în speță.")

        totals: Dict[str, Any] = {}
        components: Dict[str, Any] = {}
        seller_extra_radiere = D("0")  # am.169
        buyer_without = D("0")
        seller_ante = D("0")
        ante_fee = D("0")
        notation_amount = D("0")

        if "opinion" in acts:
            components["opinion"] = opinion_calculation(
                quantities.get("opinion_information_extracts", 1),
                quantities.get("opinion_notation_count", 0),
                honorarium_increase_percent=increase_percent_dec if "opinion" in increase_scope else 0,
            )
            buyer_without += components["opinion"]["total"]
        if "radiere" in acts:
            components["radiere"] = radiere_calculation(
                quantities.get("radiere_information_extracts", 1),
                quantities.get("radiere_notation_count", 0),
                honorarium_increase_percent=increase_percent_dec if "radiere" in increase_scope else 0,
            )
            if str(request.get("radiere_party") or "buyer") == "seller":  # am.169 (V4.20): Declaratia de radiere in sarcina vanzatorului
                components["radiere"]["party"] = "seller"
                seller_extra_radiere = components["radiere"]["total"]
            else:
                components["radiere"]["party"] = "buyer"
                buyer_without += components["radiere"]["total"]

        if "antecontract" in acts:
            components["antecontract"] = antecontract_calculation(
                advance_lei, buyer_type, seller_type,
                buyer_verification_quantity=quantities.get("antecontract_buyer_verifications"),
                seller_information_extract_quantity=quantities.get("antecontract_seller_information_extracts", 1),
                seller_verification_quantity=quantities.get("antecontract_seller_verifications"),
                notation_quantity=quantities.get("antecontract_notation_count", 1),
                honorarium_increase_percent=increase_percent_dec if "antecontract" in increase_scope else 0,
            )
            ante_fee = components["antecontract"]["honorarium_net"]
            buyer_without += components["antecontract"]["buyer_without_notation"]
            seller_ante = components["antecontract"]["seller_total"]
            notation_amount = components["antecontract"]["optional_notation"]

        # PATCH V4.20 (am.169, R-PROMISIUNE-EXTERNA, titular 29.08.2026: «scade-mi promisiunea 700 lei din onorariu» — promisiunea
        # facuta la alt birou sau taxata anterior doar pe promisiune): suma NETA (fara TVA) declarata de operator se deduce din
        # onorariul NET al vanzarii cand antecontractul NU este in calcul. Conflict cu antecontractul intern → DEDUCTION_CONFLICT;
        # fara vanzare → DEDUCTION_WITHOUT_SALE; negativa → INVALID_EXTERNAL_DEDUCTION; peste onorariu → DEDUCTION_EXCEEDS_FEE (nemodificat).
        external_deduction = D("0")
        _ext_raw = request.get("external_antecontract_honorarium_net")
        if _ext_raw is not None:
            external_deduction = money2(dec(_ext_raw, "external_antecontract_honorarium_net"))
            if external_deduction < 0:
                raise FailClosedError("INVALID_EXTERNAL_DEDUCTION", "Onorariul promisiunii externe nu poate fi negativ.")
            if "antecontract" in acts:
                raise FailClosedError("DEDUCTION_CONFLICT", "Antecontractul este în calcul; nu se acceptă și o promisiune externă de dedus.")
            if "sale" not in acts:
                raise FailClosedError("DEDUCTION_WITHOUT_SALE", "Promisiunea externă se deduce numai din onorariul unei vânzări prezente în speță.")
        _internal_ded_on = request.get("deduct_antecontract_honorarium", True) is not False
        # PATCH V4.27 (am.374, S4 ratificat T56c): precedenta «onorariu intreg» > suma neta data >
        # promisiunea in calcul. Flagul deduct_antecontract_honorarium=false este INSTRUCTIUNEA
        # titularului si stinge AMANDOUA sursele, nu doar pe cea interna.
        _deduction_suppressed = False
        if "antecontract" in acts:
            _deduction_value = ante_fee if _internal_ded_on else D("0")
            _deduction_source = "antecontract_intern" if _internal_ded_on else None
            _deduction_suppressed = not _internal_ded_on
        elif external_deduction > 0 and _internal_ded_on:
            _deduction_value = external_deduction
            _deduction_source = "operator_extern"
        elif external_deduction > 0:
            _deduction_value = D("0"); _deduction_source = None
            _deduction_suppressed = True  # am.374: suma neta data, dar instructiunea cere onorariul intreg
        else:
            _deduction_value = D("0"); _deduction_source = None

        sale_result = None
        if "sale" in acts:
            sale_result = sale_calculation(
                price_lei, buyer_type, seller_type,
                usufruct_uplift=bool(request.get("usufruct_uplift", False)),
                seller_tax_percent=tax_percent,
                seller_tax_shares=tax_shares,
                antecontract_honorarium_deduction=_deduction_value,  # am.164 (V4.18) deducerea interna la comanda; am.169 (V4.20) deducerea externa declarata de operator
                include_final_verifications=True,
                honorarium_increase_percent=increase_percent_dec if "sale" in increase_scope else 0,
                buyer_verification_quantity=quantities.get("sale_buyer_verifications"),
                seller_authentication_extract_quantity=quantities.get("sale_seller_authentication_extracts", 1),
                seller_information_extract_quantity=quantities.get("sale_seller_information_extracts", 0),
                seller_verification_quantity=quantities.get("sale_seller_verifications"),
                land_book_notation_quantity=quantities.get("sale_notation_count", 0),
            )
            sale_result["antecontract_deduction_applied"] = bool(_deduction_source is not None)  # am.164 + am.169
            sale_result["antecontract_deduction_source"] = _deduction_source  # am.169: antecontract_intern / operator_extern / None
            sale_result["external_antecontract_deduction"] = external_deduction  # am.169: suma NETA declarata de operator (0 = absenta)
            sale_result["antecontract_deduction_suppressed_by_operator"] = bool(_deduction_suppressed)  # am.374 (S4): «onorariu intreg» a stins deducerea
            components["sale"] = sale_result
            buyer_without += sale_result["buyer_total"]

        if "mortgage" in acts:
            components["mortgage"] = mortgage_calculation(
                credit_lei, buyer_type,
                standalone=("sale" not in acts),
                include_buyer_verification=("sale" not in acts),
                honorarium_increase_percent=increase_percent_dec if "mortgage" in increase_scope else 0,
                bank_proxy_check_quantity=quantities.get("mortgage_bank_proxy_checks", 2),
                legalized_copy_quantity=quantities.get("mortgage_legalized_copies", 6),
                buyer_verification_quantity=quantities.get("mortgage_buyer_verifications"),
                authentication_extract_quantity=quantities.get("mortgage_authentication_extracts"),
                additional_collateral_property_quantity=quantities.get("mortgage_additional_collateral_properties", 0),
                land_book_notation_quantity=quantities.get("mortgage_notation_count", 0),
            )
            buyer_without += components["mortgage"]["buyer_total"]

        # PATCH V4.3 (decizia titularului 13.08.2026): taxe suplimentare declarate
        # explicit de operator (etichetă + sumă + parte). Nu se deduc niciodată -
        # doar input explicit; apar ca linii proprii, cu eticheta operatorului.
        additional_fees_in = request.get("additional_fees") or []
        additional_fees = []
        additional_client_total = D("0")
        additional_seller_total = D("0")  # am.169 (V4.20): taxe suplimentare in sarcina vanzatorului (party=seller)
        for af in additional_fees_in:
            try:
                amt = money2(D(str(af.get("amount"))))
            except Exception:
                raise FailClosedError("ADDITIONAL_FEE_INVALID", f"Suma taxei suplimentare '{af.get('label')}' nu este numerică.")
            label = str(af.get("label") or "").strip()
            if not label:
                raise FailClosedError("ADDITIONAL_FEE_INVALID", "Taxa suplimentară fără etichetă nu se acceptă.")
            try:
                qty = int(af.get("quantity", 1))
            except Exception:
                raise FailClosedError("ADDITIONAL_FEE_INVALID", f"Cantitatea taxei '{label}' nu este întreagă.")
            if qty < 1:
                raise FailClosedError("ADDITIONAL_FEE_INVALID", f"Cantitatea taxei '{label}' trebuie să fie cel puțin 1.")
            line_total = money2(amt * qty)
            _party = str(af.get("party") or "buyer").strip().lower()
            if _party not in ("buyer", "seller"):
                raise FailClosedError("ADDITIONAL_FEE_INVALID", f"Partea taxei '{label}' trebuie să fie buyer sau seller.")
            additional_fees.append({"label": label, "unit_amount": amt,
                                    "quantity": qty, "amount": line_total,
                                    "party": _party,
                                    "source": "operator_declared"})
            if _party == "seller":
                additional_seller_total += line_total
            else:
                additional_client_total += line_total
        if additional_fees:
            components["additional_fees"] = additional_fees
            buyer_without += additional_client_total
            totals["additional_fees_total"] = money2(additional_client_total)
            if additional_seller_total > 0:
                totals["additional_fees_seller_total"] = money2(additional_seller_total)

        # PATCH V4.16 (am.133, T8, 26.08.2026 — titular: «sa putem combina toate taxele intre ele»): SERVICII UNIVERSALE —
        # cantități explicite (service_*) aplicabile pe ORICE act/combinație; tarife pinuite (unit_costs); implicit 0; fără deduceri;
        # cantitate invalidă → INVALID_QUANTITY (fail-closed). Intră în totalul clientului (cumpărător/solicitant/debitor).
        SERVICE_CATALOG = {"service_proxy_checks": {"label": "Verificări procuri (Registrul Național Notarial al Procurilor)", "unit": "18.15", "unit_label": "verificări", "unit_singular": "verificare", "note": "TVA inclus"}, "service_legalized_copy_pages": {"label": "Legalizare copie (pe pagină)", "unit": "6.05", "unit_label": "pagini", "unit_singular": "pagină", "note": "TVA inclus"}, "service_information_extracts": {"label": "Extras de carte funciară pentru informare", "unit": "20.00", "unit_label": "extrase", "unit_singular": "extras", "note": "fără TVA"}, "service_authentication_extracts": {"label": "Extras de carte funciară pentru autentificare", "unit": "40.00", "unit_label": "extrase", "unit_singular": "extras", "note": "fără TVA"}, "service_person_verifications_pf": {"label": "Verificări în registrele notariale (persoană fizică)", "unit": "18.15", "unit_label": "verificări", "unit_singular": "verificare", "note": "TVA inclus"}, "service_person_verifications_pj": {"label": "Verificări RECOM (persoană juridică)", "unit": "30.00", "unit_label": "verificări", "unit_singular": "verificare", "note": "fără TVA"}, "service_land_book_notations": {"label": "Taxă de notare în cartea funciară", "label_radiere": "Taxă de radiere din cartea funciară", "unit": "75.00", "unit_label": "notări", "unit_label_radiere": "radieri", "unit_singular": "notare", "note": "fără TVA"},
                           "service_land_book_radieri": {"label": "Taxă de radiere din cartea funciară", "unit": "75.00", "unit_label": "radieri", "unit_singular": "radiere", "note": "fără TVA"}}  # am.169 (V4.20): radierea ca serviciu distinct pe ORICE act
        _services_party_default = str(request.get("services_party") or "buyer").strip().lower()  # am.169: comutatorul global (implicit buyer)
        if _services_party_default not in ("buyer", "seller"):
            raise FailClosedError("INVALID_SERVICES_PARTY", "services_party trebuie să fie buyer sau seller.")
        _only_radiere = ("radiere" in acts) and all(a in ("radiere", "opinion") for a in acts)
        services = []; services_total = D("0")
        services_seller = []; services_seller_total = D("0")  # am.169 (V4.20, R-SERVICII-PE-VANZATOR)
        for _sk, _sp in SERVICE_CATALOG.items():
            _lab0 = _sp.get("label_radiere") if (_only_radiere and _sp.get("label_radiere")) else _sp["label"]
            _ul = _sp.get("unit_label_radiere") if (_only_radiere and _sp.get("unit_label_radiere")) else _sp["unit_label"]
            _u = D(_sp["unit"])
            # cheia fara sufix → partea din comutatorul global; cheia cu sufix _seller → vanzator (decide per linie, are prioritate)
            for _key, _party in ((_sk, _services_party_default), (_sk + "_seller", "seller")):
                if quantities.get(_key) is None: continue
                _q = count(quantities.get(_key), _key, 0)
                if _q <= 0: continue
                _a = money2(_u * _q)
                _lab = _lab0 if _party == "buyer" else f"{_lab0} (vânzător)"
                _row = {"key": _key, "catalog_key": _sk, "party": _party, "label": _lab, "unit_amount": _u, "quantity": _q, "unit_label": _ul, "unit_singular": _sp["unit_singular"], "amount": _a, "note": _sp.get("note"), "source": "operator_declared_quantity"}
                if _party == "seller":
                    services_seller.append(_row); services_seller_total += _a
                else:
                    services.append(_row); services_total += _a
        if services:
            buyer_without += services_total
            totals["services_total"] = money2(services_total)
        if services_seller:
            totals["services_seller_total"] = money2(services_seller_total)
        seller_extra = money2(services_seller_total + additional_seller_total + seller_extra_radiere)  # am.169: tot ce cade pe vanzator in afara actelor
        if seller_extra > 0:
            totals["seller_extra_total"] = seller_extra

        totals["buyer_without_optional_notation"] = money2(buyer_without)
        totals["buyer_with_optional_notation"] = money2(buyer_without + notation_amount)

        if sale_result is not None:
            seller_sale = sale_result["seller"]
            if seller_type == "PF" and tax_percent is None and not tax_shares:
                totals["seller_tax_1"] = money2(seller_ante + seller_sale["total_1"] + seller_extra)  # am.169: serviciile vanzatorului intra in AMBELE variante
                totals["seller_tax_3"] = money2(seller_ante + seller_sale["total_3"] + seller_extra)
                totals["seller_variants_non_cumulative"] = True
            else:
                totals["seller"] = money2(seller_ante + seller_sale["total"] + seller_extra)
        elif "antecontract" in acts:
            totals["seller"] = money2(seller_ante + seller_extra)
        elif seller_extra > 0:
            totals["seller"] = money2(seller_extra)  # am.169: vanzator numai cu servicii/taxe declarate (ex. radiere in sarcina lui)

        return {
            "status": "CALCULATION_PASS_INTERNAL_DRAFT",
            "module": "M1-C01",
            "module_version": ENGINE_VERSION,  # T36b: urmeaza versiunea motorului (audit T36)
            "configuration": {
                "acts": acts,
                "buyer_type": buyer_type,
                "seller_type": seller_type,
                "client": request.get("client") or "—",
                "broker": request.get("broker") or "—",
                "currency": currency,
                "fx": fx,
                "operator_confirmations": {
                    "advance_equals_own_funds": request.get("advance_equals_own_funds_confirmed") is True
                },
                "honorarium_adjustment": {
                    "percent": _jsonable(increase_percent_dec),
                    "scope": increase_scope,
                },
                "reprezentant": request.get("reprezentant"),  # am.465: cine a facut oferta; motorul il DUCE, nu-l interpreteaza
                "component_quantities": quantities,
                "services_party": _services_party_default,  # am.169
                "radiere_party": (components.get("radiere") or {}).get("party") if "radiere" in components else None,  # am.169
                "external_antecontract_honorarium_net": _jsonable(external_deduction) if _ext_raw is not None else None,  # am.169
            },
            "components": _jsonable(components),
            "services": _jsonable(services),  # am.133 (V4.16)
            "services_seller": _jsonable(services_seller),  # am.169 (V4.20)
            "totals": _jsonable(totals),
            "default_deliverables": ["DOCX_OFFER", "PDF_OFFER"],
            "human_approval_required": True,
            "automatic_send": False,
            "automatic_propagation": False,
            "core_modified": False,
        }
    except FailClosedError as exc:
        return exc.as_result()


def _jsonable(value: Any) -> Any:
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, dict):
        return {k: _jsonable(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_jsonable(v) for v in value]
    return value


__all__ = [
    "FailClosedError",
    "sale_honorarium",
    "mortgage_honorarium",
    "opinion_calculation",
    "antecontract_calculation",
    "sale_calculation",
    "mortgage_calculation",
    "validate_and_calculate",
]
