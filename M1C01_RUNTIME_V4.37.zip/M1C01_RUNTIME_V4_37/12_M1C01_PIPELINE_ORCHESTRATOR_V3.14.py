"""SPN STOICA AI — M1-C01 deterministic pipeline orchestrator V3.14 (V4.25, am.367, titular 09.09.2026).

V3.14 + am.483 (V4.36, T61b, 22.09.2026): oferta detaliata POARTA rularea inauntru (atasament PDF `rulare.json`, aceiasi octeti ca al patrulea livrabil); titularul: «oferta detaliata sa contina aceasta rulare json».
V3.14 + am.482 (V4.36, T61b, 22.09.2026): AM482_RULARE — al PATRULEA livrabil, `rulare.json` (ENGINE_RESULT + NORMALIZED_CASE,
format M1C01_RULARE_V1), ca sumele sa poata ajunge in actul redactat rapid (am.343: nicio cifra fara rularea ei); cifrele neschimbate.
V3.14 + am.399 (V4.29, T57i-bis): AM399_PRET_TVA — mentiunea TVA a pretului o da operatorul (`pret_tva`: CU_TVA_INCLUS / FARA_TVA);
CU_TVA_INCLUS + `baza_fara_tva: da` -> baza = total / (1 + cota), 2 zecimale; vanzator PJ fara mentiune -> intrebare de mijloc neblocanta;
fara mentiune -> V4.28 bit-identic.
V3.14 + am.388 (V4.28, T56y): AM388_LIVRARE — mereu exact trei fisiere: oferta.pdf (scurt) + oferta_detaliata.pdf (extins) + oferta_mail.docx (e-mail complet; scurt numai la `email_format: scurt`);
la split sufix _cumparator / _vanzator; cererea operatorului pe format se consemneaza, nu schimba livrarea.
V3.14 (am.367): R-FORMAT-OFERTA (`offer_format` scurt implicit / complet; setul scurt livrat cu sufix _SCURT); R-ANCPI-ROTUNJIRE-SUS
(`ancpi_rounding` ceil implicit / floor numai pe etaloane inghetate); R-VERIFICARI-TOTAL-VANZARE (`verificari_pf` pe vanzare = TOTAL);
coliziunea `notari_cf` (o singura numarare). Motorul V1.25.


V3.13 (am.282 — R-IMPOZIT-MIXT-COTE): citește `seller_tax_shares` (aliasuri: impozit_cote, cote_impozit, impozit_pe_cote)
= lista cotelor [{cota: «1/2» | «50%» | 0.5, tax_percent: 1 | 3, label/act: text}] și o pune în NORMALIZED_CASE;
motorul V1.24 (V1.23 + module_version corectat, T36b) calculează impozitul pe fiecare cotă și îl însumează. Aliasuri de cotă: cota/cote/parte; de procent:
tax_percent/procent/impozit/cota_impozit. Conflictul cu seller_tax_percent îl declară motorul (TAX_SHARES_CONFLICT), orchestratorul transmite ambele câmpuri.
Fără cote → bit-identic cu V3.12.

--- istoric V3.9 ---

V3.9 (am.135 — R-OFERTA-INDIVIDUALA): citește `offer_for` (aliasuri: oferta_pentru, solicitant_oferta, pentru) ∈
{both, buyer, seller, split} și `include_broker` (aliasuri: broker_in_oferta, include_intermediar; implicit true —
brokerul dispare NUMAI la comandă explicită), le pune în NORMALIZED_CASE (motorul le ignoră; calculul rămâne comun,
același run_id) și le transmite generatorului V3.10. Livrarea publică poartă sufixul părții (`_CUMPARATOR` / `_VANZATOR`)
pe buyer/seller/split; la split ies două seturi de documente dintr-o singură rulare (cheile `*_seller` în
delivery_artifacts, atașate după setul cumpărătorului). `both` = bit-identic cu V3.8.

--- istoric V3.6 ---

V3.4 extinde descoperirea dinamică — introdusă în V3.3 doar pentru motor — la
generator, FX Gate și registrul FX, care erau fixate pe nume de versiune în cod.
Aceeași disciplină: exact o versiune activă, altfel oprire fail-closed.

V3.4 propagă de asemenea cererea de curs a FX Gate V2.0 ca NECESITA_CLARIFICARE,
nu ca respingere. V3.3 transforma orice rezultat non-PASS al gate-ului în
RESPINS_FAIL_CLOSED, ceea ce ar fi transformat o întrebare adresată operatorului
într-o eroare de execuție.

V3.6 remediază DEF-08: contractul public de livrare cerea necondiționat toate
trei livrabilele, deci orice `requested_formats` parțial era respins cu
DELIVERY_CONTRACT_INCOMPLETE, deși documentele cerute fuseseră generate corect.
Contractul respectă acum formatele efectiv solicitate; setul implicit rămâne
complet (DOCX + PDF + Word e-mail) când operatorul nu cere altceva.

Nu modifică CORE, formulele, motorul sau conținutul livrabilelor.


Local scope only: ChatBuild M1-C01. This file does not modify CORE, the parent
project, the canonical calculation engine, or the offer generator.

Purpose:
- normalize a compact case envelope into the canonical engine schema;
- execute the active engine and generator atomically;
- remove stale aliases before execution;
- verify generated deliverables and QA before reporting success;
- publish run-bound success and fail-closed audit artifacts;
- emit a compact attachment contract containing only exact root-level download paths;
- preserve human approval and disable automatic sending/propagation.

The runtime remains responsible for supplying a verified FX rate. This script
never invents or downloads an exchange rate.
"""
from __future__ import annotations

# am.431 (T59a): scriere LF + stdout UTF-8 + legaturi fara privilegiu, pe orice mediu (R-71: pe Linux, no-op).
import os as _os_am431, sys as _sys_am431  # noqa: E402
_sys_am431.path.insert(0, _os_am431.path.abspath(_os_am431.path.join(_os_am431.path.dirname(_os_am431.path.abspath(__file__)), '..', '..')))
try:
    import SPN_PORTABIL_V1 as _portabil_am431  # noqa: E402,F401
except ImportError:  # runtime-ul livrat singur sau COPIAT in afara bancului (skill spn-taxe-m1c01, fixturile bateriei)
    # Fara modul, se face aici minimul care altfel opreste rularea: fluxurile pe UTF-8. Masurat in T59a —
    # copia runtime-ului din fixtura T56Z cadea cu «'charmap' codec can't encode 'ș'», deci orchestratorul
    # respingea livrarea desi motorul calculase corect. Pe Linux e no-op (fluxurile sunt deja UTF-8).
    _portabil_am431 = None
    for _flux_am431 in (_sys_am431.stdout, _sys_am431.stderr):
        try:
            if _flux_am431 is not None and (getattr(_flux_am431, 'encoding', '') or '').lower().replace('-', '') != 'utf8':
                _flux_am431.reconfigure(encoding='utf-8', errors='backslashreplace')
        except Exception:
            pass

import argparse
import contextlib
import io
import hashlib
import importlib.util
import json
import shutil
import sys
import re
import unicodedata
import traceback
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional
from zoneinfo import ZoneInfo

ENGINE_PREFIX = "08_M1C01_REFERENCE_ENGINE_V"
ENGINE_SUFFIX = ".py"
GENERATOR_PREFIX = "11_M1C01_OFFER_GENERATOR_V"
GENERATOR_SUFFIX = ".py"
FX_GATE_PREFIX = "14_M1C01_FX_GATE_V"
FX_GATE_SUFFIX = ".py"
REGISTRY_PREFIX = "17_BNR_FX_REGISTRY"
REGISTRY_SUFFIX = ".json"
# Etichete folosite exclusiv în rapoarte, când componenta nu a fost încă rezolvată.
GENERATOR_NAME = f"{GENERATOR_PREFIX}*{GENERATOR_SUFFIX}"
FX_GATE_NAME = f"{FX_GATE_PREFIX}*{FX_GATE_SUFFIX}"
REGISTRY_NAME = f"{REGISTRY_PREFIX}*{REGISTRY_SUFFIX}"
SESSION_STATE_NAME = "M1C01_SESSION_STATE.json"
ATTACHMENT_RESULT_NAME = "M1C01_ATTACHMENT_RESULT.json"
ATTACHMENT_CONTRACT_VERSION = "M1C01_ATTACH_EXACT_PATHS_V2"
ORCHESTRATOR_VERSION = "3.14"
OUTPUT_BASENAME = "OFERTA_M1-C01_CANONICA"
ARTIFACT_NAMES = (
    "ENGINE_RESULT.json",
    f"{OUTPUT_BASENAME}.docx",
    f"{OUTPUT_BASENAME}.pdf",
    "EMAIL_REZUMAT_M1-C01.docx",
    "RAPORT_QA_GENERATOR.json",
    "PIPELINE_RESULT.json",
    "M1C01_LIVRABIL_CURENT.docx",
    "M1C01_LIVRABIL_CURENT.pdf",
    "M1C01_DELIVERY_MANIFEST.json",
    "M1C01_DELIVERY_LATEST.json",
    ATTACHMENT_RESULT_NAME,
)
# am.388: numele publice fixe (decizia titularului, 10.09.2026) — sterse de la radacina la fiecare rulare
AM388_NUME_PUBLICE = {"pdf": "oferta", "pdf_detaliat": "oferta_detaliata", "email_docx": "oferta_mail",
                      "rulare_json": "rulare"}  # am.482: al patrulea livrabil, fisierul rularii
AM388_EXTENSII = {"pdf": "pdf", "pdf_detaliat": "pdf", "email_docx": "docx", "rulare_json": "json"}
AM388_SUFIX_SPLIT = {"buyer": "_cumparator", "seller": "_vanzator"}
ARTIFACT_NAMES = ARTIFACT_NAMES + tuple(
    f"{AM388_NUME_PUBLICE[k]}{s}.{AM388_EXTENSII[k]}" for k in AM388_NUME_PUBLICE for s in ("", "_cumparator", "_vanzator"))


class FXClarificationNeeded(RuntimeError):
    """Cursul nu a putut fi stabilit automat; operatorul trebuie să îl indice.

    Nu este eroare de execuție: pipeline-ul raportează NECESITA_CLARIFICARE, la
    fel ca la variantele de tip PF/PJ neprecizate.
    """

    def __init__(self, code: str, message: str, details: Dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


class OrchestratorError(RuntimeError):
    def __init__(self, code: str, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


@dataclass(frozen=True)
class CanonicalFiles:
    engine: Path
    generator: Path


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _json_dump(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _case_sha256(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(_canonical_json_bytes(payload)).hexdigest()


def _new_run_id(case_sha256: str) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    return f"{stamp}_{case_sha256[:10]}"


def _load_json(path: Path) -> Dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise OrchestratorError("INPUT_NOT_FOUND", f"Fișierul de intrare nu există: {path}") from exc
    except json.JSONDecodeError as exc:
        raise OrchestratorError("INPUT_INVALID_JSON", f"JSON invalid în {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise OrchestratorError("INPUT_NOT_OBJECT", "Intrarea trebuie să fie un obiect JSON.")
    return value


def _resolve_candidates(root: Path, filename: str) -> list[Path]:
    direct = root / filename
    candidates = [direct] if direct.is_file() else []
    candidates.extend(p for p in root.rglob(filename) if p.is_file() and p != direct)
    unique: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        resolved = str(path.resolve())
        if resolved not in seen:
            seen.add(resolved)
            unique.append(path)
    return unique


def _select_exact_file(root: Path, filename: str, explicit: Optional[Path] = None) -> Path:
    if explicit is not None:
        if not explicit.is_file() or explicit.name != filename:
            raise OrchestratorError(
                "FILE_CANONIC_NOT_FOUND",
                f"Fișierul explicit nu este versiunea canonică cerută: {filename}",
                {"provided": str(explicit)},
            )
        return explicit.resolve()

    candidates = _resolve_candidates(root, filename)
    if not candidates:
        raise OrchestratorError("FILE_CANONIC_NOT_FOUND", f"Lipsește fișierul canonic {filename}.")

    # Multiple identical Knowledge copies are acceptable; conflicting binaries are not.
    by_hash: Dict[str, list[Path]] = {}
    for candidate in candidates:
        by_hash.setdefault(_sha256(candidate), []).append(candidate)
    if len(by_hash) > 1:
        raise OrchestratorError(
            "CONFLICTING_CANONICAL_FILES",
            f"Există copii binar diferite pentru {filename}.",
            {digest: [str(p) for p in paths] for digest, paths in by_hash.items()},
        )

    # Prefer the shallowest path, then lexical order.
    return sorted(candidates, key=lambda p: (len(p.parts), str(p)))[0].resolve()


def _version_key(path: Path, prefix: str, suffix: str) -> tuple[int, ...]:
    """Extrage versiunea numerică dintr-un nume `PREFIX<versiune>SUFIX`."""
    name = path.name
    if not (name.startswith(prefix) and name.endswith(suffix)):
        return ()
    raw = name[len(prefix):-len(suffix)]
    try:
        return tuple(int(part) for part in raw.split("."))
    except ValueError:
        return ()


def _engine_version_key(path: Path) -> tuple[int, ...]:
    return _version_key(path, ENGINE_PREFIX, ENGINE_SUFFIX)


def _select_versioned_component(
    root: Path,
    prefix: str,
    suffix: str,
    label: str,
    explicit: Optional[Path] = None,
    *,
    require_numeric_version: bool = True,
) -> Path:
    """Descoperă exact o versiune activă a unei componente versionate.

    Aceeași disciplină aplicată motorului începând cu V3.3: se caută întâi la
    rădăcina Knowledge, apoi recursiv. Coexistența mai multor versiuni sau a
    unor copii binar diferite ale aceleiași versiuni oprește fail-closed.
    Orchestratorul nu alege niciodată singur între versiuni.
    """
    def _key(path: Path) -> tuple[int, ...]:
        key = _version_key(path, prefix, suffix)
        if key or not require_numeric_version:
            return key or (0,)
        return ()

    if explicit is not None:
        if not explicit.is_file():
            raise OrchestratorError(
                "FILE_CANONIC_NOT_FOUND",
                f"Fișierul explicit indicat pentru {label} nu există.",
                {"provided": str(explicit)},
            )
        return explicit.resolve()

    direct = sorted(
        (p for p in root.glob(f"{prefix}*{suffix}") if p.is_file() and _key(p)),
        key=_key,
    )
    candidates = direct
    if not candidates:
        candidates = sorted(
            (p for p in root.rglob(f"{prefix}*{suffix}") if p.is_file() and _key(p)),
            key=lambda p: (_key(p), len(p.parts), str(p)),
        )
    if not candidates:
        raise OrchestratorError(
            "FILE_CANONIC_NOT_FOUND",
            f"Lipsește componenta activă {label} ({prefix}*{suffix}).",
        )

    versions: Dict[str, list[Path]] = {}
    for candidate in candidates:
        version = ".".join(str(x) for x in _key(candidate))
        versions.setdefault(version, []).append(candidate)

    if len(versions) != 1:
        raise OrchestratorError(
            "MULTIPLE_ACTIVE_COMPONENT_VERSIONS",
            f"Există mai multe versiuni active pentru {label}; păstrați exact una.",
            {version: [str(p) for p in paths] for version, paths in versions.items()},
        )

    only_paths = next(iter(versions.values()))
    by_hash: Dict[str, list[Path]] = {}
    for candidate in only_paths:
        by_hash.setdefault(_sha256(candidate), []).append(candidate)
    if len(by_hash) > 1:
        raise OrchestratorError(
            "CONFLICTING_CANONICAL_FILES",
            f"Există copii binar diferite ale aceleiași versiuni pentru {label}.",
            {digest: [str(p) for p in paths] for digest, paths in by_hash.items()},
        )
    return sorted(only_paths, key=lambda p: (len(p.parts), str(p)))[0].resolve()


def _select_active_engine(root: Path, explicit: Optional[Path] = None) -> Path:
    if explicit is not None:
        if not explicit.is_file() or not _engine_version_key(explicit):
            raise OrchestratorError(
                "FILE_CANONIC_NOT_FOUND",
                "Fișierul explicit nu este un motor M1-C01 versionat valid.",
                {"provided": str(explicit)},
            )
        return explicit.resolve()

    # The Builder contract requires exactly one active engine version in Knowledge.
    # Search root-level first (normal Builder mount). Recursive fallback is accepted
    # only when it resolves to one version; multiple versions fail closed.
    direct = sorted(
        (p for p in root.glob(f"{ENGINE_PREFIX}*{ENGINE_SUFFIX}") if p.is_file() and _engine_version_key(p)),
        key=_engine_version_key,
    )
    candidates = direct
    if not candidates:
        candidates = sorted(
            (p for p in root.rglob(f"{ENGINE_PREFIX}*{ENGINE_SUFFIX}") if p.is_file() and _engine_version_key(p)),
            key=lambda p: (_engine_version_key(p), len(p.parts), str(p)),
        )

    if not candidates:
        raise OrchestratorError(
            "FILE_CANONIC_NOT_FOUND",
            "Lipsește motorul activ M1-C01 (08_M1C01_REFERENCE_ENGINE_V*.py).",
        )

    versions: Dict[str, list[Path]] = {}
    for candidate in candidates:
        version = ".".join(str(x) for x in _engine_version_key(candidate))
        versions.setdefault(version, []).append(candidate)

    if len(versions) != 1:
        raise OrchestratorError(
            "MULTIPLE_ACTIVE_ENGINE_VERSIONS",
            "Există mai multe versiuni de motor M1-C01 în Knowledge; păstrați exact una.",
            {version: [str(p) for p in paths] for version, paths in versions.items()},
        )

    only_paths = next(iter(versions.values()))
    by_hash: Dict[str, list[Path]] = {}
    for candidate in only_paths:
        by_hash.setdefault(_sha256(candidate), []).append(candidate)
    if len(by_hash) > 1:
        raise OrchestratorError(
            "CONFLICTING_CANONICAL_FILES",
            "Există copii binar diferite ale aceleiași versiuni de motor M1-C01.",
            {digest: [str(p) for p in paths] for digest, paths in by_hash.items()},
        )

    return sorted(only_paths, key=lambda p: (len(p.parts), str(p)))[0].resolve()


def locate_canonical_files(
    search_root: Path,
    engine_path: Optional[Path] = None,
    generator_path: Optional[Path] = None,
) -> CanonicalFiles:
    return CanonicalFiles(
        engine=_select_active_engine(search_root, engine_path),
        generator=_select_versioned_component(
            search_root, GENERATOR_PREFIX, GENERATOR_SUFFIX, "generator ofertă", generator_path
        ),
    )


def _load_module(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise OrchestratorError("MODULE_LOAD_FAILED", f"Nu poate fi încărcat modulul {path.name}.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _first(data: Mapping[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in data and data[key] is not None:
            return data[key]
    return default


def _bool(value: Any) -> Optional[bool]:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "da", "confirmat", "confirmed"}:
        return True
    if text in {"0", "false", "no", "nu", "neconfirmat", "unconfirmed"}:
        return False
    return None


def _person(value: Any) -> Any:
    if value is None:
        return None
    text = str(value).strip().upper()
    aliases = {
        "PF": "PF",
        "PERSOANA FIZICA": "PF",
        "PERSOANĂ FIZICĂ": "PF",
        "FIZICA": "PF",
        "FIZICĂ": "PF",
        "PJ": "PJ",
        "PERSOANA JURIDICA": "PJ",
        "PERSOANĂ JURIDICĂ": "PJ",
        "JURIDICA": "PJ",
        "JURIDICĂ": "PJ",
    }
    return aliases.get(text, text)


def _act(value: Any) -> str:
    text = str(value).strip().lower()
    aliases = {
        "opinion": "opinion",
        "opinie": "opinion",
        "opinie notariala": "opinion",
        "opinie notarială": "opinion",
        "antecontract": "antecontract",
        "promisiune": "antecontract",
        "sale": "sale",
        "vanzare": "sale",
        "vânzare": "sale",
        "contract de vanzare": "sale",
        "contract de vânzare": "sale",
        "mortgage": "mortgage",
        "ipoteca": "mortgage",
        "ipotecă": "mortgage",
        "contract de ipoteca": "mortgage",
        "contract de ipotecă": "mortgage",
        "refinantare": "mortgage",
        "refinanțare": "mortgage",
    }
    return aliases.get(text, text)


def _decimal(value: Any, field: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise OrchestratorError("INVALID_NUMBER", f"Valoare numerică invalidă: {field}.") from exc
    if not result.is_finite() or result < 0:
        raise OrchestratorError("INVALID_NUMBER", f"Valoare numerică negativă sau ne-finită: {field}.")
    return result


def _scope_values(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {"ambele", "both", "sale_and_mortgage", "vanzare_si_ipoteca", "vânzare și ipotecă"}:
            return ["sale", "mortgage"]
        raw = [part.strip() for part in text.replace("+", ",").replace("/", ",").split(",") if part.strip()]
    elif isinstance(value, (list, tuple, set)):
        raw = list(value)
    else:
        raw = [value]
    aliases = {
        "sale": "sale", "vanzare": "sale", "vânzare": "sale", "contract de vanzare": "sale", "contract de vânzare": "sale",
        "mortgage": "mortgage", "ipoteca": "mortgage", "ipotecă": "mortgage", "refinantare": "mortgage", "refinanțare": "mortgage",
    }
    result: list[str] = []
    for item in raw:
        key = str(item).strip().lower()
        mapped = aliases.get(key, key)
        if mapped not in result:
            result.append(mapped)
    return result


_PARTY_ALIASES = {
    "buyer": "buyer", "cumparator": "buyer", "cumpărător": "buyer", "cumparatorul": "buyer", "cumpărătorul": "buyer", "solicitant": "buyer", "debitor": "buyer",
    "promitent-cumparator": "buyer", "promitent-cumpărător": "buyer", "client": "buyer",
    "seller": "seller", "vanzator": "seller", "vânzător": "seller", "vanzatorul": "seller", "vânzătorul": "seller",
    "promitent-vanzator": "seller", "promitent-vânzător": "seller",
}


def _party_value(value: Any, field: str) -> Optional[str]:
    """am.169 (V4.20): partea (buyer/seller) din aliasurile românești; invalid → INVALID_PARTY (fail-closed)."""
    if value is None or str(value).strip() == "":
        return None
    mapped = _PARTY_ALIASES.get(str(value).strip().lower())
    if mapped is None:
        raise OrchestratorError("INVALID_PARTY", f"{field} trebuie să fie vanzator/cumparator (seller/buyer).", {"provided": value})
    return mapped


def _quantity(value: Any, field: str) -> int:
    d = _decimal(value, field)
    if d != d.to_integral_value():
        raise OrchestratorError("INVALID_QUANTITY", f"Cantitatea trebuie să fie întreagă: {field}.")
    return int(d)


def normalize_case(case: Mapping[str, Any]) -> Dict[str, Any]:
    """Normalize a compact case envelope without changing canonical formulas."""
    raw_acts = _first(case, "acts", "acte", "operations")
    if isinstance(raw_acts, str):
        raw_acts = [part.strip() for part in raw_acts.replace("+", ",").split(",") if part.strip()]
    if not isinstance(raw_acts, list) or not raw_acts:
        raise OrchestratorError("MISSING_ACTS", "Lipsesc actele speței.")
    acts = [_act(v) for v in raw_acts]

    currency = str(_first(case, "currency", "moneda", default="EUR")).strip().upper()
    normalized: Dict[str, Any] = {
        "acts": acts,
        "buyer_type": _person(_first(case, "buyer_type", "cumparator_tip", "promitent_cumparator_tip", "debtor_type")),
        "seller_type": _person(_first(case, "seller_type", "vanzator_tip", "promitent_vanzator_tip")),
        "client": _first(case, "client", "client_name", "nume_client", default="—") or "—",
        "broker": _first(case, "broker", "intermediar", "agent", "agent_name", default="—") or "—",
        "currency": currency,
    }
    buyer_name = _first(
        case,
        "buyer_name", "cumparator_nume", "nume_cumparator",
        "promitent_buyer_name", "promitent_cumparator_nume",
        "debtor_name", "debitor_nume", "constituitor_name", "constituitor_nume",
    )
    seller_name = _first(
        case,
        "seller_name", "vanzator_nume", "nume_vanzator",
        "promitent_seller_name", "promitent_vanzator_nume",
    )
    if buyer_name not in (None, "", "—", "-"):
        normalized["buyer_name"] = str(buyer_name).strip()
    if seller_name not in (None, "", "—", "-"):
        normalized["seller_name"] = str(seller_name).strip()

    for target, aliases in {
        "price": ("price", "pret", "pret_imobil"),
        "advance": ("advance", "avans", "suma_antecontract"),
        "own_funds": ("own_funds", "surse_proprii"),
        "credit": ("credit", "credit_ipotecar", "valoare_credit"),
    }.items():
        value = _first(case, *aliases)
        if value is not None:
            normalized[target] = value

    # Financing percentages are accepted only when price is known and percentages are coherent.
    own_pct = _first(case, "own_funds_percent", "procent_surse_proprii")
    credit_pct = _first(case, "credit_percent", "procent_credit")
    if own_pct is not None or credit_pct is not None:
        if "price" not in normalized:
            raise OrchestratorError("MISSING_PRICE", "Procentele de finanțare necesită prețul.")
        price = _decimal(normalized["price"], "price")
        own = _decimal(own_pct if own_pct is not None else Decimal("100") - _decimal(credit_pct, "credit_percent"), "own_funds_percent")
        credit = _decimal(credit_pct if credit_pct is not None else Decimal("100") - own, "credit_percent")
        if own + credit != Decimal("100"):
            raise OrchestratorError("FINANCING_PERCENT_MISMATCH", "Procentele surse proprii + credit trebuie să fie 100%.")
        normalized["own_funds"] = format(price * own / Decimal("100"), "f")
        normalized["credit"] = format(price * credit / Decimal("100"), "f")

    advance_from_own = _bool(_first(case, "advance_equals_own_funds_confirmed", "avans_egal_surse_proprii", "advance_from_own_funds"))
    if advance_from_own is True:
        normalized["advance_equals_own_funds_confirmed"] = True
        if "advance" in normalized and "own_funds" not in normalized:
            normalized["own_funds"] = normalized["advance"]
        elif "own_funds" in normalized and "advance" not in normalized:
            normalized["advance"] = normalized["own_funds"]
    elif advance_from_own is False:
        normalized["advance_equals_own_funds_confirmed"] = False

    # A directly stated payment at antecontract is the advance; no second confirmation is needed.
    if "antecontract" in acts and "advance" in normalized:
        if "own_funds" in normalized and _decimal(normalized["advance"], "advance") == _decimal(normalized["own_funds"], "own_funds"):
            normalized["advance_equals_own_funds_confirmed"] = True

    seller_tax = _first(case, "seller_tax_percent", "impozit_vanzator", "cota_impozit")
    held_over_three = _bool(_first(
        case,
        "seller_owned_more_than_3_years",
        "seller_held_more_than_3_years",
        "dobandit_peste_3_ani",
        "detinut_peste_3_ani",
    ))
    # am.282 (V3.13): impozitul PE COTE — lista cotelor cu procentul fiecareia (R-IMPOZIT-MIXT-COTE)
    seller_shares = _first(case, "seller_tax_shares", "impozit_cote", "cote_impozit", "impozit_pe_cote")
    if seller_shares is not None:
        if not isinstance(seller_shares, list) or not seller_shares:
            raise OrchestratorError("INVALID_TAX_SHARES", "Impozitul pe cote trebuie să fie o listă nevidă de cote {cota, tax_percent}.")
        if seller_tax is not None:
            # conflictul il declara MOTORUL (TAX_SHARES_CONFLICT) — orchestratorul doar transmite ambele campuri, fail-closed in motor
            normalized["seller_tax_percent"] = int(_decimal(seller_tax, "seller_tax_percent"))
        _shares_norm = []
        for _i, _sh in enumerate(seller_shares):
            if not isinstance(_sh, Mapping):
                raise OrchestratorError("INVALID_TAX_SHARES", f"Cota {_i + 1} a impozitului nu este un obiect {{cota, tax_percent}}.")
            _cota = _first(_sh, "cota", "cote", "parte", "share")
            _pct = _first(_sh, "tax_percent", "procent", "impozit", "cota_impozit", "percent")
            if _cota is None or _pct is None:
                raise OrchestratorError("INVALID_TAX_SHARES", f"Cota {_i + 1} a impozitului: lipsește cota sau procentul.")
            _pct_txt = str(_pct).strip().replace("%", "")
            try:
                _pct_int = int(_decimal(_pct_txt, "seller_tax_shares.tax_percent"))
            except Exception as exc:
                raise OrchestratorError("INVALID_TAX_VARIANT", f"Cota {_i + 1}: procentul impozitului pe cotă poate fi numai 1 sau 3.") from exc
            _row = {"cota": str(_cota).strip(), "tax_percent": _pct_int}
            _lbl = _first(_sh, "label", "act", "titlu", "eticheta")
            if _lbl is not None:
                _row["label"] = str(_lbl)
            _shares_norm.append(_row)
        normalized["seller_tax_shares"] = _shares_norm
    elif seller_tax is not None:
        normalized["seller_tax_percent"] = int(_decimal(seller_tax, "seller_tax_percent"))
    elif normalized.get("seller_type") == "PF" and held_over_three is True:
        # Local M1-C01 normalization approved by the operator; not a CORE rule.
        normalized["seller_tax_percent"] = 1

    _uzu = _first(case, "usufruct_uplift", "uzufruct", "cu_uzufruct")
    if _uzu is None and isinstance(case.get("sale"), Mapping):
        _uzu = _first(case["sale"], "usufruct_uplift", "uzufruct")
    if _uzu is not None:
        if not isinstance(_uzu, bool):
            raise OrchestratorError("INVALID_USUFRUCT_FLAG", "usufruct_uplift trebuie sa fie boolean (true/false).")
        normalized["usufruct_uplift"] = _uzu

    increase_percent = _first(
        case,
        "honorarium_increase_percent",
        "majorare_onorariu_percent",
        "procent_majorare_onorariu",
    )
    raw_adjustment = _first(case, "honorarium_adjustment", "ajustare_onorariu")
    if isinstance(raw_adjustment, Mapping):
        if increase_percent is None:
            increase_percent = _first(raw_adjustment, "percent", "procent")
        raw_scope = _first(raw_adjustment, "scope", "acte")
    else:
        raw_scope = None
    # PATCH V4.20 (am.169): taxele suplimentare se citesc INDEPENDENT de scope-ul majorării (V3.10 le citea doar cand
    # raw_scope era None → NameError/ignorare cu majorare pe scope) + partea (parte: vanzator/cumparator → party buyer/seller)
    raw_af = _first(case, "additional_fees", "taxe_suplimentare")
    if raw_af:
        if not isinstance(raw_af, (list, tuple)):
            raise OrchestratorError("ADDITIONAL_FEE_INVALID", "Taxele suplimentare trebuie să fie o listă de obiecte.")
        _afs = []
        for _af in raw_af:
            if not isinstance(_af, Mapping):
                raise OrchestratorError("ADDITIONAL_FEE_INVALID", "Fiecare taxă suplimentară trebuie să fie un obiect (label, amount, quantity, parte).")
            _row = {"label": _first(_af, "label", "eticheta", "denumire"), "amount": _first(_af, "amount", "suma", "tarif")}
            _qty = _first(_af, "quantity", "cantitate", "bucati")
            if _qty is not None:
                _row["quantity"] = _quantity(_qty, "additional_fees.quantity")
            _pt = _party_value(_first(_af, "party", "parte", "in_sarcina"), "additional_fees.parte")
            if _pt is not None:
                _row["party"] = _pt
            _afs.append(_row)
        normalized["additional_fees"] = _afs
    raw_scope = _first(case, "honorarium_increase_scope", "majorare_onorariu_scope", "acte_majorate")
    # aliasuri de REDUCERE (am.174, V3.12): «scade onorariul cu 30%» / «reducere_onorariu_percent: 30» → percent -30
    _red = _first(case, "honorarium_reduction_percent", "reducere_onorariu_percent", "procent_reducere_onorariu",
                  "scade_onorariu_percent")
    if _red is not None:
        if increase_percent is not None:
            raise OrchestratorError("INVALID_HONORARIUM_ADJUSTMENT",
                                    "Majorarea și reducerea onorariului nu se pot cere simultan (am.174).")
        try:
            increase_percent = -abs(Decimal(str(_red)))
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise OrchestratorError("INVALID_NUMBER", "Valoare numerică invalidă: reducere_onorariu_percent.") from exc
        raw_scope = raw_scope if raw_scope is not None else _first(case, "reducere_onorariu_scope", "acte_reduse")
    if increase_percent is not None:
        # am.174 (V3.12): procentul ajustarii e SEMNAT — negativ = reducere; fail-closed la ≤ -100 (motorul re-verifica)
        try:
            pct = Decimal(str(increase_percent))
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise OrchestratorError("INVALID_NUMBER", "Valoare numerică invalidă: honorarium_increase_percent.") from exc
        if not pct.is_finite():
            raise OrchestratorError("INVALID_NUMBER", "Valoare numerică ne-finită: honorarium_increase_percent.")
        # poarta reducerii ≥100% ramane in MOTOR (signed_pct → INVALID_HONORARIUM_ADJUSTMENT), ca la gardele DEDUCTION_*
        scope = _scope_values(raw_scope)
        available = [act for act in ("sale", "mortgage", "antecontract", "opinion", "radiere") if act in acts]
        if not scope:
            if len(available) == 1:
                scope = available
            elif len(available) > 1:
                raise OrchestratorError(
                    "HONORARIUM_SCOPE_REQUIRED",
                    "Precizați actul căruia i se aplică ajustarea onorariului (mai multe acte în speță).",
                )
            else:
                raise OrchestratorError(
                    "HONORARIUM_SCOPE_NOT_APPLICABLE",
                    "Ajustarea onorariului cere un act în speță (sale/mortgage/antecontract/opinion/radiere — am.174).",
                )
        if any(item not in {"sale", "mortgage", "antecontract", "opinion", "radiere"} for item in scope):
            raise OrchestratorError("INVALID_HONORARIUM_SCOPE", "Scope-ul ajustării onorariului este invalid (sale/mortgage/antecontract/opinion/radiere — am.174).")
        if any(item not in acts for item in scope):
            raise OrchestratorError("HONORARIUM_SCOPE_NOT_IN_CASE", "Scope-ul majorării include un act absent din speță.")
        normalized["honorarium_adjustment"] = {"percent": format(pct, "f"), "scope": scope}

    raw_quantities = _first(case, "component_quantities", "cantitati_componente") or {}
    if not isinstance(raw_quantities, Mapping):
        raise OrchestratorError("INVALID_COMPONENT_QUANTITIES", "Cantitățile componentelor trebuie să fie un obiect.")
    aliases = {
        "opinion_information_extracts": ("opinion_information_extracts", "opinie_extrase_informare"),
        "opinion_notation_count": ("opinion_notation_count", "opinion_notations", "opinie_notari_carte_funciara", "opinie_notari_cf"),
        "antecontract_buyer_verifications": ("antecontract_buyer_verifications", "antecontract_verificari_cumparator"),
        "antecontract_notation_count": ("antecontract_notation_count", "antecontract_notations", "pv_notation_count", "pv_notari_carte_funciara", "antecontract_notari_cf"),
        "antecontract_seller_information_extracts": ("antecontract_seller_information_extracts", "antecontract_extrase_informare_vanzator"),
        "antecontract_seller_verifications": ("antecontract_seller_verifications", "antecontract_verificari_vanzator"),
        "sale_buyer_verifications": ("sale_buyer_verifications", "vanzare_verificari_cumparator"),
        "sale_seller_authentication_extracts": ("sale_seller_authentication_extracts", "vanzare_extrase_autentificare_vanzator"),
        "sale_seller_information_extracts": ("sale_seller_information_extracts", "vanzare_extrase_informare", "vanzare_extrase_informare_vanzator"),
        "sale_seller_verifications": ("sale_seller_verifications", "vanzare_verificari_vanzator"),
        "sale_notation_count": ("sale_notation_count", "sale_notations", "vanzare_notari_carte_funciara", "vanzare_notari_cf"),
        # PATCH V4.11 (25.08.2026, tichet radiere): cantitatile radierii erau ignorate silentios (fail-open) —
        # motorul (V1.17) si schema (V1.13) le cunosc, tabelul de aliasuri nu le avea.
        "radiere_information_extracts": ("radiere_information_extracts", "radiere_extrase_informare"),
        "radiere_notation_count": ("radiere_notation_count", "radiere_notations", "radiere_radieri_carte_funciara", "radiere_radieri_cf", "radiere_notari_cf", "radieri_cf"),
        "mortgage_bank_proxy_checks": ("mortgage_bank_proxy_checks", "ipoteca_verificari_procuri_bancare"),
        # PATCH V4.16 (am.133): serviciile universale — pe orice act (aliasuri românești)
        "service_proxy_checks": ('service_proxy_checks', 'verificari_procura', 'verificari_procuri', 'procura_verificari', 'verificare_procura'),
        "service_legalized_copy_pages": ('service_legalized_copy_pages', 'legalizari_pagini', 'copii_legalizate_pagini', 'pagini_legalizate', 'legalizare_pagini'),
        "service_information_extracts": ('service_information_extracts', 'extrase_informare', 'extras_informare'),
        "service_authentication_extracts": ('service_authentication_extracts', 'extrase_autentificare', 'extras_autentificare'),
        "service_person_verifications_pf": ('service_person_verifications_pf', 'verificari_pf', 'verificari_persoana_fizica'),
        "service_person_verifications_pj": ('service_person_verifications_pj', 'verificari_pj', 'verificari_recom'),
        "service_land_book_notations": ('service_land_book_notations', 'notari_cf', 'notari_carte_funciara', 'radieri_cf_servicii', 'notari_radieri_cf'),
        # PATCH V4.20 (am.169): radierea ca serviciu distinct pe orice act
        "service_land_book_radieri": ('service_land_book_radieri', 'radieri_cf_orice_act', 'radieri_carte_funciara', 'taxe_radiere_cf', 'radiere_cf_serviciu'),
        "mortgage_legalized_copies": ("mortgage_legalized_copies", "ipoteca_copii_legalizate"),
        "mortgage_buyer_verifications": ("mortgage_buyer_verifications", "ipoteca_verificari_debitor"),
        "mortgage_authentication_extracts": ("mortgage_authentication_extracts", "ipoteca_extrase_autentificare"),
        "mortgage_notation_count": ("mortgage_notation_count", "mortgage_notations", "ipoteca_notari_carte_funciara", "ipoteca_notari_cf", "taxe_notare_ipoteca"),
        "mortgage_additional_collateral_properties": (
            "mortgage_additional_collateral_properties",
            "ipoteca_imobile_suplimentare_in_garantie",
            "ipoteca_bunuri_suplimentare_in_garantie",
            "additional_collateral_properties",
        ),
    }
    # PATCH V4.20 (am.169, R-SERVICII-PE-VANZATOR): fiecare serviciu universal are geamanul _seller, alimentat din
    # cheia/aliasul obisnuit cu sufixul _vanzator / _seller / _vanzatorul (ex. verificari_procuri_vanzator: 2)
    for _sk in [k for k in aliases if k.startswith("service_")]:
        aliases[_sk + "_seller"] = tuple(a + suf for a in aliases[_sk] for suf in ("_seller", "_vanzator", "_vanzatorul", "_vânzător"))
    quantities: Dict[str, int] = {}
    for target, keys in aliases.items():
        value = _first(raw_quantities, *keys, default=_first(case, *keys))
        if value is not None:
            quantities[target] = _quantity(value, target)
    # Total collateral properties include the primary property already covered by the base 100 lei.
    total_collateral = _first(
        raw_quantities,
        "mortgage_total_collateral_properties",
        "ipoteca_total_imobile_in_garantie",
        "ipoteca_numar_total_imobile_garantie",
        "collateral_properties_total",
        default=_first(
            case,
            "mortgage_total_collateral_properties",
            "ipoteca_total_imobile_in_garantie",
            "ipoteca_numar_total_imobile_garantie",
            "collateral_properties_total",
        ),
    )
    if total_collateral is not None:
        if "mortgage" not in acts:
            raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Imobilele aduse în garanție sunt aplicabile numai ipotecii.")
        total_qty = _quantity(total_collateral, "mortgage_total_collateral_properties")
        derived_additional = max(total_qty - 1, 0)
        explicit_additional = quantities.get("mortgage_additional_collateral_properties")
        if explicit_additional is not None and explicit_additional != derived_additional:
            raise OrchestratorError(
                "COLLATERAL_PROPERTY_COUNT_CONFLICT",
                "Numărul total al imobilelor în garanție contrazice numărul imobilelor suplimentare.",
                {"total": total_qty, "additional": explicit_additional},
            )
        quantities["mortgage_additional_collateral_properties"] = derived_additional

    # Safe unscoped aliases are resolved only when the target is unambiguous.
    def set_quantity(target: str, value: Any, source: str) -> None:
        qty = _quantity(value, target)
        if target in quantities and quantities[target] != qty:
            raise OrchestratorError(
                "COMPONENT_QUANTITY_CONFLICT",
                f"Cantitatea pentru {target} este contradictorie.",
                {"existing": quantities[target], "incoming": qty, "source": source},
            )
        quantities[target] = qty

    generic_auth = _first(raw_quantities, "authentication_extracts", "extrase_autentificare", default=_first(case, "authentication_extracts", "extrase_autentificare"))
    if generic_auth is not None:
        target = "sale_seller_authentication_extracts" if "sale" in acts else "mortgage_authentication_extracts" if "mortgage" in acts else None
        if target is None:
            raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Extrasele de autentificare nu sunt aplicabile speței.")
        set_quantity(target, generic_auth, "authentication_extracts")

    # Generic «extrase de carte funciară» are routed deterministically by the acts.
    # Sale takes precedence in combined sale+mortgage cases because the final authentication
    # extract is charged to the seller and the mortgage branch deduplicates it.
    generic_land_extracts = _first(
        raw_quantities,
        "land_registry_extracts", "extrase_carte_funciara", "extrase_cf",
        default=_first(case, "land_registry_extracts", "extrase_carte_funciara", "extrase_cf"),
    )
    if generic_land_extracts is not None:
        extract_type_raw = _first(
            raw_quantities,
            "land_registry_extract_type", "tip_extrase_carte_funciara", "tip_extrase_cf",
            default=_first(case, "land_registry_extract_type", "tip_extrase_carte_funciara", "tip_extrase_cf"),
        )
        extract_scope_raw = _first(
            raw_quantities,
            "land_registry_extract_scope", "act_extrase_carte_funciara", "scope_extrase_cf",
            default=_first(case, "land_registry_extract_scope", "act_extrase_carte_funciara", "scope_extrase_cf"),
        )
        type_aliases = {
            "authentication": "authentication", "autentificare": "authentication", "auth": "authentication",
            "information": "information", "informare": "information", "info": "information",
        }
        scope_aliases = {
            "opinion": "opinion", "opinie": "opinion",
            "antecontract": "antecontract", "p-v": "antecontract", "pv": "antecontract", "promisiune": "antecontract",
            "sale": "sale", "vanzare": "sale", "vânzare": "sale", "cvc": "sale",
            "mortgage": "mortgage", "ipoteca": "mortgage", "ipotecă": "mortgage", "ip": "mortgage",
        }
        extract_type = type_aliases.get(str(extract_type_raw).strip().lower()) if extract_type_raw is not None else None
        extract_scope = scope_aliases.get(str(extract_scope_raw).strip().lower()) if extract_scope_raw is not None else None
        if extract_type_raw is not None and extract_type is None:
            raise OrchestratorError("INVALID_EXTRACT_TYPE", "Tipul extraselor trebuie să fie autentificare sau informare.")
        if extract_scope_raw is not None and extract_scope is None:
            raise OrchestratorError("INVALID_EXTRACT_SCOPE", "Actul extraselor de carte funciară este invalid.")
        if extract_scope is not None and extract_scope not in acts:
            raise OrchestratorError("COMPONENT_SCOPE_NOT_IN_CASE", "Actul indicat pentru extrase nu există în speță.")

        target: Optional[str] = None
        if extract_scope == "sale":
            if extract_type == "information":
                raise OrchestratorError("EXTRACT_TYPE_SCOPE_CONFLICT", "Vânzarea utilizează extrase de autentificare.")
            target = "sale_seller_authentication_extracts"
        elif extract_scope == "mortgage":
            if extract_type == "information":
                raise OrchestratorError("EXTRACT_TYPE_SCOPE_CONFLICT", "Ipoteca utilizează extrase de autentificare.")
            target = "mortgage_authentication_extracts"
        elif extract_scope == "opinion":
            if extract_type == "authentication":
                raise OrchestratorError("EXTRACT_TYPE_SCOPE_CONFLICT", "Opinia utilizează extrase de informare.")
            target = "opinion_information_extracts"
        elif extract_scope == "antecontract":
            if extract_type == "authentication":
                raise OrchestratorError("EXTRACT_TYPE_SCOPE_CONFLICT", "Promisiunea de vânzare utilizează extrase de informare.")
            target = "antecontract_seller_information_extracts"
        elif extract_type == "authentication":
            target = "sale_seller_authentication_extracts" if "sale" in acts else "mortgage_authentication_extracts" if "mortgage" in acts else None
            if target is None:
                raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Nu există un act care utilizează extrase de autentificare.")
        elif extract_type == "information":
            # PATCH V4.2 (decizia titularului 13.08.2026): informarea este permisa
            # si la vanzare (ex. radierea unei servituti de trecere).
            info_targets = []
            if "sale" in acts:
                info_targets.append("sale_seller_information_extracts")
            if "opinion" in acts:
                info_targets.append("opinion_information_extracts")
            if "antecontract" in acts:
                info_targets.append("antecontract_seller_information_extracts")
            if "radiere" in acts:
                info_targets.append("radiere_information_extracts")  # PATCH V4.11
            if len(info_targets) != 1:
                raise OrchestratorError("COMPONENT_SCOPE_REQUIRED", "Precizați cărui act îi aparțin extrasele de informare (vânzare / opinie / promisiune).")
            target = info_targets[0]
        else:
            if "sale" in acts:
                target = "sale_seller_authentication_extracts"
            elif "mortgage" in acts:
                target = "mortgage_authentication_extracts"
            elif "opinion" in acts and "antecontract" not in acts:
                target = "opinion_information_extracts"
            elif "antecontract" in acts and "opinion" not in acts:
                target = "antecontract_seller_information_extracts"
            elif "opinion" in acts and "antecontract" in acts:
                raise OrchestratorError("COMPONENT_SCOPE_REQUIRED", "Precizați dacă extrasele de carte funciară aparțin opiniei sau promisiunii de vânzare.")
            elif "radiere" in acts:
                target = "radiere_information_extracts"  # PATCH V4.11
            else:
                raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Extrasele de carte funciară nu sunt aplicabile speței.")
        set_quantity(target, generic_land_extracts, "land_registry_extracts")

    # Generic land-book notation fee (75 lei/unit) is available on every act branch.
    generic_notations = _first(
        raw_quantities,
        "land_book_notation_count", "notari_carte_funciara", "notari_cf", "numar_notari", "taxe_notare_cf",
        default=_first(case, "land_book_notation_count", "notari_carte_funciara", "notari_cf", "numar_notari", "taxe_notare_cf"),
    )
    if generic_notations is not None:
        # PATCH V4.25 (am.367): `notari_cf` / `notari_carte_funciara` erau SI alias al serviciului universal
        # `service_land_book_notations` (am.133), SI alias al notarii generice pe act (V4.11) -> aceeasi cantitate
        # intra de doua ori in total (5 notari = 750 in loc de 375). Notarea generica pe act castiga; serviciul
        # universal ramane doar pe cheile lui proprii (`service_land_book_notations`, `notari_radieri_cf`, `radieri_cf_servicii`).
        _coliziune_am367 = ("notari_cf", "notari_carte_funciara")
        _explicit_service_keys = ("service_land_book_notations", "radieri_cf_servicii", "notari_radieri_cf")
        if "service_land_book_notations" in quantities and _first(raw_quantities, *_explicit_service_keys, default=_first(case, *_explicit_service_keys)) is None \
                and _first(raw_quantities, *_coliziune_am367, default=_first(case, *_coliziune_am367)) is not None:
            quantities.pop("service_land_book_notations")
        notation_scope_raw = _first(
            raw_quantities,
            "land_book_notation_scope", "act_notari_carte_funciara", "scope_notari_cf",
            default=_first(case, "land_book_notation_scope", "act_notari_carte_funciara", "scope_notari_cf"),
        )
        notation_scope_aliases = {
            "opinion": "opinion", "opinie": "opinion", "op": "opinion",
            "antecontract": "antecontract", "p-v": "antecontract", "pv": "antecontract", "promisiune": "antecontract",
            "sale": "sale", "vanzare": "sale", "vânzare": "sale", "cvc": "sale",
            "mortgage": "mortgage", "ipoteca": "mortgage", "ipotecă": "mortgage", "ip": "mortgage",
            "radiere": "radiere", "declaratie_radiere": "radiere", "declarație_radiere": "radiere",  # PATCH V4.11
            "all": "all_present_acts", "toate": "all_present_acts", "fiecare": "all_present_acts",
            "all_present_acts": "all_present_acts", "toate_actele": "all_present_acts",
        }
        notation_scope = notation_scope_aliases.get(str(notation_scope_raw).strip().lower()) if notation_scope_raw is not None else None
        if notation_scope_raw is not None and notation_scope is None:
            raise OrchestratorError("INVALID_NOTATION_SCOPE", "Actul notării în cartea funciară este invalid.")
        target_by_act = {
            "opinion": "opinion_notation_count",
            "antecontract": "antecontract_notation_count",
            "sale": "sale_notation_count",
            "mortgage": "mortgage_notation_count",
            "radiere": "radiere_notation_count",  # PATCH V4.11
        }
        if notation_scope == "all_present_acts":
            for act in acts:
                set_quantity(target_by_act[act], generic_notations, "land_book_notation_count:all_present_acts")
        else:
            if notation_scope is not None:
                if notation_scope not in acts:
                    raise OrchestratorError("COMPONENT_SCOPE_NOT_IN_CASE", "Actul indicat pentru notare nu există în speță.")
                notation_target = target_by_act[notation_scope]
            elif len(acts) == 1:
                notation_target = target_by_act[acts[0]]
            else:
                raise OrchestratorError(
                    "COMPONENT_SCOPE_REQUIRED",
                    "Precizați actul pentru taxa de notare de 75 lei: opinie, P-V, vânzare, ipotecă sau toate actele prezente.",
                )
            set_quantity(notation_target, generic_notations, "land_book_notation_count")

    generic_legal = _first(raw_quantities, "legalized_copies", "copii_legalizate", default=_first(case, "legalized_copies", "copii_legalizate"))
    if generic_legal is not None:
        if "mortgage" not in acts:
            raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Copiile legalizate sunt configurabile în ramura ipotecii.")
        quantities["mortgage_legalized_copies"] = _quantity(generic_legal, "mortgage_legalized_copies")
    generic_info = _first(raw_quantities, "information_extracts", "extrase_informare", default=_first(case, "information_extracts", "extrase_informare"))
    if generic_info is not None:
        targets = []
        if "opinion" in acts:
            targets.append("opinion_information_extracts")
        if "antecontract" in acts:
            targets.append("antecontract_seller_information_extracts")
        if len(targets) != 1:
            raise OrchestratorError("COMPONENT_SCOPE_REQUIRED", "Precizați dacă extrasele de informare aparțin opiniei sau antecontractului.")
        quantities[targets[0]] = _quantity(generic_info, targets[0])
    generic_marital = _first(raw_quantities, "marital_regime_checks", "verificari_regim_matrimonial", default=_first(case, "marital_regime_checks", "verificari_regim_matrimonial"))
    # PATCH V4.25 (am.367, R-VERIFICARI-TOTAL-VANZARE, titular 09.09.2026 «2 verificari regim matrimonial» = 2 in total):
    # pe VANZARE cu cumparator PF, `verificari_pf` / `verificari_persoana_fizica` (serviciul universal am.133) insemna
    # «N in plus fata de verificarea de baza» si iesea ca a doua linie «Verificari in registrele notariale» -> 1 cerut = 1
    # (parea pierduta), 2 cerute = 3. De acum numarul dat de operator pe vanzare e TOTALUL verificarilor cumparatorului
    # (ambele aliasuri), o singura linie in oferta. Cheia canonica `service_person_verifications_pf` ramane serviciu
    # (in plus), pentru cine o cere explicit. Pe alte acte nimic nu se schimba.
    _vpf_keys_am367 = ("verificari_pf", "verificari_persoana_fizica")
    _vpf_raw_am367 = _first(raw_quantities, *_vpf_keys_am367, default=_first(case, *_vpf_keys_am367))
    if _vpf_raw_am367 is not None and "sale" in acts and normalized.get("buyer_type") == "PF" \
            and _first(raw_quantities, "service_person_verifications_pf", default=_first(case, "service_person_verifications_pf")) is None:
        if generic_marital is not None and _quantity(generic_marital, "sale_buyer_verifications") != _quantity(_vpf_raw_am367, "sale_buyer_verifications"):
            raise OrchestratorError("VERIFICATION_COUNT_CONFLICT", "Verificarile de regim matrimonial ale cumparatorului au fost date de doua ori, cu numere diferite.")
        generic_marital = _vpf_raw_am367
        quantities.pop("service_person_verifications_pf", None)
        if _quantity(generic_marital, "sale_buyer_verifications") < 1:
            raise OrchestratorError("INVALID_VERIFICATION_COUNT", "Pe vanzare numarul verificarilor cumparatorului e TOTALUL (minimum 1).")
    if generic_marital is not None:
        candidates = []
        if acts == ["mortgage"] and normalized.get("buyer_type") == "PF":
            candidates.append("mortgage_buyer_verifications")
        elif acts == ["antecontract"]:
            if normalized.get("buyer_type") == "PF": candidates.append("antecontract_buyer_verifications")
            if normalized.get("seller_type") == "PF": candidates.append("antecontract_seller_verifications")
        elif "sale" in acts:
            if normalized.get("buyer_type") == "PF": candidates.append("sale_buyer_verifications")
            if normalized.get("seller_type") == "PF": candidates.append("sale_seller_verifications")
        if len(candidates) != 1:
            raise OrchestratorError("COMPONENT_SCOPE_REQUIRED", "Precizați partea/actul pentru verificările de regim matrimonial.")
        quantities[candidates[0]] = _quantity(generic_marital, candidates[0])
    notation_fields = {
        "opinion_notation_count": ("opinion", "Notările opiniei sunt aplicabile numai opiniei notariale."),
        "antecontract_notation_count": ("antecontract", "Notările P-V sunt aplicabile numai P-V/antecontractului."),
        "sale_notation_count": ("sale", "Notările vânzării sunt aplicabile numai contractului de vânzare."),
        "mortgage_notation_count": ("mortgage", "Notările ipotecii sunt aplicabile numai contractului de ipotecă."),
        "radiere_notation_count": ("radiere", "Radierile din cartea funciară sunt aplicabile numai declarației de radiere."),  # PATCH V4.11
        "radiere_information_extracts": ("radiere", "Extrasele de informare ale radierii sunt aplicabile numai declarației de radiere."),  # PATCH V4.11
    }
    for field, (act, message) in notation_fields.items():
        if field in quantities and act not in acts:
            raise OrchestratorError("COMPONENT_NOT_IN_CASE", message)
    if quantities:
        normalized["component_quantities"] = quantities

    fx = _first(case, "fx", "curs") or {}
    if not isinstance(fx, Mapping):
        raise OrchestratorError("INVALID_FX", "Câmpul fx/curs trebuie să fie un obiect.")
    if currency == "EUR":
        rate = _first(fx, "rate", "rata", default=_first(case, "fx_rate", "curs_valutar"))
        publication = _first(fx, "publication_date", "data_publicarii", default=_first(case, "fx_publication_date", "data_publicare_curs"))
        effective = _first(fx, "effective_date", "data_aplicarii", default=_first(case, "fx_effective_date", "data_calculului"))
        source = _first(fx, "source", "sursa", default=_first(case, "fx_source", "sursa_curs"))
        if rate is None:
            raise OrchestratorError(
                "MISSING_FX_RATE",
                "Lipsește cursul valutar verificat. Furnizați un override al operatorului sau FX_EVIDENCE verificat.",
            )
        if not publication or not effective or not source:
            raise OrchestratorError("MISSING_FX_METADATA", "Metadatele cursului sunt incomplete.")
        _decimal(rate, "fx.rate")
        normalized["fx"] = {
            "rate": rate,
            "publication_date": str(publication),
            "effective_date": str(effective),
            "source": str(source),
            "operator_override": _bool(_first(fx, "operator_override", default=_first(case, "operator_override"))) is True,
        }
    elif currency == "RON":
        normalized["fx"] = {"rate": 1, "publication_date": "N/A", "effective_date": "N/A", "source": "RON"}

    if _bool(_first(case, "finalization_requested", "finalizare_solicitata")) is True:
        normalized["finalization_requested"] = True

    # PATCH V4.18 (am.164): deducerea onorariului antecontractului din onorariul vânzării poate fi oprită la comanda operatorului
    _ded = _first(case, "deduct_antecontract_honorarium", "scade_antecontract", "deducere_antecontract", "scade_onorariu_antecontract")
    _no_ded = _first(case, "fara_scadere_antecontract", "fara_deducere_antecontract", "nu_scade_antecontractul")
    if _no_ded is not None and _bool(_no_ded) is True:
        normalized["deduct_antecontract_honorarium"] = False
    elif _ded is not None:
        if _bool(_ded) is None:
            raise OrchestratorError("INVALID_DEDUCTION_FLAG", "deduct_antecontract_honorarium trebuie sa fie boolean (true/false).")
        normalized["deduct_antecontract_honorarium"] = _bool(_ded)
    else:
        normalized["deduct_antecontract_honorarium"] = True
    # PATCH V4.20 (am.169, titular 29.08.2026 «1.da … 5.ambele 6.da 7.da 8.da tariful existent 6.05»):
    # (a) comutatorul global al serviciilor (servicii_parte: vanzator) — implicit buyer; (b) radierea in sarcina vanzatorului;
    # (c) R-PROMISIUNE-EXTERNA: «scade-mi promisiunea 700 lei din onorariu» — suma NETA; varianta _brut extrage TVA 21%.
    _sp = _party_value(_first(case, "services_party", "servicii_parte", "parte_servicii", "servicii_in_sarcina"), "services_party")
    if _sp is not None:
        normalized["services_party"] = _sp
    _rp = _party_value(_first(case, "radiere_party", "radiere_parte", "radiere_in_sarcina"), "radiere_party")
    if _rp is not None:
        normalized["radiere_party"] = _rp
    _ext_net = _first(case, "external_antecontract_honorarium_net", "scade_promisiune", "scade_promisiunea", "promisiune_externa",
                      "onorariu_promisiune_extern", "promisiune_scazuta", "scade_antecontract_extern", "onorariu_antecontract_extern")
    _ext_gross = _first(case, "external_antecontract_honorarium_gross", "scade_promisiune_brut", "scade_promisiunea_brut", "promisiune_externa_brut",
                        "onorariu_promisiune_extern_brut", "promisiune_scazuta_cu_tva")
    if _ext_net is not None and _ext_gross is not None:
        raise OrchestratorError("EXTERNAL_DEDUCTION_CONFLICT", "Promisiunea externă se dă o singură dată: net SAU brut, nu ambele.")
    if _ext_net is not None:
        normalized["external_antecontract_honorarium_net"] = format(_decimal(_ext_net, "external_antecontract_honorarium_net").quantize(Decimal("0.01")), "f")
    elif _ext_gross is not None:
        _g = _decimal(_ext_gross, "external_antecontract_honorarium_gross")
        normalized["external_antecontract_honorarium_net"] = format((_g / Decimal("1.21")).quantize(Decimal("0.01")), "f")
        normalized["external_antecontract_honorarium_gross_declared"] = format(_g.quantize(Decimal("0.01")), "f")
    # PATCH V4.17 (am.135): oferta individuală pe parte — livrarea, nu calculul
    offer_for, include_broker = _offer_scope_request(case)
    normalized["offer_for"] = offer_for
    normalized["include_broker"] = include_broker
    normalized["offer_format"] = _offer_format_request(case)  # PATCH V4.25 (am.367, R-FORMAT-OFERTA)
    normalized["email_format"] = _email_format_request(case)  # am.388: e-mail complet implicit, scurt la cerere
    # PATCH V4.25 (am.367, R-ANCPI-ROTUNJIRE-SUS): implicit ceil; `ancpi_rounding: floor` (alias rotunjire_ancpi: trunchiat)
    # numai pentru etaloanele inghetate (R-71) — orice alta valoare cade fail-closed
    _ar = _first(case, "ancpi_rounding", "rotunjire_ancpi")
    if _ar is not None:
        _arv = {"floor": "floor", "trunchiat": "floor", "trunchiere": "floor", "jos": "floor", "ceil": "ceil", "sus": "ceil", "rotunjit": "ceil"}.get(str(_ar).strip().lower())
        if _arv is None:
            raise OrchestratorError("INVALID_ANCPI_ROUNDING", "ancpi_rounding trebuie sa fie ceil (implicit) sau floor (numai pe etaloane inghetate).", {"value": _ar})
        normalized["ancpi_rounding"] = _arv
    # am.399 (V4.29): baza fara TVA la cererea operatorului — dupa procentele de finantare (acestea raman pe pretul declarat)
    _am399 = _pret_tva_am399(case)
    if _am399["baza_fara_tva"]:
        if "price" not in normalized:
            raise OrchestratorError("MISSING_PRICE", "Baza fara TVA necesita pretul.")
        normalized["price"] = _am399_baza(_decimal(normalized["price"], "price"), _am399["cota"])
    elif _am399["pret_tva"] is not None and "price" not in normalized:
        raise OrchestratorError("MISSING_PRICE", "Mentiunea TVA a pretului necesita pretul.")

    return normalized


OFFER_SCOPES = ("both", "buyer", "seller", "split")
OFFER_PARTY_SUFFIX = {"buyer": "CUMPARATOR", "seller": "VANZATOR"}
_OFFER_FOR_ALIASES = {
    "both": "both", "ambele": "both", "ambii": "both", "comun": "both", "comuna": "both", "comună": "both", "toti": "both", "toți": "both",
    "buyer": "buyer", "cumparator": "buyer", "cumpărător": "buyer", "cumparatorul": "buyer", "cumpărătorul": "buyer",
    "promitent-cumparator": "buyer", "promitent-cumpărător": "buyer", "debitor": "buyer", "solicitant": "buyer",
    "seller": "seller", "vanzator": "seller", "vânzător": "seller", "vanzatorul": "seller", "vânzătorul": "seller",
    "promitent-vanzator": "seller", "promitent-vânzător": "seller",
    "split": "split", "separat": "split", "separate": "split", "individual": "split", "individuale": "split", "sparta": "split", "spartă": "split",
}


OFFER_FORMATS = ("scurt", "complet")
_OFFER_FORMAT_ALIASES = {
    "scurt": "scurt", "scurta": "scurt", "scurtă": "scurt", "short": "scurt", "minimal": "scurt", "minimalist": "scurt",
    "minimalista": "scurt", "minimalistă": "scurt", "simplu": "scurt", "simpla": "scurt", "simplă": "scurt", "rezumat": "scurt",
    "complet": "complet", "completa": "complet", "completă": "complet", "full": "complet", "detaliat": "complet",
    "detaliata": "complet", "detaliată": "complet", "extins": "complet", "extinsa": "complet", "extinsă": "complet", "lung": "complet",
}


def _offer_format_request(case: Mapping[str, Any]) -> str:
    """PATCH V4.25 (am.367, R-FORMAT-OFERTA, titular 09.09.2026): «cand cerem un calcul, varianta scurta; cand spun
    "da-mi o varianta completa", oferta ca pana acum». `offer_format` ∈ {scurt (implicit), complet}; aliasuri de cheie:
    format_oferta / varianta / varianta_oferta (nu `format` = formatul de livrare). Valoare necunoscuta -> INVALID_OFFER_FORMAT (fail-closed).
    Calculul si oferta completa se produc INTOTDEAUNA (QA-ul ramane cel de pana acum); formatul decide doar ce se
    livreaza operatorului."""
    raw = _first(case, "offer_format", "format_oferta", "varianta", "varianta_oferta", "variantă")
    if raw is None:
        return "scurt"
    key = str(raw).strip().lower()
    fmt = _OFFER_FORMAT_ALIASES.get(key)
    if fmt is None:
        raise OrchestratorError("INVALID_OFFER_FORMAT", "offer_format trebuie sa fie scurt / complet (varianta scurta sau varianta completa).", {"value": raw})
    return fmt


_EMAIL_FORMAT_ALIASES = {
    "complet": "complet", "completa": "complet", "completă": "complet", "extins": "complet", "detaliat": "complet", "full": "complet",
    "scurt": "scurt", "scurta": "scurt", "scurtă": "scurt", "short": "scurt", "rezumat": "scurt",
}


_AM399_PRET_TVA_ALIASES = {
    "cu_tva_inclus": "CU_TVA_INCLUS", "cu tva inclus": "CU_TVA_INCLUS", "cu tva": "CU_TVA_INCLUS", "tva inclus": "CU_TVA_INCLUS",
    "fara_tva": "FARA_TVA", "fara tva": "FARA_TVA", "fără tva": "FARA_TVA", "fără_tva": "FARA_TVA",
}
_AM399_DA = {"da", "yes", "true", "1"}
_AM399_NU = {"nu", "no", "false", "0"}


def _pret_tva_am399(case: Mapping[str, Any]) -> Dict[str, Any]:
    """am.399 (LOT T57i-1, I-1 = a): mentiunea TVA a pretului o da operatorul. Chei: pret_tva / mentiune_tva / price_vat;
    baza_fara_tva / calcul_la_baza; cota_tva (implicit 21). Fail-closed: INVALID_PRET_TVA, INVALID_BAZA_FARA_TVA,
    PRET_TVA_BAZA_CONFLICT (baza fara TVA ceruta fara «cu TVA inclus»), INVALID_COTA_TVA."""
    raw = _first(case, "pret_tva", "mentiune_tva", "price_vat")
    pt = None
    if raw is not None:
        _k = str(raw).strip().lower()
        pt = _AM399_PRET_TVA_ALIASES.get(_k) or _AM399_PRET_TVA_ALIASES.get(_k.replace("_", " "))
        if pt is None:
            raise OrchestratorError("INVALID_PRET_TVA", "pret_tva trebuie sa fie CU_TVA_INCLUS («cu TVA inclus») sau FARA_TVA («fără TVA»).", {"value": raw})
    rb = _first(case, "baza_fara_tva", "calcul_la_baza")
    bft = False
    if rb is not None:
        v = str(rb).strip().lower()
        if v in _AM399_DA:
            bft = True
        elif v not in _AM399_NU:
            raise OrchestratorError("INVALID_BAZA_FARA_TVA", "baza_fara_tva trebuie sa fie da sau nu.", {"value": rb})
    if bft and pt != "CU_TVA_INCLUS":
        raise OrchestratorError("PRET_TVA_BAZA_CONFLICT", "Baza fara TVA se calculeaza numai din pretul cu TVA inclus (pret_tva: CU_TVA_INCLUS).", {"pret_tva": raw})
    rc = _first(case, "cota_tva")
    cota = Decimal("21")
    if rc is not None:
        try:
            cota = Decimal(str(rc).strip().replace(",", ".").rstrip("%"))
        except Exception:
            raise OrchestratorError("INVALID_COTA_TVA", "cota_tva trebuie sa fie un procent intre 0 si 100.", {"value": rc})
        if not (Decimal("0") < cota < Decimal("100")):
            raise OrchestratorError("INVALID_COTA_TVA", "cota_tva trebuie sa fie un procent intre 0 si 100.", {"value": rc})
    return {"pret_tva": pt, "baza_fara_tva": bft, "cota": cota,
            "mentiune": ("FARA_TVA" if bft else pt)}


def _am399_baza(total: Decimal, cota: Decimal) -> str:
    """Baza = total / (1 + cota), 2 zecimale — formula existenta a promisiunii brute (scade_promisiune_brut, V4.20)."""
    return format((total / (Decimal("1") + cota / Decimal("100"))).quantize(Decimal("0.01")), "f")


def _reprezentant_am465(case: Mapping[str, Any]) -> Dict[str, Any]:
    """am.465: cine a facut oferta. Fara raspuns -> intrebare de mijloc NEBLOCANTA, ca la am.399.

    Se accepta obiectul ({nr} sau {nume, telefon}) si numarul gol (reprezentant: 3). Lista se citeste din reguli,
    ca intrebarea sa creasca odata cu ea: o intrare noua nu cere amendament de unealta.
    """
    brut = _first(case, "reprezentant", "operator", "reprezentant_oferta", "operator_oferta")
    reg: Dict[str, Any] = {}
    try:
        for _p in sorted(Path(__file__).resolve().parent.glob("04_M1_C01_RULES_V*.json")):
            _d = json.loads(_p.read_text(encoding="utf-8"))
            if isinstance(_d.get("reprezentanti_birou_am465_v1"), dict):
                reg = _d["reprezentanti_birou_am465_v1"]
                break
    except Exception:
        reg = {}
    lista = list(reg.get("lista") or [])
    prefix = str(reg.get("prefix_international") or "+4")

    ales: Dict[str, Any] | None = None
    if isinstance(brut, Mapping):
        ales = {k: brut.get(k) for k in ("nr", "nume", "telefon") if brut.get(k) not in (None, "")}
    elif isinstance(brut, int) or (isinstance(brut, str) and brut.strip().isdigit()):
        ales = {"nr": int(str(brut).strip())}
    elif isinstance(brut, str) and brut.strip():
        potrivite = [x for x in lista
                     if str(x.get("nume", "")).strip().upper() == brut.strip().upper()]
        ales = {"nr": potrivite[0]["nr"]} if potrivite else {"nume": brut.strip()}
    if ales:
        nr = ales.get("nr")
        if nr is not None and not (ales.get("nume") and ales.get("telefon")):
            gasit = [x for x in lista if str(x.get("nr")) == str(nr)]
            if not gasit:
                raise OrchestratorError("INVALID_REPREZENTANT_AM465",
                                        "Numarul ales nu exista in lista reprezentantilor.",
                                        {"value": nr, "numere": [x.get("nr") for x in lista]})
            ales = {"nr": nr, "nume": gasit[0].get("nume"), "telefon": gasit[0].get("telefon")}
        if not str(ales.get("nume") or "").strip():
            raise OrchestratorError("INVALID_REPREZENTANT_AM465",
                                    "Optiunea libera cere numele si telefonul reprezentantului.", {"value": brut})
        return {"reprezentant_am465": ales}

    optiuni = [
        "%d. %s  %s%s" % (x.get("nr"), x.get("nume"), prefix, x.get("telefon"))
        for x in lista
    ]
    libera = reg.get("optiune_libera") or {}
    if libera:
        optiuni.append("%s. %s" % (libera.get("nr"), libera.get("eticheta")))
    return {
        "intrebare_mijloc_am465": {
            "cod": "AM465-REPREZENTANT-OFERTA", "blocheaza": False,
            # am.468: lista intra in TEXTUL intrebarii, nu doar in `optiuni`. Un sir separat ajunge intr-un selector de
            # raspuns cu numar FIX de variante si se taie tacut — masurat in Build: 8 intrari, 4 afisate, omul adaugat
            # in aceeasi zi nu se putea alege. Un text nu poate fi taiat de un widget.
            "intrebare": "Cine din birou a facut oferta? Alegeti un numar:\n" + "\n".join(optiuni),
            "optiuni": optiuni,
            "afisare": "TEXT_NUMEROTAT",
            "nu_folosi_selector": ("Lista se scrie ca TEXT numerotat, intreaga. NU se pune intr-un selector de raspuns "
                                   "cu numar limitat de variante: are %d intrari si se taie tacut." % len(optiuni)),
            "nume_verbatim": ("Numele se copiaza din registru EXACT cum sunt scrise — fara diacritice adaugate, fara "
                              "rescriere. Ele ajung in oferta si dau initialele din act."),
            "raspuns": "reprezentant: {\"nr\": <numarul ales>}  sau, pentru ultima optiune, reprezentant: {\"nume\": \"...\", \"telefon\": \"...\"}",
            "nota": ("Oferta de acum iese fara blocul reprezentantului (ca V4.32). Claude pune intrebarea INAINTE de livrare, in ambele oferte, si re-ruleaza cu raspunsul. Telefonul ajunge apelabil in PDF."),
        }
    }


def _am399_raport(case: Mapping[str, Any], normalized: Mapping[str, Any]) -> Dict[str, Any]:
    """Consemnarea in PIPELINE_RESULT — goala fara mentiune la vanzatorul PF (V4.28 bit-identic pe forma)."""
    a = _pret_tva_am399(case)
    out: Dict[str, Any] = {}
    if a["mentiune"] is not None:
        rec = {"mentiune": a["mentiune"], "pret_tva_declarat": a["pret_tva"], "baza_fara_tva": a["baza_fara_tva"]}
        if a["baza_fara_tva"]:
            rec.update({"cota_tva": format(a["cota"], "f"), "pret_total_declarat": str(_first(case, "price", "pret", "pret_imobil")),
                        "baza_trimisa": normalized.get("price")})
        out["pret_tva_am399"] = rec
    elif normalized.get("seller_type") == "PJ" and "sale" in (normalized.get("acts") or []):
        out["intrebare_mijloc_am399"] = {
            "cod": "AM399-PRET-TVA-PJ", "blocheaza": False,
            "intrebare": "Prețul poartă TVA? — cu TVA inclus / fără TVA / nu poartă TVA (taxare inversă, construcție veche, vânzător neplătitor)",
            "raspunsuri": {"cu TVA inclus": {"pret_tva": "CU_TVA_INCLUS"}, "fără TVA": {"pret_tva": "FARA_TVA"},
                           "nu poartă TVA": {}},
            "nota": "Oferta de acum e fără mențiune (ca V4.28). Claude pune întrebarea ÎNAINTE de livrare și re-rulează cu răspunsul."}
    return out


def _email_format_request(case: Mapping[str, Any]) -> str:
    """am.388 (LOT T56y-1, 1b): e-mailul livrat = cel COMPLET; cel scurt numai la cerere. Chei: email_format /
    format_mail / format_email / varianta_mail / mail. Valoare necunoscuta -> INVALID_EMAIL_FORMAT (fail-closed)."""
    raw = _first(case, "email_format", "format_mail", "format_email", "varianta_mail", "mail")
    if raw is None or str(raw).strip() == "":
        return "complet"
    fmt = _EMAIL_FORMAT_ALIASES.get(str(raw).strip().lower())
    if fmt is None:
        raise OrchestratorError("INVALID_EMAIL_FORMAT", "email_format trebuie sa fie complet (implicit) sau scurt.", {"value": raw})
    return fmt


def _offer_scope_request(case: Mapping[str, Any]) -> tuple[str, bool]:
    """`offer_for` ∈ {both, buyer, seller, split} (implicit both) + `include_broker` (implicit True)."""
    raw = _first(case, "offer_for", "oferta_pentru", "solicitant_oferta", "pentru", "oferta_scope")
    if raw is None or str(raw).strip() == "":
        scope = "both"
    else:
        scope = _OFFER_FOR_ALIASES.get(str(raw).strip().lower())
        if scope is None:
            raise OrchestratorError(
                "INVALID_OFFER_SCOPE",
                "offer_for trebuie să fie both / buyer / seller / split (ambele / cumpărător / vânzător / separat).",
                {"provided": raw},
            )
    broker_raw = _first(case, "include_broker", "broker_in_oferta", "include_intermediar", "cu_broker")
    include_broker = True if broker_raw is None else (_bool(broker_raw) is not False)
    return scope, include_broker




# am.482 (T61b, 22.09.2026; titularul: «A»): livrarea are PATRU fisiere — al patrulea e RULAREA (`rulare.json`,
# ENGINE_RESULT + NORMALIZED_CASE, format M1C01_RULARE_V1). Fara el, unealta de redactare rapida nu poate lega
# nicio suma in act (am.343: «nicio cifra fara rularea ei»), iar calculatorul nu-l dadea niciodata omului.
AM482_RULARE = "rulare_json"
AM482_RULARE_FORMAT = "M1C01_RULARE_V1"
AM388_LIVRARE_FIXA = ["pdf", "pdf_detaliat", "email_docx", AM482_RULARE]
AM483_ATASAMENT = "rulare.json"  # am.483: numele atasamentului din oferta detaliata


def _scrie_rulare_am482(run_dir: Path, run_id: str) -> Path:
    """am.482: fisierul rularii (ENGINE_RESULT + NORMALIZED_CASE, format M1C01_RULARE_V1), scris o data in run_dir."""
    _rulare_src = run_dir / "RULARE_M1-C01.json"
    _json_dump(_rulare_src, {
        "format": AM482_RULARE_FORMAT, "module": "M1-C01", "run_id": run_id,
        "engine_result": _load_json(run_dir / "ENGINE_RESULT.json"),
        "normalized_case": _load_json(run_dir / "NORMALIZED_CASE.json"),
        "nota": "am.482: fisierul rularii se urca in dosarul de redactare ca orice document; unealta rapida il "
                "recunoaste dupa format si scoate din el sumele, cu SHA-ul verificat (am.343). am.483: acelasi "
                "fisier sta si INAUNTRUL ofertei detaliate, ca atasament PDF.",
    })
    return _rulare_src


def _ataseaza_rularea_am483(pdf_path: Path, rulare_path: Path) -> None:
    """am.483: oferta detaliata poarta rularea inauntru (atasament PDF standard). Titularul, 22.09.2026: «oferta
    detaliata, cea care o puneam de obicei, sa contina aceasta rulare json». Se face INAINTE de masurarea artefactelor,
    ca SHA-ul intern, cel livrat si cel din manifest sa fie ale aceluiasi PDF. Pagina nu se schimba."""
    import pypdf  # dependenta existenta a generatorului (QA)
    _w = pypdf.PdfWriter(clone_from=str(pdf_path))
    _w.add_attachment(AM483_ATASAMENT, rulare_path.read_bytes())
    _tmp = pdf_path.with_suffix(".pdf.am483")
    with open(_tmp, "wb") as _fh:
        _w.write(_fh)
    _tmp.replace(pdf_path)


def _rularea_din_pdf_am483(pdf_path: Path) -> bytes | None:
    """am.483: atasamentul `rulare.json` al unui PDF, sau None. Read-only; folosit de suita si de unealta rapida."""
    try:
        import pypdf
        _att = pypdf.PdfReader(str(pdf_path)).attachments.get(AM483_ATASAMENT)
    except Exception:
        return None
    if not _att:
        return None
    return _att[0] if isinstance(_att, list) else _att


def _requested_formats(case: Mapping[str, Any]) -> tuple[list[str], bool]:
    """am.388: livrarea e mereu AM388_LIVRARE_FIXA; cererea operatorului se valideaza (valoare invalida = fail-closed,
    ca pana acum) si se consemneaza in `delivery_request.cerere_operator_am388`, fara efect pe livrare."""
    _cerut, _implicit = _requested_formats_operator(case)
    return list(AM388_LIVRARE_FIXA), _implicit


def _requested_formats_operator(case: Mapping[str, Any]) -> tuple[list[str], bool]:
    """Return user-facing formats. Internal generation remains DOCX + PDF."""
    raw = _first(
        case,
        "requested_formats",
        "delivery_formats",
        "formats",
        "format",
        "livrabile",
        "format_solicitat",
    )
    if raw is None:
        return ["docx", "pdf", "email_docx"], True
    if isinstance(raw, str):
        text = raw.strip().lower()
        if text in {"ambele", "both", "docx+pdf", "pdf+docx", "word si pdf", "word și pdf"}:
            raw_values = ["docx", "pdf"]
        else:
            raw_values = [part.strip() for part in text.replace("+", ",").replace("/", ",").split(",") if part.strip()]
    elif isinstance(raw, (list, tuple, set)):
        raw_values = list(raw)
    else:
        raw_values = [raw]

    aliases = {
        "docx": "docx", "word": "docx", "document word": "docx", ".docx": "docx",
        "pdf": "pdf", ".pdf": "pdf",
        # `email_docx` este valoarea canonică din Input Schema V1.7 și lipsea din
        # tabelul de aliasuri, deci o cerere conformă cu propria schemă era respinsă.
        "email_docx": "email_docx", "email": "email_docx", "email docx": "email_docx",
        "word email": "email_docx", "email_word": "email_docx", "emaildocx": "email_docx",
    }
    selected: list[str] = []
    for value in raw_values:
        key = str(value).strip().lower()
        fmt = aliases.get(key)
        if fmt and fmt not in selected:
            selected.append(fmt)
    if not selected:
        raise OrchestratorError(
            "INVALID_DELIVERY_FORMAT",
            "Formatul solicitat trebuie să fie DOCX, PDF și/sau Word-ul de e-mail.",
            {"provided": raw},
        )
    if "email_docx" not in selected:
        selected.append("email_docx")
    return selected, False




def _meaningful_text(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text in {"—", "-", "N/A", "n/a", "none", "None"}:
        return None
    return text


def _ascii_name(value: Any, *, max_len: int = 48) -> Optional[str]:
    text = _meaningful_text(value)
    if text is None:
        return None
    folded = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    folded = folded.upper().replace("&", " SI ")
    folded = re.sub(r"[^A-Z0-9]+", "-", folded).strip("-")
    folded = re.sub(r"-+", "-", folded)
    if not folded:
        return None
    return folded[:max_len].rstrip("-") or None


def _act_delivery_code(acts: Iterable[Any]) -> str:
    ordered = ("opinion", "antecontract", "sale", "mortgage")
    codes = {"opinion": "OP", "antecontract": "P-V", "sale": "CVC", "mortgage": "IP"}
    selected = {str(v) for v in acts}
    parts = [codes[act] for act in ordered if act in selected]
    return "-".join(parts) or "DOSAR"


def _delivery_identity(normalized: Mapping[str, Any]) -> str:
    client = _ascii_name(normalized.get("client"))
    if client:
        return client
    buyer = _ascii_name(normalized.get("buyer_name"))
    seller = _ascii_name(normalized.get("seller_name"))
    if buyer and seller:
        return buyer if buyer == seller else f"{buyer}-{seller}"
    if buyer:
        return buyer
    if seller:
        return seller
    broker = _ascii_name(normalized.get("broker"))
    if broker:
        return f"AG-{broker}"
    return "DOSAR"


def _delivery_slug(normalized: Mapping[str, Any]) -> str:
    """Human-readable stable stem. Run uniqueness is added separately."""
    act_code = _act_delivery_code(normalized.get("acts", []))
    identity = _delivery_identity(normalized)
    local_date = datetime.now(ZoneInfo("Europe/Bucharest")).strftime("%Y-%m-%d")
    return f"{act_code}_{identity}_{local_date}"


def _short_run_token(run_id: str) -> str:
    return hashlib.sha256(run_id.encode("utf-8")).hexdigest()[:6].upper()


def _public_delivery_base(delivery_stem: str, run_id: str) -> str:
    return f"{delivery_stem}_{_short_run_token(run_id)}"


def _party_type_variant_request(normalized: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
    """Return a controlled PF/PJ choice request without selecting a variant."""
    acts = set(normalized.get("acts", []))
    buyer_required = bool(acts.intersection({"antecontract", "sale", "mortgage"}))
    seller_required = bool(acts.intersection({"antecontract", "sale"}))

    missing: list[str] = []
    if buyer_required and normalized.get("buyer_type") not in {"PF", "PJ"}:
        missing.append("buyer_type")
    if seller_required and normalized.get("seller_type") not in {"PF", "PJ"}:
        missing.append("seller_type")
    if not missing:
        return None

    buyer_values = [normalized.get("buyer_type")] if "buyer_type" not in missing else ["PF", "PJ"]
    seller_values = [normalized.get("seller_type")] if "seller_type" not in missing else ["PF", "PJ"]
    if not seller_required:
        seller_values = [None]

    if acts == {"mortgage"}:
        buyer_role = "Debitor / constituitor"
    elif "antecontract" in acts and "sale" not in acts:
        buyer_role = "Promitent-cumpărător"
    else:
        buyer_role = "Cumpărător"
    seller_role = "Promitent-vânzător" if "antecontract" in acts and "sale" not in acts else "Vânzător"

    variants: list[Dict[str, Any]] = []
    for buyer in buyer_values:
        for seller in seller_values:
            option: Dict[str, Any] = {"buyer_type": buyer}
            labels = [f"{buyer_role}: {buyer}"]
            if seller_required:
                option["seller_type"] = seller
                labels.append(f"{seller_role}: {seller}")
            option["id"] = "_".join(v for v in (buyer, seller) if v)
            option["label"] = " / ".join(labels)
            variants.append(option)

    if missing == ["buyer_type"]:
        question = "Selectați tipul cumpărătorului/debitorului: PF sau PJ."
    elif missing == ["seller_type"]:
        question = "Selectați tipul vânzătorului: PF sau PJ."
    else:
        question = "Selectați combinația PF/PJ a cumpărătorului și vânzătorului."

    return {
        "status": "NECESITA_CLARIFICARE",
        "clarification_code": "PARTY_TYPE_VARIANTS_REQUIRED",
        "question": question,
        "missing_fields": missing,
        "variants": variants,
        "automatic_selection": False,
        "assumption_applied": False,
        "automatic_propagation": False,
        "human_approval_required": True,
    }


def _validate_fx_audit(
    case: Mapping[str, Any],
    fx_evidence_path: Optional[Path],
    fx_gate_result_path: Optional[Path],
) -> Dict[str, Any]:
    """Validate optional FX audit inputs and bind them to the current case.

    Backward compatibility: RON cases and legacy deterministic regression calls may
    omit these paths. For EUR cases using the active FX gate, Instructions V2.25
    require both files.
    """
    if fx_evidence_path is None and fx_gate_result_path is None:
        return {}
    if fx_evidence_path is None or fx_gate_result_path is None:
        raise OrchestratorError(
            "FX_AUDIT_PAIR_REQUIRED",
            "FX_EVIDENCE și FX_GATE_RESULT trebuie furnizate împreună.",
        )
    evidence = _load_json(fx_evidence_path)
    gate = _load_json(fx_gate_result_path)
    if gate.get("status") != "PASS":
        raise OrchestratorError(
            "FX_GATE_NOT_PASS",
            "Orchestratorul nu poate continua fără FX_GATE_RESULT.status=PASS.",
            {"gate_status": gate.get("status"), "error_code": gate.get("error_code")},
        )
    if evidence.get("status") not in {"VERIFIED", "NOT_APPLICABLE"}:
        raise OrchestratorError(
            "FX_EVIDENCE_NOT_VERIFIED",
            "FX_EVIDENCE nu este VERIFIED/NOT_APPLICABLE.",
            {"evidence_status": evidence.get("status")},
        )
    case_fx = case.get("fx") if isinstance(case.get("fx"), Mapping) else {}
    if str(case.get("currency", "EUR")).upper() != "RON":
        checks = {
            "rate": (case_fx.get("rate"), evidence.get("rate")),
            "publication_date": (case_fx.get("publication_date"), evidence.get("publication_date")),
            "effective_date": (case_fx.get("effective_date"), evidence.get("effective_date")),
            "source": (str(case_fx.get("source", "")).upper(), str(evidence.get("source", "")).upper()),
            "operator_override": (case_fx.get("operator_override"), evidence.get("operator_override")),
        }
        mismatches = {
            key: {"case": left, "evidence": right}
            for key, (left, right) in checks.items()
            if str(left) != str(right)
        }
        if mismatches:
            raise OrchestratorError(
                "FX_AUDIT_CASE_MISMATCH",
                "Metadatele FX din speță nu corespund dovezii validate.",
                mismatches,
            )
    return {"evidence": evidence, "gate": gate}


def _copy_run_bound_json(
    *,
    source: Path,
    run_dir: Path,
    output_dir: Path,
    delivery_stem: str,
    run_id: str,
    suffix: str,
) -> Dict[str, Any]:
    """Persist one JSON both inside the run directory and as a root run-bound copy."""
    run_destination = run_dir / f"{suffix}.json"
    if source.resolve() != run_destination.resolve():
        shutil.copy2(source, run_destination)
    root_destination = output_dir / f"{delivery_stem}_{run_id}_{suffix}.json"
    shutil.copy2(run_destination, root_destination)
    payload = _validate_artifact(root_destination)
    payload["run_path"] = str(run_destination)
    payload["run_id"] = run_id
    return payload


def _publish_success_audit(
    *,
    output_dir: Path,
    run_dir: Path,
    run_id: str,
    delivery_stem: str,
    sources: Mapping[str, Path],
) -> Dict[str, Any]:
    """Publish immutable root-level JSON audit copies for a successful run."""
    suffixes = {
        "case_snapshot": "CASE_SNAPSHOT",
        "normalized_case": "NORMALIZED_CASE",
        "engine_result": "ENGINE_RESULT",
        "qa_report": "RAPORT_QA_GENERATOR",
        "fx_evidence": "FX_EVIDENCE",
        "fx_gate_result": "FX_GATE_RESULT",
    }
    published: Dict[str, Any] = {}
    for key, source in sources.items():
        if key not in suffixes:
            continue
        published[key] = _copy_run_bound_json(
            source=source,
            run_dir=run_dir,
            output_dir=output_dir,
            delivery_stem=delivery_stem,
            run_id=run_id,
            suffix=suffixes[key],
        )
    published["pipeline_result"] = {
        "path": str(output_dir / f"{delivery_stem}_{run_id}_PIPELINE_RESULT.json"),
        "run_path": str(run_dir / "PIPELINE_RESULT.json"),
        "run_id": run_id,
    }
    return published


def _publish_delivery_artifacts(
    *,
    output_dir: Path,
    run_dir: Path,
    run_id: str,
    case_sha: str,
    requested_formats: list[str],
    delivery_stem: str,
    internal_artifacts: Mapping[str, Mapping[str, Any]],
    offer_for: str = "both",
    offer_format: str = "complet",
    email_format: str = "complet",
) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """AM388_LIVRARE (T56y) + am.482 (T61b): pe fiecare set de parte ies EXACT PATRU fisiere — cele trei de mai jos plus
    `rulare.json` (ENGINE_RESULT + NORMALIZED_CASE, format M1C01_RULARE_V1), care duce sumele in dosarul de redactare.
    Istoric: trei fisiere —
    oferta.pdf (PDF scurt), oferta_detaliata.pdf (PDF extins), oferta_mail.docx (e-mail complet; scurt la cerere).
    La split: doua seturi, sufix _cumparator / _vanzator (cheile *_seller dupa cele ale cumparatorului); o singura
    parte sau ambele = numele simple. Word-ul ofertei se genereaza intern (QA), nu se livreaza."""
    delivery: Dict[str, Any] = {}
    if offer_for == "split":
        party_sets = [("", AM388_SUFIX_SPLIT["buyer"], "buyer"), ("_seller", AM388_SUFIX_SPLIT["seller"], "seller")]
    elif offer_for in OFFER_PARTY_SUFFIX:
        party_sets = [("", "", offer_for)]
    else:
        party_sets = [("", "", "both")]
    _mail_key = "email_docx_scurt" if email_format == "scurt" else "email_docx"
    # am.482: fisierul rularii — ENGINE_RESULT + NORMALIZED_CASE, cu formatul declarat. Se scrie o data in run_dir,
    # apoi se copiaza ca orice livrabil (la split, acelasi continut sub ambele sufixe: calculul e comun).
    _rulare_src = _scrie_rulare_am482(run_dir, run_id)  # am.482 (scris deja inainte de atasare, am.483)
    for key_suffix, name_suffix, party in party_sets:
        source_by_format = {
            "pdf": Path(str(internal_artifacts["pdf_scurt" + key_suffix]["path"])),
            "pdf_detaliat": Path(str(internal_artifacts["pdf" + key_suffix]["path"])),
            "email_docx": Path(str(internal_artifacts[_mail_key + key_suffix]["path"])),
            AM482_RULARE: _rulare_src,
        }
        for fmt in AM388_LIVRARE_FIXA:
            source = source_by_format[fmt]
            destination = output_dir / f"{AM388_NUME_PUBLICE[fmt]}{name_suffix}.{AM388_EXTENSII[fmt]}"
            shutil.copy2(source, destination)
            key = fmt + key_suffix
            delivery[key] = _validate_artifact(destination)
            delivery[key]["source_path"] = str(source)
            delivery[key]["run_id"] = run_id
            delivery[key]["party"] = party

    manifest_payload: Dict[str, Any] = {
        "status": "READY_FOR_HUMAN_REVIEW",
        "run_id": run_id,
        "run_directory": str(run_dir),
        "case_sha256": case_sha,
        "requested_formats": requested_formats,
        "offer_for": offer_for,
        "offer_format": offer_format,
        "email_format": email_format,
        "delivery_artifacts": delivery,
        "internal_generation": ["docx", "pdf", "email_docx", "docx_scurt", "pdf_scurt", "email_docx_scurt"],
        "human_approval_required": True,
        "automatic_send": False,
        "automatic_propagation": False,
        "core_modified": False,
    }
    run_manifest = run_dir / "DELIVERY_MANIFEST.json"
    root_manifest = output_dir / f"M1C01_DELIVERY_MANIFEST_{run_id}.json"
    latest_manifest = output_dir / "M1C01_DELIVERY_LATEST.json"
    _json_dump(run_manifest, manifest_payload)
    _json_dump(root_manifest, manifest_payload)
    _json_dump(latest_manifest, manifest_payload)
    manifests = {
        "run": _validate_artifact(run_manifest),
        "root": _validate_artifact(root_manifest),
        "latest": _validate_artifact(latest_manifest),
    }
    return delivery, manifests



def _publish_fail_closed_audit(
    *,
    output_dir: Path,
    run_dir: Path,
    run_id: str,
    delivery_stem: str,
    sources: Mapping[str, Path],
) -> Dict[str, Any]:
    """Publish run-bound audit JSON files for a fail-closed execution."""
    published: Dict[str, Any] = {}
    suffixes = {
        "engine_result": "ENGINE_RESULT",
        "variant_request": "VARIANT_REQUEST",
        "case_snapshot": "CASE_SNAPSHOT",
        "normalized_case": "NORMALIZED_CASE",
    }
    for key, source in sources.items():
        suffix = suffixes[key]
        destination = output_dir / f"{delivery_stem}_{run_id}_{suffix}.json"
        shutil.copy2(source, destination)
        published[key] = _validate_artifact(destination)
        published[key]["source_path"] = str(source)
        published[key]["run_id"] = run_id
    # PIPELINE_RESULT is written after the final payload is assembled.
    published["pipeline_result"] = {
        "path": str(output_dir / f"{delivery_stem}_{run_id}_PIPELINE_RESULT.json"),
        "run_id": run_id,
    }
    return published

def _clean_outputs(output_dir: Path) -> None:
    for name in ARTIFACT_NAMES:
        path = output_dir / name
        if path.exists():
            if path.is_file() or path.is_symlink():
                path.unlink()
            else:
                shutil.rmtree(path)


def _validate_artifact(path: Path) -> Dict[str, Any]:
    if not path.is_file():
        raise OrchestratorError("DELIVERABLE_MISSING", f"Lipsește livrabilul {path.name}.")
    size = path.stat().st_size
    if size <= 0:
        raise OrchestratorError("DELIVERABLE_EMPTY", f"Livrabilul {path.name} este gol.")
    return {"path": str(path), "size": size, "sha256": _sha256(path)}


def run_pipeline(
    case: Mapping[str, Any],
    *,
    output_dir: Path,
    search_root: Path,
    engine_path: Optional[Path] = None,
    generator_path: Optional[Path] = None,
    input_path: Optional[Path] = None,
    fx_evidence_path: Optional[Path] = None,
    fx_gate_result_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Run one immutable case in a unique directory and publish only a pointer result at root."""
    output_dir.mkdir(parents=True, exist_ok=True)
    # Root-level aliases from older versions are removed so they cannot be attached as current outputs.
    _clean_outputs(output_dir)

    canonical = locate_canonical_files(search_root, engine_path, generator_path)
    requested_formats, delivery_defaulted = _requested_formats(case)
    normalized = normalize_case(case)
    delivery_stem = _delivery_slug(normalized)
    case_sha = _case_sha256(case)
    run_id = _new_run_id(case_sha)
    run_dir = output_dir / f"M1C01_RUN_{run_id}"
    run_dir.mkdir(parents=True, exist_ok=False)

    case_snapshot_path = run_dir / "CASE_SNAPSHOT.json"
    normalized_path = run_dir / "NORMALIZED_CASE.json"
    _json_dump(case_snapshot_path, dict(case))
    _json_dump(normalized_path, normalized)

    fx_audit = _validate_fx_audit(case, fx_evidence_path, fx_gate_result_path)
    fx_run_sources: Dict[str, Path] = {}
    if fx_audit:
        fx_evidence_run = run_dir / "FX_EVIDENCE.json"
        fx_gate_run = run_dir / "FX_GATE_RESULT.json"
        shutil.copy2(fx_evidence_path, fx_evidence_run)
        shutil.copy2(fx_gate_result_path, fx_gate_run)
        fx_run_sources = {
            "fx_evidence": fx_evidence_run,
            "fx_gate_result": fx_gate_run,
        }

    input_file_sha = _sha256(input_path) if input_path is not None and input_path.is_file() else None

    common = {
        "run_id": run_id,
        "run_directory": str(run_dir),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "case_sha256": case_sha,
        "input_file_sha256": input_file_sha,
        "case_snapshot": {"path": str(case_snapshot_path), "sha256": _sha256(case_snapshot_path)},
        "normalized_case": {"path": str(normalized_path), "sha256": _sha256(normalized_path)},
        "orchestrator_version": ORCHESTRATOR_VERSION,
        "engine": {"name": canonical.engine.name, "path": str(canonical.engine), "sha256": _sha256(canonical.engine)},
        "generator": {"name": GENERATOR_NAME, "path": str(canonical.generator), "sha256": _sha256(canonical.generator)},
        "normalized_input": normalized,
        "fx_audit": {
            "provided": bool(fx_run_sources),
            "evidence": _validate_artifact(fx_run_sources["fx_evidence"]) if fx_run_sources else None,
            "gate_result": _validate_artifact(fx_run_sources["fx_gate_result"]) if fx_run_sources else None,
        },
        "offer_format": normalized.get("offer_format", "scurt"),  # am.367
        "delivery_request": {
            "requested_formats": requested_formats,
            "cerere_operator_am388": _requested_formats_operator(case)[0],
            "email_format": normalized.get("email_format", "complet"),
            "offer_for": normalized.get("offer_for", "both"),
            "offer_format": normalized.get("offer_format", "scurt"),  # am.367
            "include_broker": normalized.get("include_broker", True),
            "defaulted_to_docx_and_pdf": delivery_defaulted,
            "internal_generation": ["docx", "pdf", "email_docx"],
            "delivery_stem": delivery_stem,
            "public_delivery_base": _public_delivery_base(delivery_stem, run_id),
            "unique_filenames": True,
        },
        "automatic_send": False,
        "automatic_propagation": False,
        "human_approval_required": True,
        "core_modified": False,
    }

    variant_request = _party_type_variant_request(normalized)
    if variant_request is not None:
        variant_request_path = run_dir / "VARIANT_REQUEST.json"
        _json_dump(variant_request_path, variant_request)
        internal_artifacts = {
            "variant_request": _validate_artifact(variant_request_path),
            "case_snapshot": _validate_artifact(case_snapshot_path),
            "normalized_case": _validate_artifact(normalized_path),
        }
        audit_delivery = _publish_fail_closed_audit(
            output_dir=output_dir,
            run_dir=run_dir,
            run_id=run_id,
            delivery_stem=delivery_stem,
            sources={
                "variant_request": variant_request_path,
                "case_snapshot": case_snapshot_path,
                "normalized_case": normalized_path,
            },
        )
        result = {
            **common,
            "status": "NECESITA_CLARIFICARE",
            "stage": "normalization",
            "error_code": "PARTY_TYPE_VARIANTS_REQUIRED",
            "message": "Tipurile PF/PJ nu sunt precizate. Selectați una dintre variante; pipeline-ul nu a ales automat.",
            "missing_fields": variant_request["missing_fields"],
            "variants": variant_request["variants"],
            "engine_status": "NOT_RUN",
            "generator_status": "NOT_RUN",
            "qa_status": "NOT_RUN",
            "variant_request": variant_request,
            "artifacts": internal_artifacts,
            "delivery_artifacts": {},
            "audit_delivery_artifacts": audit_delivery,
        }
        run_result_path = run_dir / "PIPELINE_RESULT.json"
        root_result_path = output_dir / "PIPELINE_RESULT.json"
        unique_result_path = Path(audit_delivery["pipeline_result"]["path"])
        _json_dump(run_result_path, result)
        _json_dump(root_result_path, result)
        _json_dump(unique_result_path, result)
        return result

    _am465_rec = _reprezentant_am465(case)  # am.465: INAINTE de motor — acolo se citeste faptul
    if "reprezentant_am465" in _am465_rec:
        normalized["reprezentant"] = _am465_rec["reprezentant_am465"]
        _json_dump(normalized_path, normalized)  # instantaneul cazului spune ce a primit motorul
    engine = _load_module(canonical.engine, "m1c01_reference_engine_active")
    validate = getattr(engine, "validate_and_calculate", None)
    if normalized.get("ancpi_rounding") and hasattr(engine, "ANCPI_ROUNDING"):  # am.367: comutatorul rotunjirii ANCPI (floor doar pe etaloane)
        engine.ANCPI_ROUNDING["mode"] = normalized["ancpi_rounding"]
    if not callable(validate):
        raise OrchestratorError("ENGINE_ENTRYPOINT_MISSING", "Motorul nu expune validate_and_calculate(...).")

    engine_result = validate(normalized)
    if not isinstance(engine_result, dict):
        raise OrchestratorError("ENGINE_INVALID_RESULT", "Motorul nu a returnat un obiect JSON.")
    engine_result_path = run_dir / "ENGINE_RESULT.json"
    _json_dump(engine_result_path, engine_result)

    if engine_result.get("status") != "CALCULATION_PASS_INTERNAL_DRAFT":
        error_code = engine_result.get("error_code") or "ENGINE_REJECTED"
        message = engine_result.get("message") or "Motorul a oprit execuția fail-closed."
        internal_artifacts = {
            "engine_result": _validate_artifact(engine_result_path),
            "case_snapshot": _validate_artifact(case_snapshot_path),
            "normalized_case": _validate_artifact(normalized_path),
        }
        audit_delivery = _publish_fail_closed_audit(
            output_dir=output_dir,
            run_dir=run_dir,
            run_id=run_id,
            delivery_stem=delivery_stem,
            sources={
                "engine_result": engine_result_path,
                "case_snapshot": case_snapshot_path,
                "normalized_case": normalized_path,
            },
        )
        result = {
            **common,
            "status": engine_result.get("status", "RESPINS_FAIL_CLOSED"),
            "stage": "engine",
            "error_code": error_code,
            "message": message,
            "missing_fields": engine_result.get("missing_fields", []),
            "engine_status": engine_result.get("status"),
            "generator_status": "NOT_RUN",
            "qa_status": "NOT_RUN",
            "engine_result": engine_result,
            "artifacts": internal_artifacts,
            "delivery_artifacts": {},
            "audit_delivery_artifacts": audit_delivery,
        }
        run_result_path = run_dir / "PIPELINE_RESULT.json"
        root_result_path = output_dir / "PIPELINE_RESULT.json"
        unique_result_path = Path(audit_delivery["pipeline_result"]["path"])
        _json_dump(run_result_path, result)
        _json_dump(root_result_path, result)
        _json_dump(unique_result_path, result)
        return result

    generator = _load_module(canonical.generator, "m1c01_offer_generator_v30")
    generate = getattr(generator, "generate", None)
    if not callable(generate):
        raise OrchestratorError("GENERATOR_ENTRYPOINT_MISSING", "Generatorul nu expune generate(...).")

    _offer_for = str(normalized.get("offer_for") or "both")
    _include_broker = normalized.get("include_broker", True) is not False
    _offer_format = "scurt"  # am.388: generatorul produce MEREU ambele seturi (scurt + complet); offer_format cerut = numai consemnat
    _email_format = str(normalized.get("email_format") or "complet")  # am.388
    _am399_rec = _am399_raport(case, normalized)  # am.399: mentiunea circula ca argument, nu prin normalized
    _am399_kw = {"pret_tva_am399": _am399_rec["pret_tva_am399"]["mentiune"]} if "pret_tva_am399" in _am399_rec else {}
    generator_result = generate(str(engine_result_path), str(run_dir), OUTPUT_BASENAME,
                                offer_for=_offer_for, include_broker=_include_broker, offer_format=_offer_format, **_am399_kw)
    if not isinstance(generator_result, dict) or generator_result.get("status") != "PASS":
        raise OrchestratorError(
            "GENERATOR_FAILED",
            "Generatorul nu a returnat PASS.",
            {"generator_result": generator_result},
        )

    if _offer_for == "split":
        docx_path = run_dir / f"{OUTPUT_BASENAME}_CUMPARATOR.docx"
        pdf_path = run_dir / f"{OUTPUT_BASENAME}_CUMPARATOR.pdf"
        email_docx_path = run_dir / "EMAIL_REZUMAT_M1-C01_CUMPARATOR.docx"
    else:
        docx_path = run_dir / f"{OUTPUT_BASENAME}.docx"
        pdf_path = run_dir / f"{OUTPUT_BASENAME}.pdf"
        email_docx_path = run_dir / "EMAIL_REZUMAT_M1-C01.docx"
    qa_path = run_dir / "RAPORT_QA_GENERATOR.json"
    # am.483: oferta detaliata poarta rularea inauntru — atasata INAINTE de masurarea artefactelor (SHA-uri consecvente)
    _rulare483 = _scrie_rulare_am482(run_dir, run_id)
    for _pdf483 in ([pdf_path, run_dir / f"{OUTPUT_BASENAME}_VANZATOR.pdf"] if _offer_for == "split" else [pdf_path]):
        if _pdf483.is_file():
            _ataseaza_rularea_am483(_pdf483, _rulare483)
    artifacts = {
        "case_snapshot": _validate_artifact(case_snapshot_path),
        "normalized_case": _validate_artifact(normalized_path),
        "engine_result": _validate_artifact(engine_result_path),
        "docx": _validate_artifact(docx_path),
        "pdf": _validate_artifact(pdf_path),
        "email_docx": _validate_artifact(email_docx_path),
        "qa": _validate_artifact(qa_path),
    }
    if _offer_for == "split":
        # am.135: setul vânzătorului, validat la fel de strict
        artifacts["docx_seller"] = _validate_artifact(run_dir / f"{OUTPUT_BASENAME}_VANZATOR.docx")
        artifacts["pdf_seller"] = _validate_artifact(run_dir / f"{OUTPUT_BASENAME}_VANZATOR.pdf")
        artifacts["email_docx_seller"] = _validate_artifact(run_dir / "EMAIL_REZUMAT_M1-C01_VANZATOR.docx")
    if _offer_format == "scurt":
        # am.367: setul scurt, produs de generator pe langa cel complet (aceleasi sume, acelasi run_id)
        _short_sets = [("", "_CUMPARATOR"), ("_seller", "_VANZATOR")] if _offer_for == "split" else [("", "")]
        for _ks, _ns in _short_sets:
            _base_short = f"{OUTPUT_BASENAME}{_ns}_SCURT" if _ns else f"{OUTPUT_BASENAME}_SCURT"
            artifacts["docx_scurt" + _ks] = _validate_artifact(run_dir / f"{_base_short}.docx")
            artifacts["pdf_scurt" + _ks] = _validate_artifact(run_dir / f"{_base_short}.pdf")
            artifacts["email_docx_scurt" + _ks] = _validate_artifact(run_dir / (f"EMAIL_SCURT_M1-C01{_ns}.docx" if _ns else "EMAIL_SCURT_M1-C01.docx"))
    qa = _load_json(qa_path)
    if qa.get("status") != "PASS":
        raise OrchestratorError("QA_FAILED", "Raportul QA nu este PASS.", {"qa": qa})
    if qa.get("core_modified") is not False or qa.get("automatic_send") is not False or qa.get("automatic_propagation") is not False:
        raise OrchestratorError("GOVERNANCE_QA_FAILED", "Raportul QA indică o abatere de guvernanță.")

    delivery_artifacts, delivery_manifests = _publish_delivery_artifacts(
        output_dir=output_dir,
        run_dir=run_dir,
        run_id=run_id,
        case_sha=case_sha,
        requested_formats=requested_formats,
        delivery_stem=delivery_stem,
        internal_artifacts=artifacts,
        offer_for=_offer_for,
        offer_format=_offer_format,
        email_format=_email_format,
    )

    success_sources: Dict[str, Path] = {
        "case_snapshot": case_snapshot_path,
        "normalized_case": normalized_path,
        "engine_result": engine_result_path,
        "qa_report": qa_path,
        **fx_run_sources,
    }
    audit_delivery = _publish_success_audit(
        output_dir=output_dir,
        run_dir=run_dir,
        run_id=run_id,
        delivery_stem=delivery_stem,
        sources=success_sources,
    )

    result = {
        **common,
        "status": "READY_FOR_HUMAN_REVIEW",
        "stage": "complete",
        "engine_status": engine_result.get("status"),
        "generator_status": generator_result.get("status"),
        "qa_status": qa.get("status"),
        "artifacts": artifacts,
        "delivery_artifacts": delivery_artifacts,
        "delivery_manifests": delivery_manifests,
        "audit_delivery_artifacts": audit_delivery,
        **_am399_rec,
        **_am465_rec,
    }
    run_result_path = run_dir / "PIPELINE_RESULT.json"
    root_result_path = output_dir / "PIPELINE_RESULT.json"
    unique_result_path = Path(audit_delivery["pipeline_result"]["path"])
    _json_dump(run_result_path, result)
    _json_dump(root_result_path, result)
    _json_dump(unique_result_path, result)
    return result



def _merge_patch(base: Any, patch: Any) -> Any:
    """Apply RFC 7396-style merge semantics for a derived case amendment."""
    if not isinstance(patch, Mapping):
        return patch
    result: Dict[str, Any] = dict(base) if isinstance(base, Mapping) else {}
    for key, value in patch.items():
        if value is None:
            result.pop(key, None)
        elif isinstance(value, Mapping):
            result[key] = _merge_patch(result.get(key, {}), value)
        else:
            result[key] = value
    return result


def _session_state_path(output_dir: Path) -> Path:
    return output_dir / SESSION_STATE_NAME


def _load_session_state(output_dir: Path) -> Dict[str, Any]:
    path = _session_state_path(output_dir)
    if not path.is_file():
        raise OrchestratorError(
            "SESSION_STATE_NOT_FOUND",
            "Nu există o speță reușită în conversația curentă din care să pornească modificarea.",
            {"state_path": str(path)},
        )
    state = _load_json(path)
    if state.get("status") != "ACTIVE" or not isinstance(state.get("case"), dict):
        raise OrchestratorError("SESSION_STATE_INVALID", "Snapshotul speței curente este invalid.")
    return state


def _write_session_state(
    *,
    output_dir: Path,
    case: Mapping[str, Any],
    result: Mapping[str, Any],
    mode: str,
    parent_run_id: Optional[str],
) -> Dict[str, Any]:
    previous: Dict[str, Any] = {}
    state_path = _session_state_path(output_dir)
    if state_path.is_file():
        try:
            previous = _load_json(state_path)
        except OrchestratorError:
            previous = {}
    history = list(previous.get("history", [])) if isinstance(previous.get("history"), list) else []
    history.append({
        "run_id": result.get("run_id"),
        "mode": mode,
        "parent_run_id": parent_run_id,
        "created_at_utc": result.get("created_at_utc"),
        "case_sha256": result.get("case_sha256"),
        "delivery_artifacts": result.get("delivery_artifacts", {}),
    })
    state = {
        "status": "ACTIVE",
        "session_protocol": "M1C01_STATEFUL_V1",
        "orchestrator_version": ORCHESTRATOR_VERSION,
        "updated_at_utc": datetime.now(timezone.utc).isoformat(),
        "current_run_id": result.get("run_id"),
        "parent_run_id": parent_run_id,
        "case": dict(case),
        "delivery_artifacts": result.get("delivery_artifacts", {}),
        "delivery_manifests": result.get("delivery_manifests", {}),
        "history": history[-50:],
        "automatic_send": False,
        "automatic_propagation": False,
        "core_modified": False,
    }
    _json_dump(state_path, state)
    return state


def _locate_runtime_file(search_root: Path, filename: str, explicit: Optional[Path] = None) -> Path:
    return _select_exact_file(search_root, filename, explicit)


def _run_fx_gate_internal(
    case: Mapping[str, Any],
    *,
    output_dir: Path,
    search_root: Path,
    fx_gate_path: Optional[Path] = None,
    registry_path: Optional[Path] = None,
) -> tuple[Dict[str, Any], Path, Path, Path]:
    """Execute FX Gate inside the stateful controller so a follow-up needs one command only."""
    gate_path = _select_versioned_component(
        search_root, FX_GATE_PREFIX, FX_GATE_SUFFIX, "FX Gate", fx_gate_path
    )
    registry = _select_versioned_component(
        search_root, REGISTRY_PREFIX, REGISTRY_SUFFIX, "registru FX",
        registry_path, require_numeric_version=False,
    )
    gate = _load_module(gate_path, "m1c01_fx_gate_stateful")
    run = getattr(gate, "run", None)
    if not callable(run):
        raise OrchestratorError("FX_GATE_ENTRYPOINT_MISSING", "FX Gate nu expune run(...).")

    work = output_dir / "M1C01_STATEFUL_WORK"
    work.mkdir(parents=True, exist_ok=True)
    draft_path = work / "M1C01_CASE_DRAFT.json"
    validated_path = work / "M1C01_CASE.json"
    evidence_path = work / "FX_EVIDENCE.json"
    gate_result_path = work / "FX_GATE_RESULT.json"
    _json_dump(draft_path, dict(case))
    fx_stdout = io.StringIO()
    fx_stderr = io.StringIO()
    with contextlib.redirect_stdout(fx_stdout), contextlib.redirect_stderr(fx_stderr):
        exit_code = run(draft_path, validated_path, evidence_path, gate_result_path, registry)
    gate_result = _load_json(gate_result_path)
    gate_result["captured_stdout"] = fx_stdout.getvalue()
    gate_result["captured_stderr"] = fx_stderr.getvalue()
    if gate_result.get("status") == "NECESITA_CLARIFICARE":
        # FX Gate V2.0+ poate cere cursul în loc să respingă speța. Cererea de
        # clarificare nu este un defect: se propagă operatorului ca întrebare.
        raise FXClarificationNeeded(
            str(gate_result.get("error_code") or "FX_RATE_REQUIRED"),
            str(gate_result.get("message") or "Este necesar cursul speței curente."),
            dict(gate_result.get("details") or {}),
        )
    if exit_code != 0 or gate_result.get("status") != "PASS":
        raise OrchestratorError(
            str(gate_result.get("error_code") or "FX_GATE_FAILED"),
            str(gate_result.get("message") or "FX Gate a respins speța."),
            dict(gate_result.get("details") or {}),
        )
    return _load_json(validated_path), evidence_path, gate_result_path, draft_path


def _reattach_latest(output_dir: Path) -> Dict[str, Any]:
    state = _load_session_state(output_dir)
    artifacts = state.get("delivery_artifacts") or {}
    required = set(AM388_LIVRARE_FIXA)  # am.388
    if not required.issubset(set(artifacts)):  # am.135: la split există și cheile *_seller
        raise OrchestratorError("LATEST_DELIVERY_INCOMPLETE", "Ultima rulare nu are toate cele trei livrabile.")
    for key, meta in artifacts.items():
        path = Path(str(meta.get("path", "")))
        if not path.is_file() or path.stat().st_size <= 0:
            raise OrchestratorError("LATEST_DELIVERY_MISSING", f"Livrabilul {key} nu mai este accesibil.")
    return {
        "status": "READY_FOR_REATTACH",
        "mode": "reattach",
        "run_id": state.get("current_run_id"),
        "delivery_artifacts": artifacts,
        "message": "Reatașați exact cele trei livrabile ale ultimei rulări, fără recalculare.",
        "automatic_send": False,
        "automatic_propagation": False,
        "core_modified": False,
    }


def run_stateful(
    *,
    mode: str,
    input_payload: Optional[Mapping[str, Any]],
    output_dir: Path,
    search_root: Path,
    engine_path: Optional[Path] = None,
    generator_path: Optional[Path] = None,
    fx_gate_path: Optional[Path] = None,
    registry_path: Optional[Path] = None,
) -> Dict[str, Any]:
    mode = mode.lower()
    if mode == "reattach":
        return _reattach_latest(output_dir)

    parent_run_id: Optional[str] = None
    if mode == "new":
        if not isinstance(input_payload, Mapping):
            raise OrchestratorError("INPUT_REQUIRED", "Modul new necesită speța completă.")
        case = dict(input_payload)
    elif mode in {"amend", "regenerate"}:
        state = _load_session_state(output_dir)
        parent_run_id = str(state.get("current_run_id") or "") or None
        base_case = dict(state["case"])
        if mode == "amend":
            if not isinstance(input_payload, Mapping):
                raise OrchestratorError("AMENDMENT_REQUIRED", "Modul amend necesită un obiect JSON cu modificările.")
            case = _merge_patch(base_case, input_payload)
        else:
            case = base_case
    else:
        raise OrchestratorError("INVALID_MODE", f"Mod de execuție necunoscut: {mode}.")

    # A derived run is fully recalculated. It never reuses old result files.
    validated_case, evidence_path, gate_result_path, draft_path = _run_fx_gate_internal(
        case,
        output_dir=output_dir,
        search_root=search_root,
        fx_gate_path=fx_gate_path,
        registry_path=registry_path,
    )
    result = run_pipeline(
        validated_case,
        output_dir=output_dir,
        search_root=search_root,
        engine_path=engine_path,
        generator_path=generator_path,
        input_path=draft_path,
        fx_evidence_path=evidence_path,
        fx_gate_result_path=gate_result_path,
    )
    result["execution_mode"] = mode
    result["parent_run_id"] = parent_run_id
    if result.get("status") == "READY_FOR_HUMAN_REVIEW":
        state = _write_session_state(
            output_dir=output_dir,
            case=validated_case,
            result=result,
            mode=mode,
            parent_run_id=parent_run_id,
        )
        result["session_state"] = {
            "path": str(_session_state_path(output_dir)),
            "current_run_id": state.get("current_run_id"),
            "parent_run_id": parent_run_id,
            "history_length": len(state.get("history", [])),
        }
        # Re-write result after session binding.
        run_result = Path(str(result.get("run_directory"))) / "PIPELINE_RESULT.json"
        root_result = output_dir / "PIPELINE_RESULT.json"
        unique_result = output_dir / f"{_delivery_slug(normalize_case(validated_case))}_{result['run_id']}_PIPELINE_RESULT.json"
        for path in (run_result, root_result, unique_result):
            _json_dump(path, result)
    return result



DELIVERY_ORDER = ("pdf", "pdf_detaliat", "email_docx", "rulare_json")  # am.388 + am.482


def _sanitized_delivery_artifacts(
    artifacts: Mapping[str, Any], expected_formats: Optional[Iterable[str]] = None
) -> Dict[str, Any]:
    """Return only root run-bound user-facing metadata; never expose internal aliases.

    `expected_formats` reflectă ce a cerut operatorul. Implicit, setul complet.
    Un format cerut și lipsă este eroare; unul necerut și absent nu este.
    """
    role_names = {
        "docx": "offer_docx",
        "pdf": "offer_pdf_short",  # am.388
        "pdf_detaliat": "offer_pdf_detailed",  # am.388
        "email_docx": "email_docx",
        "rulare_json": "run_json",  # am.482
    }
    wanted = [f for f in DELIVERY_ORDER if f in set(expected_formats or DELIVERY_ORDER)]
    if not wanted:
        raise OrchestratorError(
            "DELIVERY_CONTRACT_INCOMPLETE",
            "Nu a fost solicitat niciun livrabil public valid.",
        )
    sanitized: Dict[str, Any] = {}
    for fmt in wanted:
        raw = artifacts.get(fmt)
        if not isinstance(raw, Mapping):
            raise OrchestratorError(
                "DELIVERY_CONTRACT_INCOMPLETE",
                f"Lipsește livrabilul public obligatoriu: {fmt}.",
            )
        path = Path(str(raw.get("path", "")))
        validated = _validate_artifact(path)
        run_id = str(raw.get("run_id") or "")
        if not run_id:
            raise OrchestratorError("DELIVERY_RUN_ID_MISSING", f"Livrabilul {fmt} nu are run_id.")
        if path.name in {"OFERTA_M1-C01_CANONICA.docx", "OFERTA_M1-C01_CANONICA.pdf", "EMAIL_REZUMAT_M1-C01.docx"}:
            raise OrchestratorError(
                "INTERNAL_ALIAS_EXPOSED",
                f"Livrabilul public {fmt} indică un alias intern interzis.",
                {"path": str(path)},
            )
        sanitized[fmt] = {
            "role": role_names[fmt],
            "path": str(path),
            "filename": path.name,
            "size": validated["size"],
            "sha256": validated["sha256"],
            "run_id": run_id,
            "attach": True,
        }
    # PATCH V4.17 (am.135): setul vânzătorului (split) — după cel al cumpărătorului, aceleași verificări
    for fmt in wanted:
        raw = artifacts.get(fmt + "_seller")
        if not isinstance(raw, Mapping):
            continue
        path = Path(str(raw.get("path", "")))
        validated = _validate_artifact(path)
        run_id = str(raw.get("run_id") or "")
        if not run_id:
            raise OrchestratorError("DELIVERY_RUN_ID_MISSING", f"Livrabilul {fmt}_seller nu are run_id.")
        sanitized[fmt + "_seller"] = {
            "role": role_names[fmt] + "_seller",
            "path": str(path),
            "filename": path.name,
            "size": validated["size"],
            "sha256": validated["sha256"],
            "run_id": run_id,
            "attach": True,
        }
    run_ids = {str(meta["run_id"]) for meta in sanitized.values()}
    if len(run_ids) != 1:
        raise OrchestratorError(
            "DELIVERY_RUN_ID_MISMATCH",
            "Cele trei livrabile publice nu aparțin aceleiași rulări.",
            {"run_ids": sorted(run_ids)},
        )
    return sanitized


def _public_attachment_envelope(result: Mapping[str, Any]) -> Dict[str, Any]:
    """Build the only CLI-visible result used by ChatGPT for actual attachments."""
    status = str(result.get("status") or "RESPINS_FAIL_CLOSED")
    if status not in {"READY_FOR_HUMAN_REVIEW", "READY_FOR_REATTACH"}:
        return {
            "status": status,
            "stage": result.get("stage"),
            "error_code": result.get("error_code"),
            "message": result.get("message"),
            "missing_fields": result.get("missing_fields", []),
            "attachment_contract": ATTACHMENT_CONTRACT_VERSION,
            "attach_exact_paths": False,
            "attachment_paths": [],
            "delivery_artifacts": {},
            "orchestrator_version": ORCHESTRATOR_VERSION,
        }

    requested = (result.get("delivery_request") or {}).get("requested_formats")
    sanitized = _sanitized_delivery_artifacts(result.get("delivery_artifacts") or {}, requested)
    run_id = next(iter({meta["run_id"] for meta in sanitized.values()}))
    ordered_paths = [sanitized[fmt]["path"] for fmt in DELIVERY_ORDER if fmt in sanitized]
    ordered_paths += [sanitized[fmt + "_seller"]["path"] for fmt in DELIVERY_ORDER if fmt + "_seller" in sanitized]  # am.135
    return {
        "status": status,
        "stage": result.get("stage", "complete"),
        "execution_mode": result.get("execution_mode", "legacy"),
        "run_id": run_id,
        "parent_run_id": result.get("parent_run_id"),
        "attachment_contract": ATTACHMENT_CONTRACT_VERSION,
        "attach_exact_paths": True,
        "attachment_paths": ordered_paths,
        "delivery_artifacts": sanitized,
        "attachment_count": len(ordered_paths),
        "internal_aliases_are_not_deliverables": True,
        "message": (
            f"Atașați efectiv exact cele {len(ordered_paths)} fișiere din attachment_paths, "
            "în ordinea indicată."
        ),
        "orchestrator_version": ORCHESTRATOR_VERSION,
    }


def _write_public_attachment_result(output_dir: Path, result: Mapping[str, Any]) -> Dict[str, Any]:
    envelope = _public_attachment_envelope(result)
    _json_dump(output_dir / ATTACHMENT_RESULT_NAME, envelope)
    return envelope

def _failure_payload(exc: BaseException) -> Dict[str, Any]:
    if isinstance(exc, FXClarificationNeeded):
        # Cererea de curs nu este respingere: operatorul primește o întrebare.
        return {
            "status": "NECESITA_CLARIFICARE",
            "stage": "fx_gate",
            "error_code": exc.code,
            "message": exc.message,
            "details": exc.details,
            "missing_fields": ["fx.rate"],
            "engine_status": "NOT_RUN",
            "generator_status": "NOT_RUN",
            "qa_status": "NOT_RUN",
            "orchestrator_version": ORCHESTRATOR_VERSION,
            "automatic_send": False,
            "automatic_propagation": False,
            "human_approval_required": True,
            "core_modified": False,
        }
    if isinstance(exc, OrchestratorError):
        return {
            "status": "RESPINS_FAIL_CLOSED",
            "stage": "orchestrator",
            "error_code": exc.code,
            "message": exc.message,
            "details": exc.details,
            "orchestrator_version": ORCHESTRATOR_VERSION,
            "automatic_send": False,
            "automatic_propagation": False,
            "human_approval_required": True,
            "core_modified": False,
        }
    return {
        "status": "RESPINS_FAIL_CLOSED",
        "stage": "orchestrator",
        "error_code": "UNHANDLED_ORCHESTRATOR_ERROR",
        "message": str(exc),
        "traceback": traceback.format_exc(),
        "orchestrator_version": ORCHESTRATOR_VERSION,
        "automatic_send": False,
        "automatic_propagation": False,
        "human_approval_required": True,
        "core_modified": False,
    }


def main(argv: Optional[Iterable[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="M1-C01 stateful atomic pipeline orchestrator V3.7")
    parser.add_argument("--mode", choices=["legacy", "new", "amend", "regenerate", "reattach"], default="legacy")
    parser.add_argument("--input", type=Path, help="Speță completă (new/legacy) sau patch JSON (amend)")
    parser.add_argument("--output", default=Path("/mnt/data"), type=Path)
    parser.add_argument("--search-root", default=Path("/mnt/data"), type=Path)
    parser.add_argument("--engine", type=Path)
    parser.add_argument("--generator", type=Path)
    parser.add_argument("--fx-gate", type=Path)
    parser.add_argument("--registry", type=Path)
    parser.add_argument("--fx-evidence", type=Path)
    parser.add_argument("--fx-gate-result", type=Path)
    args = parser.parse_args(list(argv) if argv is not None else None)

    try:
        if args.mode == "legacy":
            if args.input is None:
                raise OrchestratorError("INPUT_REQUIRED", "Modul legacy necesită --input.")
            case = _load_json(args.input)
            result = run_pipeline(
                case,
                output_dir=args.output,
                search_root=args.search_root,
                engine_path=args.engine,
                generator_path=args.generator,
                input_path=args.input,
                fx_evidence_path=args.fx_evidence,
                fx_gate_result_path=args.fx_gate_result,
            )
        else:
            payload = _load_json(args.input) if args.input is not None else None
            result = run_stateful(
                mode=args.mode,
                input_payload=payload,
                output_dir=args.output,
                search_root=args.search_root,
                engine_path=args.engine,
                generator_path=args.generator,
                fx_gate_path=args.fx_gate,
                registry_path=args.registry,
            )
        public_result = _write_public_attachment_result(args.output, result)
        print(json.dumps(public_result, ensure_ascii=False, indent=2))
        return 0 if result.get("status") in {"READY_FOR_HUMAN_REVIEW", "READY_FOR_REATTACH"} else 2
    except BaseException as exc:
        payload = _failure_payload(exc)
        args.output.mkdir(parents=True, exist_ok=True)
        _json_dump(args.output / "PIPELINE_RESULT.json", payload)
        public_payload = _write_public_attachment_result(args.output, payload)
        stream = sys.stdout if payload.get("status") == "NECESITA_CLARIFICARE" else sys.stderr
        print(json.dumps(public_payload, ensure_ascii=False, indent=2), file=stream)
        return 3 if payload.get("status") == "NECESITA_CLARIFICARE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
