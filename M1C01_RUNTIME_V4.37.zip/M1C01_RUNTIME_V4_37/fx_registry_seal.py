"""Recalculează integrity.sha256 pentru registrul FX M1-C01. Rulare după orice adăugare de curs."""

# am.431 (T59a): scriere LF + stdout UTF-8 + legaturi fara privilegiu, pe orice mediu (R-71: pe Linux, no-op).
import os as _os_am431, sys as _sys_am431  # noqa: E402
_sys_am431.path.insert(0, _os_am431.path.abspath(_os_am431.path.join(_os_am431.path.dirname(_os_am431.path.abspath(__file__)), '..', '..')))
try:
    import SPN_PORTABIL_V1 as _portabil_am431  # noqa: E402,F401
except ImportError:  # runtime-ul livrat singur sau COPIAT in afara bancului (skill spn-taxe-m1c01, fixturile bateriei)
    # Fara modul, se face aici minimul care altfel opreste rularea: fluxurile pe UTF-8. Masurat in T59a —
    # copia runtime-ului din fixtura T56Z cadea cu «'charmap' codec can't encode 'ș'», deci orchestratorul
    # respingea livrarea desi motorul calculase corect. Pe Linux e no-op (fluxurile sunt deja UTF-8).
    _portabil_am431 = None
    for _flux_am431 in (_sys_am431.stdout, _sys_am431.stderr):
        try:
            if _flux_am431 is not None and (getattr(_flux_am431, 'encoding', '') or '').lower().replace('-', '') != 'utf8':
                _flux_am431.reconfigure(encoding='utf-8', errors='backslashreplace')
        except Exception:
            pass
import json, hashlib, sys
p = sys.argv[1]
reg = json.load(open(p, encoding="utf-8"))
body = {k: v for k, v in reg.items() if k != "integrity"}
blob = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
reg["integrity"] = {"algorithm": "sha256-canonical-json", "sha256": hashlib.sha256(blob.encode()).hexdigest()}
open(p, "w", encoding="utf-8").write(json.dumps(reg, ensure_ascii=False, indent=2))
print("integrity.sha256 =", reg["integrity"]["sha256"])
