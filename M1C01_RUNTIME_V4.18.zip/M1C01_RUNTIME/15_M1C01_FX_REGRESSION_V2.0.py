"""Regresie FX M1-C01 — V2.0.

V2.0 realiniază suita la FX Gate V2.0 și la registrul V2.0. V1.1 avea gate-ul și
registrul fixate pe nume de versiune, deci ar fi devenit inertă imediat după
patch-ul FX — același defect DEF-04 constatat la suitele 13 și 16.

Modificări față de V1.1:
* componentele se descoperă dinamic (exact o versiune activă);
* data neacoperită de registru nu mai este respingere, ci cerere de curs
  (`NECESITA_CLARIFICARE / FX_RATE_REQUIRED`), conform Instructions;
* integritatea registrului se verifică prin amprenta internă, nu prin hash fixat
  în codul gate-ului;
* cazuri noi pentru cascada V2.0: registru non-producție, registru modificat
  fără resigilare, dată implicită, rutare de weekend.

Treapta BNR live este dezactivată explicit (`--no-live`) în toate cazurile:
suita trebuie să fie deterministă și rulabilă fără rețea. Comportamentul live se
verifică separat, manual, într-un mediu cu acces la internet.

Nu modifică CORE, formulele, motorul sau generatorul.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, Optional

SUITE = "M1-C01_FX_REGRESSION_V2.0"
GATE_PREFIX = "14_M1C01_FX_GATE_V"
REGISTRY_PREFIX = "17_BNR_FX_REGISTRY"


def discover(root: Path, prefix: str, label: str, suffix: str) -> Path:
    found = sorted(p for p in root.glob(f"{prefix}*{suffix}") if p.is_file())
    if not found:
        raise SystemExit(f"Componenta {label} lipsește din {root} ({prefix}*{suffix}).")
    if len(found) > 1:
        raise SystemExit(
            f"Există mai multe versiuni active pentru {label}: " + ", ".join(p.name for p in found)
        )
    return found[0].resolve()


def _base(**kw: Any) -> Dict[str, Any]:
    case = {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF",
            "seller_tax_percent": 1, "currency": "EUR"}
    case.update(kw)
    return case


OPERATOR_FX = {
    "mode": "operator", "rate": 5.2424, "publication_date": "2026-08-11",
    "effective_date": "2026-08-12", "source": "operator",
    "operator_override": True, "operator_explicit": True,
}

# id -> (caz, status așteptat, cod așteptat, publicare așteptată, curs așteptat, mod așteptat)
CASES: Dict[str, tuple] = {
    "FXL01_WORKDAY_2026_07_31": (
        _base(calculation_date="2026-07-31"), "PASS", None, "2026-07-30", 5.2439, "bnr_local_registry"),
    "FXL02_WEEKEND_2026_08_02": (
        _base(calculation_date="2026-08-02"), "PASS", None, "2026-07-31", 5.2473, "bnr_local_registry"),
    "FXL03_MONDAY_2026_08_03": (
        _base(calculation_date="2026-08-03"), "PASS", None, "2026-07-31", 5.2473, "bnr_local_registry"),
    "FXL04_DATE_OUTSIDE_REGISTRY_ASKS_RATE": (
        _base(calculation_date="2026-08-04"), "NECESITA_CLARIFICARE", "FX_RATE_REQUIRED", None, None, None),
    "FXL05_UNAUTHORIZED_OPERATOR_REJECT": (
        _base(calculation_date="2026-08-12", fx={**OPERATOR_FX, "operator_explicit": False}),
        "RESPINS_FAIL_CLOSED", "UNAUTHORIZED_OPERATOR_FX_OVERRIDE", None, None, None),
    "FXL06_OPERATOR_EXPLICIT": (
        _base(calculation_date="2026-08-12", fx=OPERATOR_FX), "PASS", None, "2026-08-11", 5.2424, "operator"),
    "FXL07_CURRENT_DAY_FROM_REGISTRY": (
        _base(calculation_date="2026-08-12"), "PASS", None, "2026-08-11", 5.2424, "bnr_local_registry"),
    "FXL08_RON_NOT_APPLICABLE": (
        _base(currency="RON", price=1500000, calculation_date="2026-08-12"),
        "PASS", None, None, None, "RON"),
    "FXL09_FUTURE_DATE_ASKS_RATE": (
        _base(calculation_date="2026-12-31"), "NECESITA_CLARIFICARE", "FX_RATE_REQUIRED", None, None, None),
    "FXL10_SATURDAY_ROUTES_TO_FRIDAY": (
        _base(calculation_date="2026-08-15"), "NECESITA_CLARIFICARE", "FX_RATE_REQUIRED", None, None, None),
}

# Cazuri care alterează registrul înainte de rulare.
TAMPER_CASES = {
    "FXL11_REGISTRY_MODIFIED_WITHOUT_RESEAL": ("modify_rate", "RESPINS_FAIL_CLOSED",
                                               "FX_REGISTRY_INTEGRITY_MISMATCH"),
    "FXL12_REGISTRY_NOT_FOR_PRODUCTION": ("mark_non_production", "NECESITA_CLARIFICARE",
                                          "FX_RATE_REQUIRED"),
}


def _seal(registry: Dict[str, Any]) -> Dict[str, Any]:
    body = {k: v for k, v in registry.items() if k != "integrity"}
    blob = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    registry["integrity"] = {"algorithm": "sha256-canonical-json",
                             "sha256": hashlib.sha256(blob.encode("utf-8")).hexdigest()}
    return registry


def run_gate(gate: Path, registry: Path, out: Path, case: Dict[str, Any]) -> Dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    inp, case_out = out / "CASE_DRAFT.json", out / "CASE_READY.json"
    evidence, result_path = out / "FX_EVIDENCE.json", out / "FX_GATE_RESULT.json"
    inp.write_text(json.dumps(case, ensure_ascii=False, indent=2), encoding="utf-8")
    subprocess.run(
        [sys.executable, str(gate), "--input", str(inp), "--output-case", str(case_out),
         "--evidence", str(evidence), "--result", str(result_path),
         "--registry", str(registry), "--no-live"],
        capture_output=True, text=True,
    )
    if not result_path.is_file():
        return {"status": "NO_RESULT", "error_code": "GATE_PRODUCED_NO_RESULT"}
    payload = json.loads(result_path.read_text(encoding="utf-8"))
    if evidence.is_file():
        payload["_evidence"] = json.loads(evidence.read_text(encoding="utf-8"))
    return payload


def check(name: str, payload: Dict[str, Any], status: str, code: Optional[str],
          publication: Optional[str], rate: Optional[float], mode: Optional[str]) -> Dict[str, Any]:
    errors = []
    if payload.get("status") != status:
        errors.append(f"status={payload.get('status')} != {status}")
    if code and payload.get("error_code") != code:
        errors.append(f"error_code={payload.get('error_code')} != {code}")
    evidence = payload.get("_evidence") or {}
    if mode and evidence.get("mode") != mode:
        errors.append(f"mode={evidence.get('mode')} != {mode}")
    if publication and evidence.get("publication_date") != publication:
        errors.append(f"publication_date={evidence.get('publication_date')} != {publication}")
    if rate is not None and float(evidence.get("rate", 0)) != float(rate):
        errors.append(f"rate={evidence.get('rate')} != {rate}")
    return {"id": name, "status": "PASS" if not errors else "FAIL", "errors": errors,
            "gate_status": payload.get("status"), "error_code": payload.get("error_code"),
            "mode": evidence.get("mode"), "rate": evidence.get("rate")}


def main() -> int:
    parser = argparse.ArgumentParser(description=SUITE)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--search-root", type=Path, default=None)
    parser.add_argument("--gate", type=Path, default=None)
    parser.add_argument("--registry", type=Path, default=None)
    args = parser.parse_args()

    root = (args.search_root or Path(__file__).resolve().parent).resolve()
    gate = args.gate or discover(root, GATE_PREFIX, "FX Gate", ".py")
    registry = args.registry or discover(root, REGISTRY_PREFIX, "registru FX", ".json")
    args.output.mkdir(parents=True, exist_ok=True)

    results = []
    for name, spec in CASES.items():
        payload = run_gate(gate, registry, args.output / name, spec[0])
        results.append(check(name, payload, *spec[1:]))

    original = json.loads(registry.read_text(encoding="utf-8"))
    for name, (kind, status, code) in TAMPER_CASES.items():
        work = args.output / name
        work.mkdir(parents=True, exist_ok=True)
        altered = copy.deepcopy(original)
        if kind == "modify_rate":
            # Modificare fără resigilare: amprenta internă nu mai corespunde.
            next(iter(altered["records"].values()))["rate"] = 9.9999
        elif kind == "mark_non_production":
            altered["usable_in_production"] = False
            _seal(altered)
        altered_path = work / "REGISTRY_ALTERED.json"
        altered_path.write_text(json.dumps(altered, ensure_ascii=False, indent=2), encoding="utf-8")
        payload = run_gate(gate, altered_path, work, _base(calculation_date="2026-08-12"))
        results.append(check(name, payload, status, code, None, None, None))

    report = {
        "status": "PASS" if all(r["status"] == "PASS" for r in results) else "FAIL",
        "suite": SUITE,
        "scope": "rezolvarea cursului; treapta live dezactivată pentru determinism",
        "gate": str(gate),
        "registry": str(registry),
        "results": results,
    }
    (args.output / "FX_REGRESSION_REPORT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
