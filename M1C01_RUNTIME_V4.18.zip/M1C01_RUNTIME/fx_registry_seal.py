"""Recalculează integrity.sha256 pentru registrul FX M1-C01. Rulare după orice adăugare de curs."""
import json, hashlib, sys
p = sys.argv[1]
reg = json.load(open(p, encoding="utf-8"))
body = {k: v for k, v in reg.items() if k != "integrity"}
blob = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
reg["integrity"] = {"algorithm": "sha256-canonical-json", "sha256": hashlib.sha256(blob.encode()).hexdigest()}
open(p, "w", encoding="utf-8").write(json.dumps(reg, ensure_ascii=False, indent=2))
print("integrity.sha256 =", reg["integrity"]["sha256"])
