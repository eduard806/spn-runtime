"""Regresie de persistență a auditului M1-C01 — V2.0.

V2.0 remediază DEF-04 constatat la auditul din 12.08.2026: V1.0 avea căi fixe
către `/mnt/data` și versiuni inexistente (orchestrator V1.9, motor V1.5,
generator V2.0), deci eșua cu cinci fișiere lipsă înainte de a rula vreun test.

Componentele se descoperă acum dinamic: exact o versiune activă pentru fiecare.
Argumentele explicite rămân disponibile pentru rulări controlate.

Domeniu neschimbat: publicarea JSON run-bound și legarea dovezii FX. Nu modifică
CORE, formulele, motorul, generatorul sau registrul FX.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict

SUITE = "M1-C01_AUDIT_PERSISTENCE_REGRESSION_V2.0"

ORCHESTRATOR_PREFIX = "12_M1C01_PIPELINE_ORCHESTRATOR_V"
ENGINE_PREFIX = "08_M1C01_REFERENCE_ENGINE_V"
GENERATOR_PREFIX = "11_M1C01_OFFER_GENERATOR_V"
FX_GATE_PREFIX = "14_M1C01_FX_GATE_V"
REGISTRY_PREFIX = "17_BNR_FX_REGISTRY"


def discover(root: Path, prefix: str, label: str, suffix: str = ".py") -> Path:
    """Găsește exact o versiune activă a componentei. Oprește dacă sunt mai multe."""
    found = sorted(p for p in root.glob(f"{prefix}*{suffix}") if p.is_file())
    if not found:
        raise SystemExit(f"Componenta {label} lipsește din {root} ({prefix}*{suffix}).")
    if len(found) > 1:
        raise SystemExit(
            f"Există mai multe versiuni active pentru {label}: "
            + ", ".join(p.name for p in found)
        )
    return found[0].resolve()


def load(path: Path) -> Dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON object required: {path}")
    return value


def dump(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, capture_output=True)


def result(test_id: str, errors: list[str], **extra: Any) -> Dict[str, Any]:
    return {"id": test_id, "status": "PASS" if not errors else "FAIL", "errors": errors, **extra}


def build_base_case() -> Dict[str, Any]:
    return {
        "acts": ["sale"],
        "price": 300000,
        "buyer_type": "PF",
        "seller_type": "PF",
        "seller_owned_more_than_3_years": True,
        "currency": "EUR",
        "calculation_date": "2026-07-31",
        "client": "—",
        "broker": "—",
    }


def execute_gate(case_draft: Path, case_out: Path, evidence: Path, gate_result: Path, gate: Path, registry: Path) -> subprocess.CompletedProcess[str]:
    return run([
        sys.executable, str(gate),
        "--input", str(case_draft),
        "--output-case", str(case_out),
        "--evidence", str(evidence),
        "--result", str(gate_result),
        "--registry", str(registry),
    ])


def execute_orchestrator(case_path: Path, output: Path, orchestrator: Path, engine: Path, generator: Path, evidence: Path | None, gate_result: Path | None) -> subprocess.CompletedProcess[str]:
    cmd = [
        sys.executable, str(orchestrator),
        "--input", str(case_path),
        "--output", str(output),
        "--engine", str(engine),
        "--generator", str(generator),
    ]
    if evidence is not None:
        cmd += ["--fx-evidence", str(evidence)]
    if gate_result is not None:
        cmd += ["--fx-gate-result", str(gate_result)]
    return run(cmd)


def test_success(root: Path, args: argparse.Namespace) -> Dict[str, Any]:
    work = root / "A01_success"
    work.mkdir(parents=True, exist_ok=True)
    draft = work / "M1C01_CASE_DRAFT.json"
    case = work / "M1C01_CASE.json"
    evidence = work / "FX_EVIDENCE.json"
    gate_result = work / "FX_GATE_RESULT.json"
    output = work / "output"
    dump(draft, build_base_case())
    errors: list[str] = []

    fx_proc = execute_gate(draft, case, evidence, gate_result, args.fx_gate, args.registry)
    if fx_proc.returncode != 0:
        errors.append(f"fx gate returncode={fx_proc.returncode}: {fx_proc.stderr or fx_proc.stdout}")
        return result("AUDIT_SUCCESS_RUN_BOUND_GUARD", errors)

    proc = execute_orchestrator(case, output, args.orchestrator, args.engine, args.generator, evidence, gate_result)
    if proc.returncode != 0:
        errors.append(f"orchestrator returncode={proc.returncode}: {proc.stderr or proc.stdout}")
        return result("AUDIT_SUCCESS_RUN_BOUND_GUARD", errors)

    pipeline_path = output / "PIPELINE_RESULT.json"
    if not pipeline_path.is_file():
        errors.append("missing PIPELINE_RESULT.json")
        return result("AUDIT_SUCCESS_RUN_BOUND_GUARD", errors)
    pipeline = load(pipeline_path)
    run_id = str(pipeline.get("run_id", ""))
    stem = str(pipeline.get("delivery_request", {}).get("delivery_stem", ""))
    if pipeline.get("status") != "READY_FOR_HUMAN_REVIEW": errors.append("pipeline status mismatch")
    if pipeline.get("stage") != "complete": errors.append("pipeline stage mismatch")
    if pipeline.get("engine_status") != "CALCULATION_PASS_INTERNAL_DRAFT": errors.append("engine status mismatch")
    if pipeline.get("generator_status") != "PASS": errors.append("generator status mismatch")
    if pipeline.get("qa_status") != "PASS": errors.append("qa status mismatch")
    if pipeline.get("core_modified") is not False: errors.append("core_modified must be false")
    if pipeline.get("automatic_send") is not False: errors.append("automatic_send must be false")
    if pipeline.get("automatic_propagation") is not False: errors.append("automatic_propagation must be false")
    if pipeline.get("human_approval_required") is not True: errors.append("human approval must be required")
    if not run_id or not stem: errors.append("missing run_id/delivery_stem")

    audit = pipeline.get("audit_delivery_artifacts")
    required = ["case_snapshot", "normalized_case", "engine_result", "qa_report", "fx_evidence", "fx_gate_result", "pipeline_result"]
    if not isinstance(audit, dict):
        errors.append("missing audit_delivery_artifacts")
        audit = {}
    names: list[str] = []
    expected_prefix = f"{stem}_{run_id}_"
    for key in required:
        item = audit.get(key)
        if not isinstance(item, dict):
            errors.append(f"missing audit item {key}")
            continue
        path = Path(str(item.get("path", "")))
        names.append(path.name)
        if not path.is_file(): errors.append(f"audit file missing {key}: {path}")
        if not path.name.startswith(expected_prefix): errors.append(f"run-bound name mismatch {key}: {path.name}")
        if item.get("run_id") != run_id: errors.append(f"run_id mismatch {key}")

    engine_result_path = Path(str(audit.get("engine_result", {}).get("path", "")))
    qa_path = Path(str(audit.get("qa_report", {}).get("path", "")))
    fx_path = Path(str(audit.get("fx_evidence", {}).get("path", "")))
    if engine_result_path.is_file():
        eng = load(engine_result_path)
        totals = eng.get("totals", {})
        if totals.get("buyer_without_optional_notation") != "17249.05": errors.append("buyer total mismatch")
        if totals.get("seller") != "15790.15": errors.append("seller total mismatch")
    if qa_path.is_file():
        qa = load(qa_path)
        if qa.get("status") != "PASS": errors.append("QA report not PASS")
        if qa.get("details", {}).get("page_count") != 1: errors.append("page_count mismatch")
    if fx_path.is_file():
        fx = load(fx_path)
        expected_fx = {
            "status": "VERIFIED", "rate": 5.2439, "publication_date": "2026-07-30",
            "effective_date": "2026-07-31", "source": "BNR", "operator_override": False,
        }
        for key, expected in expected_fx.items():
            if fx.get(key) != expected: errors.append(f"FX {key} mismatch: {fx.get(key)!r}")
        if not fx.get("registry_sha256"): errors.append("missing registry_sha256")

    delivery = pipeline.get("delivery_artifacts", {})
    delivery_names = [Path(str(v.get("path", ""))).name for v in delivery.values() if isinstance(v, dict)]
    # Contractul validat livrează trei documente run-bound: DOCX, PDF și Word e-mail.
    if sorted(delivery.keys()) != ["docx", "email_docx", "pdf"]: errors.append("delivery formats mismatch")
    # Numele publice folosesc coduri de act și token SHA-256(run_id)[:6], nu run_id brut.
    token = hashlib.sha256(run_id.encode("utf-8")).hexdigest()[:6].upper()
    if any(token not in name for name in delivery_names): errors.append("delivery run_id mismatch")
    if any("M1C01_LIVRABIL_CURENT" in name for name in names + delivery_names): errors.append("stale delivery alias present")

    return result(
        "AUDIT_SUCCESS_RUN_BOUND_GUARD", errors,
        returncode=proc.returncode,
        run_id=run_id,
        audit_names=names,
        delivery_names=delivery_names,
        totals={"buyer": "17249.05", "seller": "15790.15"},
    )


def prepare_fx(work: Path, args: argparse.Namespace) -> tuple[Path, Path, Path]:
    draft = work / "M1C01_CASE_DRAFT.json"
    case = work / "M1C01_CASE.json"
    evidence = work / "FX_EVIDENCE.json"
    gate_result = work / "FX_GATE_RESULT.json"
    dump(draft, build_base_case())
    proc = execute_gate(draft, case, evidence, gate_result, args.fx_gate, args.registry)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout)
    return case, evidence, gate_result


def test_mismatch(root: Path, args: argparse.Namespace) -> Dict[str, Any]:
    work = root / "A02_mismatch"
    work.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []
    try:
        case, evidence, gate_result = prepare_fx(work, args)
    except Exception as exc:
        return result("AUDIT_FX_MISMATCH_FAIL_CLOSED_GUARD", [str(exc)])
    case_payload = load(case)
    case_payload["fx"]["rate"] = 5.9999
    dump(case, case_payload)
    output = work / "output"
    proc = execute_orchestrator(case, output, args.orchestrator, args.engine, args.generator, evidence, gate_result)
    payload = load(output / "PIPELINE_RESULT.json") if (output / "PIPELINE_RESULT.json").is_file() else {}
    if proc.returncode == 0: errors.append("mismatch unexpectedly accepted")
    if payload.get("status") != "RESPINS_FAIL_CLOSED": errors.append("status not fail-closed")
    if payload.get("error_code") != "FX_AUDIT_CASE_MISMATCH": errors.append(f"error code mismatch: {payload.get('error_code')}")
    if list(output.glob("*.docx")) or list(output.glob("*.pdf")): errors.append("deliverables generated after FX mismatch")
    return result("AUDIT_FX_MISMATCH_FAIL_CLOSED_GUARD", errors, returncode=proc.returncode, error_code=payload.get("error_code"))


def test_pair(root: Path, args: argparse.Namespace) -> Dict[str, Any]:
    work = root / "A03_pair"
    work.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []
    try:
        case, evidence, _gate_result = prepare_fx(work, args)
    except Exception as exc:
        return result("AUDIT_FX_PAIR_REQUIRED_GUARD", [str(exc)])
    output = work / "output"
    proc = execute_orchestrator(case, output, args.orchestrator, args.engine, args.generator, evidence, None)
    payload = load(output / "PIPELINE_RESULT.json") if (output / "PIPELINE_RESULT.json").is_file() else {}
    if proc.returncode == 0: errors.append("single FX audit file unexpectedly accepted")
    if payload.get("status") != "RESPINS_FAIL_CLOSED": errors.append("status not fail-closed")
    if payload.get("error_code") != "FX_AUDIT_PAIR_REQUIRED": errors.append(f"error code mismatch: {payload.get('error_code')}")
    if list(output.glob("*.docx")) or list(output.glob("*.pdf")): errors.append("deliverables generated without FX audit pair")
    return result("AUDIT_FX_PAIR_REQUIRED_GUARD", errors, returncode=proc.returncode, error_code=payload.get("error_code"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--search-root", type=Path, default=None,
                        help="Directorul Knowledge. Implicit: directorul acestei suite.")
    parser.add_argument("--orchestrator", type=Path, default=None)
    parser.add_argument("--engine", type=Path, default=None)
    parser.add_argument("--generator", type=Path, default=None)
    parser.add_argument("--fx-gate", type=Path, default=None)
    parser.add_argument("--registry", type=Path, default=None)
    parser.add_argument("--output", type=Path, default=Path("./M1C01_AUDIT_PERSISTENCE_REGRESSION_V2_0"))
    args = parser.parse_args()

    root = (args.search_root or Path(__file__).resolve().parent).resolve()
    if args.orchestrator is None:
        args.orchestrator = discover(root, ORCHESTRATOR_PREFIX, "orchestrator")
    if args.engine is None:
        args.engine = discover(root, ENGINE_PREFIX, "motor")
    if args.generator is None:
        args.generator = discover(root, GENERATOR_PREFIX, "generator")
    if args.fx_gate is None:
        args.fx_gate = discover(root, FX_GATE_PREFIX, "FX Gate")
    if args.registry is None:
        args.registry = discover(root, REGISTRY_PREFIX, "registru FX", suffix=".json")

    required = [args.orchestrator, args.engine, args.generator, args.fx_gate, args.registry]
    missing = [str(p) for p in required if not p.is_file()]
    if missing:
        report = {"status": "FAIL", "suite": SUITE, "scope": "audit persistence only; no CORE change", "errors": [f"missing file: {p}" for p in missing], "results": []}
        args.output.mkdir(parents=True, exist_ok=True)
        dump(args.output / "AUDIT_PERSISTENCE_REGRESSION_REPORT.json", report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 1

    if args.output.exists():
        shutil.rmtree(args.output)
    args.output.mkdir(parents=True)
    results = [test_success(args.output, args), test_mismatch(args.output, args), test_pair(args.output, args)]
    report = {
        "status": "PASS" if all(r["status"] == "PASS" for r in results) else "FAIL",
        "suite": SUITE,
        "scope": "run-bound success JSON persistence and FX evidence binding only; no CORE, formula, engine, generator or registry change",
        "results": results,
    }
    dump(args.output / "AUDIT_PERSISTENCE_REGRESSION_REPORT.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
