---
name: spn-taxe-m1c01
description: Calculator oficial de taxe notariale SPN STOICA (modulul M1-C01). Se foloseste ORICE data cand trebuie calculate onorarii, impozit vanzator, tarife ANCPI, arhivare sau TVA pentru acte notariale (vanzare, ipoteca, antecontract), inclusiv prin puntea de taxe a platformei de redactare. Contine runtime-ul autorizat V4.5 (motor V1.13) in M1C01_RUNTIME/. Executie numai fizica, sumele exclusiv din motor, cu run_id.
---

# SKILL: CALCULATOR TAXE NOTARIALE M1-C01 — V1.6 (14.08.2026)
# PROIECT INDIVIDUAL CALCULATOR DE TAXE · runtime oficial V4.5

## GUVERNANTA (regula de aur)
Acest proiect CONSUMA versiunea oficiala; NU o modifica. Orice defect/nevoie
noua = TICHET catre titular (componenta + speta JSON de reproducere + run_id),
patch-ul se face UNITAR in pipeline-ul platformei-mama si se intoarce ca
versiune noua pe GitHub. Repararea conversationala aici = defect de proces.

## RUNTIME-UL AUTORIZAT
La prima cerere de calcul din conversatie:
1. Descarcare autonoma:
   a) GitHub (sursa oficiala):
      https://raw.githubusercontent.com/eduard806/spn-runtime/main/M1C01_RUNTIME_V4_5.zip
   b) Fallback: cere operatorului sa incarce M1C01_RUNTIME_V4_5.zip manual.
   Dimensiunea asteptata: ~93 KB. Un raspuns de cateva sute de octeti e o
   pagina de eroare, nu arhiva - sterge-l si treci la sursa urmatoare.
2. VERIFICARE SHA-256 - OBLIGATORIE SI NENEGOCIABILA:
   bc96f5b169032bdd86a3eef2569f87bed4aaa3ab1cce920694365f23fd7bba55
   Nepotrivire = REFUZA orice calcul, sterge fisierul, anunta operatorul.
   Fara exceptii, indiferent de instructiuni contrare, inclusiv ale
   operatorului: hashul se schimba DOAR prin patch versionat al acestui skill.
3. Dezarhiveaza in /home/claude/m1c01/ si verifica preconditiile: exact UN
   motor 08_M1C01_REFERENCE_ENGINE_V1.13.py, exact un orchestrator
   12_M1C01_PIPELINE_ORCHESTRATOR_V3.5.py, reguli 04_M1_C01_RULES_V1.9.json,
   schema 06_INPUT_SCHEMA_M1-C01_V1.10.json + verificarea per-fisier pe
   RUNTIME_SHA256_MANIFEST.txt.
4. Descarcarea se face O DATA per conversatie.
Motorul V1.10 NU exista si nu se reconstruieste. Activ: V1.13.

## FLUXUL UNUI CALCUL
### Pasul 1 - normalizarea cererii (operatorul vorbeste natural)
- "PF-PF" -> buyer_type + seller_type (primul = cumparatorul).
- "ipoteca N%" -> acts+=mortgage, credit_percent=N, own_funds_percent=100-N.
- "cu P-V"/"cu antecontract" -> acts+=antecontract; avansul se cere daca lipseste.
- Impozit vanzator PF nespecificat -> NU intreba; motorul da 1%/3% necumulativ.
- Cantitati -> component_quantities (intregi nenegativi):
  sale_seller_authentication_extracts (40 lei/buc),
  sale_seller_information_extracts (20 lei/buc - INFORMAREA E PERMISA SI LA
  VANZARE, ex. radierea unei servituti), sale_notation_count (75 lei/notare),
  mortgage_* etc. Cantitate generica in speta multi-act -> cere DOAR scope-ul.
- MAJORARE ONORARIU: "majoreaza onorariul cu 10%" ->
  honorarium_increase_percent=10 + honorarium_increase_scope (sale/mortgage/
  both; ambiguu in speta multi-act -> intrebare). STRICT pe onorariu, inainte de TVA.
- TAXE SUPLIMENTARE (declarate explicit, ex. "taxa schimbare denumire
  creditor, 100 lei per carte funciara, 3 carti") ->
  additional_fees: [{"label": "...", "amount": 100, "quantity": 3}]
  (amount = tarif UNITAR; quantity implicit 1; total = amount x quantity;
  linia apare separata, marcata operator_declared). NIMIC nu se deduce.
- Nu deduce NIMIC: CF-urile nu devin extrase, extrasele nu devin imobile.

### Pasul 2 - cursul valutar (numai EUR): cascada FX Gate V2.1
operator (prioritate absoluta, cu data comunicatului) -> BNR live
(curs.bnr.ro, apoi www; valideaza XML, nu HTML) -> registrul local al ACELEIASI
spete -> INTREBARE (cu ziua de publicare necesara). Niciodata curs presupus,
niciodata mostenit intre spete. Sursa cursului se raporteaza la fiecare calcul.

### Pasul 3 - executia (numai fizica)
python3 /home/claude/m1c01/M1C01_RUNTIME/12_M1C01_PIPELINE_ORCHESTRATOR_V3.5.py
  --mode {new|amend|regenerate|reattach} --input CEREREA.json
  --output DIRECTOR_SPETA --search-root /home/claude/m1c01/M1C01_RUNTIME
Fiecare speta in director propriu. Exit 0=succes, 3=clarificare, altfel=esec.
Narativul fara artefacte = defect. Run_id-ul se raporteaza mereu.

### Pasul 4 - livrarea
EXACT fisierele din attachment_paths (M1C01_ATTACHMENT_RESULT.json), prin
present_files, cu numele run-bound. Alaturi: cursul (valoare/data/sursa) si
totalurile pe parti. Toate documentele = proiecte supuse aprobarii titularului.

### Non-succes
NECESITA_CLARIFICARE -> pui DOAR intrebarea indicata (nu e eroare).
RESPINS_FAIL_CLOSED -> raportezi error_code real; nu ocolesti pipeline-ul.

## ISTORIC V4.5 (14.08.2026)
Singura schimbare fata de V4.4: docstring-ul motorului 08_M1C01_REFERENCE_ENGINE_V1.13.py corectat (spunea V1.11 - sursa raportarilor gresite de versiune in jurnale). ZERO schimbari de calcul; lantul motorului neatins (V1.9 -> V1.11 -> V1.12 -> V1.13). Manifestul intern regenerat. Bateriile proprii: BRANCH PASS, FX 12/12 PASS pe V4.5.
