"""SPN STOICA AI — M1-C01 reference calculation engine V1.9.

Reference implementation for ChatBuild transfer. It is deterministic and offline:
the runtime must provide the effective FX rate and its source metadata. This file
never fetches external data, never sends an offer, and never propagates rules.

Canonical scope: MODULE M1-C01 V1.9 only. CORE is not modified.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from decimal import Decimal, ROUND_CEILING, ROUND_HALF_UP, InvalidOperation
from typing import Any, Dict, Iterable, List, Literal, Optional

D = Decimal
PersonType = Literal["PF", "PJ"]
VAT = D("0.21")


class FailClosedError(ValueError):
    """Materially incomplete, contradictory or unsupported input."""

    def __init__(self, code: str, message: str, missing_fields: Optional[List[str]] = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.missing_fields = missing_fields or []

    def as_result(self) -> Dict[str, Any]:
        return {
            "status": "RESPINS_FAIL_CLOSED",
            "error_code": self.code,
            "message": self.message,
            "missing_fields": self.missing_fields,
            "automatic_propagation": False,
            "human_approval_required": True,
        }


def dec(value: Any, field: str = "value") -> Decimal:
    try:
        result = D(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FailClosedError("INVALID_NUMBER", f"Câmp numeric invalid: {field}.") from exc
    if not result.is_finite() or result < 0:
        raise FailClosedError("INVALID_NUMBER", f"Câmp numeric negativ sau ne-finit: {field}.")
    return result


def ceil_leu(value: Decimal) -> Decimal:
    return value.quantize(D("1"), rounding=ROUND_CEILING)


def money2(value: Decimal) -> Decimal:
    return value.quantize(D("0.01"), rounding=ROUND_HALF_UP)


def count(value: Any, field: str, default: int) -> int:
    if value is None:
        return default
    try:
        d = D(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FailClosedError("INVALID_QUANTITY", f"Cantitate invalidă: {field}.") from exc
    if not d.is_finite() or d < 0 or d != d.to_integral_value():
        raise FailClosedError("INVALID_QUANTITY", f"Cantitatea trebuie să fie un număr întreg nenegativ: {field}.")
    return int(d)


def adjusted_honorarium(base: Decimal, percent: Any, field: str) -> tuple[Decimal, Decimal, Decimal]:
    pct = dec(percent if percent is not None else 0, field)
    final = ceil_leu(base * (D("1") + pct / D("100"))) if pct else base
    return pct, final - base, final


def person_verification(person_type: PersonType) -> Decimal:
    if person_type == "PF":
        return D("18.15")  # 15 + TVA 21%
    if person_type == "PJ":
        return D("30.00")  # RECOM, fără TVA
    raise FailClosedError("UNKNOWN_PERSON_TYPE", "Tipul persoanei trebuie să fie PF sau PJ.")


def sale_honorarium(value_lei: Decimal) -> Decimal:
    v = dec(value_lei, "sale_value_lei")
    if v <= D("20000"):
        return ceil_leu(max(D("0.022") * v, D("230")))
    if v <= D("35000"):
        return ceil_leu(D("440") + D("0.019") * (v - D("20001")))
    if v <= D("65000"):
        return ceil_leu(D("725") + D("0.016") * (v - D("35001")))
    if v <= D("100000"):
        return ceil_leu(D("1205") + D("0.015") * (v - D("65001")))
    if v <= D("200000"):
        return ceil_leu(D("1705") + D("0.011") * (v - D("100001")))
    if v <= D("600000"):
        return ceil_leu(D("2805") + D("0.009") * (v - D("200001")))
    if v == D("600001"):
        raise FailClosedError(
            "OPEN_THRESHOLD_600001",
            "Valoarea exactă 600.001 lei rămâne fail-closed până la decizie expresă a titularului.",
        )
    return ceil_leu(D("6405") + D("0.006") * (v - D("600001")))


def mortgage_honorarium(credit_lei: Decimal) -> Decimal:
    v = dec(credit_lei, "credit_lei")
    if v <= D("50000"):
        return ceil_leu(max(D("0.0085") * v, D("150")))
    if v <= D("100000"):
        return ceil_leu(D("425") + D("0.005") * (v - D("50000")))
    if v <= D("200000"):
        return ceil_leu(D("750") + D("0.0046") * (v - D("100001")))
    if v <= D("500000"):
        return ceil_leu(D("1209") + D("0.0019") * (v - D("200001")))
    if v == D("500001"):
        raise FailClosedError(
            "OPEN_THRESHOLD_500001",
            "Valoarea exactă 500.001 lei rămâne fail-closed până la decizie expresă a titularului.",
        )
    return ceil_leu(D("1778") + D("0.0010") * (v - D("500001")))


def opinion_calculation(
    information_extract_quantity: int = 1,
    notation_quantity: int = 0,
) -> Dict[str, Decimal]:
    qty = count(information_extract_quantity, "opinion_information_extracts", 1)
    extract_total = D("20.00") * qty
    notation_qty = count(notation_quantity, "opinion_notation_count", 0)
    notation_unit = D("75.00")
    notation_total = money2(notation_unit * notation_qty)
    return {
        "honorarium_net": D("400.00"),
        "vat": D("84.00"),
        "information_extract_quantity": qty,
        "information_extract_unit": D("20.00"),
        "information_extract": money2(extract_total),
        "notation_quantity": notation_qty,
        "notation_unit": notation_unit,
        "land_book_notation": notation_total,
        "total": money2(D("400.00") + D("84.00") + extract_total + notation_total),
    }

def antecontract_calculation(
    advance_lei: Decimal,
    buyer_type: PersonType,
    seller_type: PersonType,
    *,
    buyer_verification_quantity: int = 1,
    seller_information_extract_quantity: int = 1,
    seller_verification_quantity: int = 1,
    notation_quantity: int = 1,
) -> Dict[str, Any]:
    advance = dec(advance_lei, "advance_lei")
    honorarium = ceil_leu(max(D("0.01") * advance, D("500")))
    archive = D("45.00")
    vat = money2((honorarium + archive) * VAT)
    buyer_qty = count(buyer_verification_quantity, "antecontract_buyer_verifications", 1)
    seller_info_qty = count(seller_information_extract_quantity, "antecontract_seller_information_extracts", 1)
    seller_ver_qty = count(seller_verification_quantity, "antecontract_seller_verifications", 1)
    notation_qty = count(notation_quantity, "antecontract_notation_count", 1)
    buyer_verification_unit = person_verification(buyer_type)
    seller_verification_unit = person_verification(seller_type)
    buyer_verification = money2(buyer_verification_unit * buyer_qty)
    seller_information_extract = money2(D("20.00") * seller_info_qty)
    seller_verification = money2(seller_verification_unit * seller_ver_qty)
    notation_unit = D("75.00")
    notation_total = money2(notation_unit * notation_qty)
    buyer_without = honorarium + archive + vat + buyer_verification
    return {
        "advance_lei": money2(advance),
        "honorarium_net": honorarium,
        "archive": archive,
        "vat": vat,
        "buyer_verification_quantity": buyer_qty,
        "buyer_verification_unit": buyer_verification_unit,
        "buyer_verification": buyer_verification,
        "buyer_without_notation": money2(buyer_without),
        "notation_quantity": notation_qty,
        "notation_unit": notation_unit,
        "optional_notation": notation_total,
        "buyer_with_notation": money2(buyer_without + notation_total),
        "seller_information_extract_quantity": seller_info_qty,
        "seller_information_extract_unit": D("20.00"),
        "seller_information_extract": seller_information_extract,
        "seller_verification_quantity": seller_ver_qty,
        "seller_verification_unit": seller_verification_unit,
        "seller_verification": seller_verification,
        "seller_total": money2(seller_information_extract + seller_verification),
    }

def sale_calculation(
    price_lei: Decimal,
    buyer_type: PersonType,
    seller_type: PersonType,
    seller_tax_percent: Optional[int] = None,
    antecontract_honorarium_deduction: Decimal = D("0"),
    include_final_verifications: bool = True,
    *,
    honorarium_increase_percent: Any = 0,
    buyer_verification_quantity: Optional[int] = None,
    seller_authentication_extract_quantity: int = 1,
    seller_verification_quantity: Optional[int] = None,
    land_book_notation_quantity: int = 0,
) -> Dict[str, Any]:
    price = dec(price_lei, "price_lei")
    deduction = dec(antecontract_honorarium_deduction, "antecontract_honorarium_deduction")
    gross_honorarium = sale_honorarium(price)
    if deduction > gross_honorarium:
        raise FailClosedError("DEDUCTION_EXCEEDS_FEE", "Deducerea antecontractului depășește onorariul vânzării.")
    base_after_deduction = gross_honorarium - deduction
    pct, increase_amount, honorarium = adjusted_honorarium(base_after_deduction, honorarium_increase_percent, "sale_honorarium_increase_percent")
    archive = D("45.00")
    vat = money2((honorarium + archive) * VAT)
    ancpi_rate = D("0.0015") if buyer_type == "PF" else D("0.005")
    ancpi = ceil_leu(price * ancpi_rate)
    default_buyer_qty = 1 if include_final_verifications else 0
    buyer_qty = count(buyer_verification_quantity, "sale_buyer_verifications", default_buyer_qty)
    buyer_verification_unit = person_verification(buyer_type)
    buyer_verification = money2(buyer_verification_unit * buyer_qty)
    notation_qty = count(land_book_notation_quantity, "sale_notation_count", 0)
    notation_unit = D("75.00")
    land_book_notation = money2(notation_unit * notation_qty)
    buyer_total = honorarium + archive + vat + ancpi + buyer_verification + land_book_notation

    default_seller_qty = 1 if include_final_verifications else 0
    seller_ver_qty = count(seller_verification_quantity, "sale_seller_verifications", default_seller_qty)
    auth_qty = count(seller_authentication_extract_quantity, "sale_seller_authentication_extracts", 1)
    seller_verification_unit = person_verification(seller_type)
    seller_verification = money2(seller_verification_unit * seller_ver_qty)
    authentication_extract = money2(D("40.00") * auth_qty)
    seller_base = authentication_extract + seller_verification
    seller: Dict[str, Decimal] = {
        "authentication_extract_quantity": auth_qty,
        "authentication_extract_unit": D("40.00"),
        "authentication_extract": authentication_extract,
        "seller_verification_quantity": seller_ver_qty,
        "seller_verification_unit": seller_verification_unit,
        "seller_verification": seller_verification,
    }
    if seller_type == "PJ":
        seller["total"] = money2(seller_base)
    elif seller_tax_percent in (1, 3):
        tax = ceil_leu(price * D(seller_tax_percent) / D("100"))
        seller["tax_percent"] = D(seller_tax_percent)
        seller["tax"] = tax
        seller["total"] = money2(seller_base + tax)
    elif seller_tax_percent is None:
        tax1 = ceil_leu(price * D("0.01"))
        tax3 = ceil_leu(price * D("0.03"))
        seller["tax_1"] = tax1
        seller["tax_3"] = tax3
        seller["total_1"] = money2(seller_base + tax1)
        seller["total_3"] = money2(seller_base + tax3)
    else:
        raise FailClosedError("INVALID_TAX_VARIANT", "Impozitul vânzătorului PF poate fi numai 1%, 3% sau nespecificat.")

    return {
        "price_lei": money2(price),
        "gross_honorarium_before_deduction": gross_honorarium,
        "antecontract_honorarium_deduction": deduction,
        "honorarium_before_increase": base_after_deduction,
        "honorarium_increase_percent": pct,
        "honorarium_increase_amount": increase_amount,
        "honorarium_net": honorarium,
        "archive": archive,
        "vat": vat,
        "ancpi": ancpi,
        "buyer_verification_quantity": buyer_qty,
        "buyer_verification_unit": buyer_verification_unit,
        "buyer_verification": buyer_verification,
        "notation_quantity": notation_qty,
        "notation_unit": notation_unit,
        "land_book_notation": land_book_notation,
        "buyer_total": money2(buyer_total),
        "seller": seller,
    }

def mortgage_calculation(
    credit_lei: Decimal,
    buyer_type: PersonType,
    *,
    standalone: bool = False,
    include_buyer_verification: bool = False,
    honorarium_increase_percent: Any = 0,
    bank_proxy_check_quantity: int = 2,
    legalized_copy_quantity: int = 6,
    buyer_verification_quantity: Optional[int] = None,
    authentication_extract_quantity: Optional[int] = None,
    additional_collateral_property_quantity: int = 0,
    land_book_notation_quantity: int = 0,
) -> Dict[str, Any]:
    credit = dec(credit_lei, "credit_lei")
    base_honorarium = mortgage_honorarium(credit)
    pct, increase_amount, honorarium = adjusted_honorarium(base_honorarium, honorarium_increase_percent, "mortgage_honorarium_increase_percent")
    archive = D("45.00")
    vat = money2((honorarium + archive) * VAT)
    ocpi_base = ceil_leu(D("100") + D("0.001") * credit)
    additional_collateral_qty = count(
        additional_collateral_property_quantity,
        "mortgage_additional_collateral_properties",
        0,
    )
    additional_collateral_unit = D("100.00")
    additional_collateral_fee = money2(additional_collateral_unit * additional_collateral_qty)
    ocpi = money2(ocpi_base + additional_collateral_fee)
    proxy_qty = count(bank_proxy_check_quantity, "mortgage_bank_proxy_checks", 2)
    legal_qty = count(legalized_copy_quantity, "mortgage_legalized_copies", 6)
    default_ver_qty = 1 if include_buyer_verification else 0
    verification_qty = count(buyer_verification_quantity, "mortgage_buyer_verifications", default_ver_qty)
    default_auth_qty = 1 if standalone else 0
    auth_qty = count(authentication_extract_quantity, "mortgage_authentication_extracts", default_auth_qty)
    bank_proxy_check_unit = D("18.15")
    legalized_copy_unit = D("6.05")
    verification_unit = person_verification(buyer_type)
    bank_proxy_checks = money2(bank_proxy_check_unit * proxy_qty)
    bank_proxy_legalization = money2(legalized_copy_unit * legal_qty)
    verification = money2(verification_unit * verification_qty)
    authentication_extract = money2(D("40.00") * auth_qty)
    notation_qty = count(land_book_notation_quantity, "mortgage_notation_count", 0)
    notation_unit = D("75.00")
    land_book_notation = money2(notation_unit * notation_qty)
    total = honorarium + archive + vat + ocpi + bank_proxy_checks + bank_proxy_legalization + verification + authentication_extract + land_book_notation
    return {
        "credit_lei": money2(credit),
        "honorarium_before_increase": base_honorarium,
        "honorarium_increase_percent": pct,
        "honorarium_increase_amount": increase_amount,
        "honorarium_net": honorarium,
        "archive": archive,
        "vat": vat,
        "ocpi_base": money2(ocpi_base),
        "additional_collateral_property_quantity": additional_collateral_qty,
        "additional_collateral_property_unit": additional_collateral_unit,
        "additional_collateral_property_fee": additional_collateral_fee,
        "ocpi": ocpi,
        "bank_proxy_check_quantity": proxy_qty,
        "bank_proxy_check_unit": bank_proxy_check_unit,
        "bank_proxy_checks": bank_proxy_checks,
        "legalized_copy_quantity": legal_qty,
        "legalized_copy_unit": legalized_copy_unit,
        "bank_proxy_legalization": bank_proxy_legalization,
        "buyer_verification_quantity": verification_qty,
        "buyer_verification_unit": verification_unit,
        "buyer_verification": verification,
        "authentication_extract_quantity": auth_qty,
        "authentication_extract_unit": D("40.00"),
        "authentication_extract": authentication_extract,
        "notation_quantity": notation_qty,
        "notation_unit": notation_unit,
        "land_book_notation": land_book_notation,
        "buyer_total": money2(total),
    }

def _effective_money(amount: Any, currency: str, fx_rate: Decimal) -> Decimal:
    value = dec(amount, "amount")
    if currency == "RON":
        return money2(value)
    if currency == "EUR":
        return money2(value * fx_rate)
    raise FailClosedError("UNSUPPORTED_CURRENCY", "Versiunea canonică acceptă RON și EUR.")


def validate_and_calculate(request: Dict[str, Any]) -> Dict[str, Any]:
    """Validate a normalized request and produce a structured internal draft.

    Unknown person types are not guessed. The orchestrator must expand them into PF/PJ
    variants before calling this function, or return a controlled variant request.
    """
    try:
        acts = request.get("acts") or []
        if not isinstance(acts, list) or not acts:
            raise FailClosedError("MISSING_ACTS", "Nu a fost indicat niciun act.", ["acts"])
        allowed = {"opinion", "antecontract", "sale", "mortgage"}
        if any(a not in allowed for a in acts):
            raise FailClosedError("UNKNOWN_ACT", "A fost indicat un act neacceptat de M1-C01.")

        buyer_type = request.get("buyer_type")
        seller_type = request.get("seller_type")
        if buyer_type not in ("PF", "PJ") and any(a in acts for a in ("antecontract", "sale", "mortgage")):
            raise FailClosedError(
                "BUYER_TYPE_VARIANTS_REQUIRED",
                "Tipul cumpărătorului nu este precizat; trebuie generate separat variantele PF și PJ.",
                ["buyer_type"],
            )
        if seller_type not in ("PF", "PJ") and any(a in acts for a in ("antecontract", "sale")):
            raise FailClosedError(
                "SELLER_TYPE_VARIANTS_REQUIRED",
                "Tipul vânzătorului nu este precizat; trebuie generate separat variantele PF și PJ.",
                ["seller_type"],
            )

        fx = request.get("fx") or {}
        currency = request.get("currency", "EUR")
        if currency == "EUR":
            if fx.get("rate") is None:
                raise FailClosedError("MISSING_FX_RATE", "Lipsește cursul valutar efectiv.", ["fx.rate"])
            fx_rate = dec(fx["rate"], "fx.rate")
            for f in ("publication_date", "effective_date", "source"):
                if not fx.get(f):
                    raise FailClosedError("MISSING_FX_METADATA", "Metadatele cursului sunt incomplete.", [f"fx.{f}"])
        else:
            fx_rate = D("1")

        if "antecontract" in acts and request.get("advance") is None:
            own_funds_for_confirmation = request.get("own_funds")
            confirmed = request.get("advance_equals_own_funds_confirmed") is True
            if confirmed:
                if own_funds_for_confirmation is None:
                    raise FailClosedError(
                        "INVALID_ADVANCE_CONFIRMATION",
                        "Confirmarea că avansul este egal cu sursele proprii nu poate fi aplicată deoarece lipsesc sursele proprii.",
                        ["own_funds"],
                    )
                request = dict(request)
                request["advance"] = own_funds_for_confirmation
            elif request.get("finalization_requested") is True:
                raise FailClosedError(
                    "UNCONFIRMED_ANTECONTRACT_ADVANCE",
                    "Finalizarea a fost solicitată fără confirmarea sumei achitate la antecontract.",
                    ["advance"],
                )
            else:
                if own_funds_for_confirmation is not None:
                    question = (
                        f"Confirmați că suma achitată la antecontract este {own_funds_for_confirmation} {currency}, "
                        "reprezentând integral sursele proprii?"
                    )
                    proposed = {"advance": str(own_funds_for_confirmation), "currency": currency, "basis": "own_funds"}
                else:
                    question = "Ce sumă se achită la antecontract?"
                    proposed = None
                return {
                    "status": "NECESITA_CLARIFICARE",
                    "clarification_code": "CONFIRM_ANTECONTRACT_ADVANCE",
                    "question": question,
                    "missing_fields": ["advance"],
                    "proposed_value": proposed,
                    "assumption_applied": False,
                    "automatic_propagation": False,
                    "human_approval_required": True,
                }
        if "sale" in acts and request.get("price") is None:
            raise FailClosedError("MISSING_PRICE", "Lipsește prețul vânzării.", ["price"])

        price_lei = None
        if request.get("price") is not None:
            price_lei = _effective_money(request["price"], currency, fx_rate)

        advance_lei = None
        if request.get("advance") is not None:
            advance_lei = _effective_money(request["advance"], currency, fx_rate)
            if price_lei is not None and advance_lei > price_lei:
                raise FailClosedError("ADVANCE_EXCEEDS_PRICE", "Avansul depășește prețul.")

        credit_lei = None
        credit = request.get("credit")
        own_funds = request.get("own_funds")
        if "mortgage" in acts:
            standalone_mortgage = "sale" not in acts
            if standalone_mortgage:
                # Actul autonom are ca bază exclusiv valoarea creditului indicată de operator.
                # Nu se solicită și nu se inventează un preț al vânzării.
                if credit is None:
                    raise FailClosedError("MISSING_CREDIT", "Lipsește valoarea creditului pentru ipoteca/refinanțarea autonomă.", ["credit"])
                credit_lei = _effective_money(credit, currency, fx_rate)
            else:
                if credit is None and own_funds is None:
                    raise FailClosedError("MISSING_CREDIT", "Lipsește valoarea creditului sau a surselor proprii.", ["credit"])
                if price_lei is None:
                    raise FailClosedError("MISSING_PRICE", "Ipoteca din combinație necesită prețul vânzării.", ["price"])
                if credit is not None:
                    credit_lei = _effective_money(credit, currency, fx_rate)
                if own_funds is not None:
                    own_funds_lei = _effective_money(own_funds, currency, fx_rate)
                    derived_credit = money2(price_lei - own_funds_lei)
                    if derived_credit < 0:
                        raise FailClosedError("OWN_FUNDS_EXCEED_PRICE", "Sursele proprii depășesc prețul.")
                    if credit_lei is None:
                        credit_lei = derived_credit
                    elif credit_lei != derived_credit:
                        raise FailClosedError("FINANCING_MISMATCH", "Sursele proprii și creditul nu însumează prețul.")

        adjustment = request.get("honorarium_adjustment") or {}
        if not isinstance(adjustment, dict):
            raise FailClosedError("INVALID_HONORARIUM_ADJUSTMENT", "Ajustarea onorariului trebuie să fie un obiect.")
        increase_percent = adjustment.get("percent", 0)
        increase_scope = adjustment.get("scope") or []
        if isinstance(increase_scope, str):
            increase_scope = [increase_scope]
        if not isinstance(increase_scope, list):
            raise FailClosedError("INVALID_HONORARIUM_SCOPE", "Scope-ul majorării onorariului este invalid.")
        if any(v not in {"sale", "mortgage"} for v in increase_scope):
            raise FailClosedError("INVALID_HONORARIUM_SCOPE", "Majorarea onorariului se poate aplica numai vânzării și/sau ipotecii.")
        if any(v not in acts for v in increase_scope):
            raise FailClosedError("HONORARIUM_SCOPE_NOT_IN_CASE", "Scope-ul majorării include un act absent din speță.")
        increase_percent_dec = dec(increase_percent, "honorarium_adjustment.percent")
        quantities = request.get("component_quantities") or {}
        if not isinstance(quantities, dict):
            raise FailClosedError("INVALID_COMPONENT_QUANTITIES", "Cantitățile componentelor trebuie să fie un obiect.")

        tax_percent = request.get("seller_tax_percent")
        if tax_percent is not None:
            try:
                tax_percent = int(tax_percent)
            except (TypeError, ValueError) as exc:
                raise FailClosedError("INVALID_TAX_VARIANT", "Cota de impozit este invalidă.") from exc

        totals: Dict[str, Any] = {}
        components: Dict[str, Any] = {}
        buyer_without = D("0")
        seller_ante = D("0")
        ante_fee = D("0")
        notation_amount = D("0")

        if "opinion" in acts:
            components["opinion"] = opinion_calculation(
                quantities.get("opinion_information_extracts", 1),
                quantities.get("opinion_notation_count", 0),
            )
            buyer_without += components["opinion"]["total"]

        if "antecontract" in acts:
            components["antecontract"] = antecontract_calculation(
                advance_lei, buyer_type, seller_type,
                buyer_verification_quantity=quantities.get("antecontract_buyer_verifications"),
                seller_information_extract_quantity=quantities.get("antecontract_seller_information_extracts", 1),
                seller_verification_quantity=quantities.get("antecontract_seller_verifications"),
                notation_quantity=quantities.get("antecontract_notation_count", 1),
            )
            ante_fee = components["antecontract"]["honorarium_net"]
            buyer_without += components["antecontract"]["buyer_without_notation"]
            seller_ante = components["antecontract"]["seller_total"]
            notation_amount = components["antecontract"]["optional_notation"]

        sale_result = None
        if "sale" in acts:
            sale_result = sale_calculation(
                price_lei, buyer_type, seller_type,
                seller_tax_percent=tax_percent,
                antecontract_honorarium_deduction=ante_fee,
                include_final_verifications=True,
                honorarium_increase_percent=increase_percent_dec if "sale" in increase_scope else 0,
                buyer_verification_quantity=quantities.get("sale_buyer_verifications"),
                seller_authentication_extract_quantity=quantities.get("sale_seller_authentication_extracts", 1),
                seller_verification_quantity=quantities.get("sale_seller_verifications"),
                land_book_notation_quantity=quantities.get("sale_notation_count", 0),
            )
            components["sale"] = sale_result
            buyer_without += sale_result["buyer_total"]

        if "mortgage" in acts:
            components["mortgage"] = mortgage_calculation(
                credit_lei, buyer_type,
                standalone=("sale" not in acts),
                include_buyer_verification=("sale" not in acts),
                honorarium_increase_percent=increase_percent_dec if "mortgage" in increase_scope else 0,
                bank_proxy_check_quantity=quantities.get("mortgage_bank_proxy_checks", 2),
                legalized_copy_quantity=quantities.get("mortgage_legalized_copies", 6),
                buyer_verification_quantity=quantities.get("mortgage_buyer_verifications"),
                authentication_extract_quantity=quantities.get("mortgage_authentication_extracts"),
                additional_collateral_property_quantity=quantities.get("mortgage_additional_collateral_properties", 0),
                land_book_notation_quantity=quantities.get("mortgage_notation_count", 0),
            )
            buyer_without += components["mortgage"]["buyer_total"]

        totals["buyer_without_optional_notation"] = money2(buyer_without)
        totals["buyer_with_optional_notation"] = money2(buyer_without + notation_amount)

        if sale_result is not None:
            seller_sale = sale_result["seller"]
            if seller_type == "PF" and tax_percent is None:
                totals["seller_tax_1"] = money2(seller_ante + seller_sale["total_1"])
                totals["seller_tax_3"] = money2(seller_ante + seller_sale["total_3"])
                totals["seller_variants_non_cumulative"] = True
            else:
                totals["seller"] = money2(seller_ante + seller_sale["total"])
        elif "antecontract" in acts:
            totals["seller"] = money2(seller_ante)

        return {
            "status": "CALCULATION_PASS_INTERNAL_DRAFT",
            "module": "M1-C01",
            "module_version": "1.9",
            "configuration": {
                "acts": acts,
                "buyer_type": buyer_type,
                "seller_type": seller_type,
                "client": request.get("client") or "—",
                "broker": request.get("broker") or "—",
                "currency": currency,
                "fx": fx,
                "operator_confirmations": {
                    "advance_equals_own_funds": request.get("advance_equals_own_funds_confirmed") is True
                },
                "honorarium_adjustment": {
                    "percent": _jsonable(increase_percent_dec),
                    "scope": increase_scope,
                },
                "component_quantities": quantities,
            },
            "components": _jsonable(components),
            "totals": _jsonable(totals),
            "default_deliverables": ["DOCX_OFFER", "PDF_OFFER"],
            "human_approval_required": True,
            "automatic_send": False,
            "automatic_propagation": False,
            "core_modified": False,
        }
    except FailClosedError as exc:
        return exc.as_result()


def _jsonable(value: Any) -> Any:
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, dict):
        return {k: _jsonable(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_jsonable(v) for v in value]
    return value


__all__ = [
    "FailClosedError",
    "sale_honorarium",
    "mortgage_honorarium",
    "opinion_calculation",
    "antecontract_calculation",
    "sale_calculation",
    "mortgage_calculation",
    "validate_and_calculate",
]
