"""SPN STOICA AI — M1-C01 FX gate V2.0 (BNR live → registru local → clarificare).

Modifică exclusiv rezolvarea cursului. Nu atinge CORE, formulele de calcul,
motorul, generatorul sau orchestratorul.

Cascadă deterministă, în ordine strictă:

  1. RON                      → FX neaplicabil.
  2. curs explicit operator   → validat și folosit ca atare (comportament V1.1).
  3. BNR live                 → descărcare de pe bnr.ro pentru ziua bancară țintă.
  4. registru local           → numai dacă acoperă exact ziua bancară țintă.
  5. altfel                   → NECESITA_CLARIFICARE_FX: se cere cursul operatorului.

Diferențe față de V1.1
----------------------
* Treapta 3 este nouă: gate-ul își poate obține singur cursul oficial.
* Treapta 5 este nouă: absența cursului nu mai este eșec mut, ci cerere explicită.
  V1.1 returna FX_REGISTRY_DATE_NOT_COVERED, ceea ce contrazicea Instructions V3.8
  („EUR fără curs: întreabă exclusiv cursul speței curente").
* Registrul nu mai are hash hardcodat în cod. Integritatea se verifică față de
  câmpul `integrity.sha256` din registrul însuși, calculat pe conținutul canonic
  fără acel câmp. Registrul devine actualizabil, dar nu accidental.
* Registrul marcat `usable_in_production: false` este refuzat pentru calcule reale.
* Registrul învechit față de ziua țintă nu mai este folosit tăcut.

Rețea
-----
Treapta 3 necesită acces la internet. În medii fără rețea (ChatGPT Code
Interpreter, sandbox izolat) încercarea eșuează în `--fx-timeout` secunde și
cascada continuă curat spre treptele 4 și 5. Fără rețea, comportamentul este
identic cu V1.1 plus cererea explicită de curs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import urllib.error
import urllib.request
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Tuple
from urllib.parse import urlparse

VERSION = "2.0"
REGISTRY_NAME = "17_BNR_FX_REGISTRY_V2.0.json"

BNR_10DAYS_URL = "https://www.bnr.ro/nbrfxrates10days.xml"
BNR_TODAY_URL = "https://www.bnr.ro/nbrfxrates.xml"
BNR_ALLOWED_HOSTS = {"bnr.ro", "www.bnr.ro"}
DEFAULT_TIMEOUT = 6.0


class FXGateError(RuntimeError):
    def __init__(self, code: str, message: str, details: Dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


class FXClarificationRequired(RuntimeError):
    """Cursul nu poate fi stabilit automat; operatorul trebuie să îl indice."""

    def __init__(self, message: str, details: Dict[str, Any]):
        super().__init__(message)
        self.message = message
        self.details = details


# --------------------------------------------------------------------------- IO

def load_json(path: Path) -> Dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise FXGateError("INPUT_NOT_FOUND", f"Fișierul nu există: {path}") from exc
    except json.JSONDecodeError as exc:
        raise FXGateError("INPUT_INVALID_JSON", f"JSON invalid: {exc}") from exc
    if not isinstance(value, dict):
        raise FXGateError("INPUT_NOT_OBJECT", "Intrarea trebuie să fie un obiect JSON.")
    return value


def dump_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_sha256(payload: Mapping[str, Any]) -> str:
    body = {k: v for k, v in payload.items() if k != "integrity"}
    blob = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


# ------------------------------------------------------------------- primitives

def parse_date(value: Any, field: str) -> date:
    try:
        return date.fromisoformat(str(value))
    except Exception as exc:
        raise FXGateError("INVALID_DATE", f"Dată invalidă: {field}.", {"value": value}) from exc


def positive_decimal(value: Any, field: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FXGateError("INVALID_FX_RATE", f"Curs numeric invalid: {field}.") from exc
    if not result.is_finite() or result <= 0:
        raise FXGateError("INVALID_FX_RATE", f"Cursul trebuie să fie pozitiv și finit: {field}.")
    return result


def previous_weekday(day: date) -> date:
    candidate = day - timedelta(days=1)
    while candidate.weekday() >= 5:
        candidate -= timedelta(days=1)
    return candidate


def resolve_target_date(case: Mapping[str, Any]) -> Tuple[date, str, date]:
    """Ziua bancară al cărei curs se aplică speței.

    Regula fiscală aplicabilă: se folosește cotația oficială BNR publicată în
    ziua lucrătoare anterioară datei operațiunii.
    """
    raw = case.get("calculation_date")
    if raw in (None, ""):
        effective = datetime.now(timezone.utc).date()
    else:
        effective = parse_date(raw, "calculation_date")
    day_type = "weekend" if effective.weekday() >= 5 else "business_day"
    return previous_weekday(effective), day_type, effective


# ------------------------------------------------------------------ treapta 2

def validate_operator(case: Dict[str, Any], fx: Mapping[str, Any]) -> Dict[str, Any]:
    if fx.get("operator_explicit") is not True:
        raise FXGateError(
            "UNAUTHORIZED_OPERATOR_FX_OVERRIDE",
            "Cursul operatorului este permis numai dacă rata a fost furnizată expres în mesajul curent.",
        )
    if fx.get("operator_override") is not True or str(fx.get("source", "")).lower() != "operator":
        raise FXGateError(
            "INVALID_OPERATOR_FX_METADATA",
            "Modul operator necesită source=operator și operator_override=true.",
        )
    positive_decimal(fx.get("rate"), "fx.rate")
    publication = parse_date(fx.get("publication_date"), "fx.publication_date")
    effective = parse_date(fx.get("effective_date"), "fx.effective_date")
    evidence = {
        "status": "VERIFIED",
        "mode": "operator",
        "rate": fx["rate"],
        "publication_date": publication.isoformat(),
        "effective_date": effective.isoformat(),
        "source": "operator",
        "operator_override": True,
        "operator_explicit": True,
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    case["fx"] = {k: v for k, v in evidence.items() if k not in ("status", "verified_at_utc")}
    return evidence


# ------------------------------------------------------------------ treapta 3

def _fetch(url: str, timeout: float) -> str:
    host = (urlparse(url).hostname or "").lower()
    if host not in BNR_ALLOWED_HOSTS:
        raise FXGateError("FX_SOURCE_NOT_OFFICIAL", "Descărcarea este permisă exclusiv de pe bnr.ro.")
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "SPN-STOICA-M1C01-FXGate/2.0", "Accept": "application/xml"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        if response.status != 200:
            raise FXGateError("FX_LIVE_HTTP_ERROR", f"Răspuns HTTP {response.status} de la BNR.")
        return response.read().decode("utf-8", errors="replace")


def _parse_bnr_xml(xml: str) -> Dict[str, Decimal]:
    """Extrage perechile publication_date → curs EUR din formatul nbrfxrates."""
    rates: Dict[str, Decimal] = {}
    for cube in re.finditer(r'<Cube\s+date="(\d{4}-\d{2}-\d{2})"\s*>(.*?)</Cube>', xml, re.S):
        day = cube.group(1)
        eur = re.search(r'<Rate\s+currency="EUR"\s*>([0-9.]+)</Rate>', cube.group(2))
        if eur:
            try:
                rates[day] = Decimal(eur.group(1))
            except InvalidOperation:
                continue
    return rates


def resolve_live_bnr(
    case: Dict[str, Any], target_date: date, day_type: str, effective_date: date, timeout: float
) -> Optional[Dict[str, Any]]:
    """Încearcă obținerea cursului direct de la BNR. None dacă nu reușește."""
    for url in (BNR_10DAYS_URL, BNR_TODAY_URL):
        try:
            xml = _fetch(url, timeout)
        except (urllib.error.URLError, urllib.error.HTTPError, OSError, TimeoutError):
            continue
        except FXGateError:
            raise
        rates = _parse_bnr_xml(xml)
        rate = rates.get(target_date.isoformat())
        if rate is None:
            continue
        evidence = {
            "status": "VERIFIED",
            "mode": "bnr_live",
            "rate": float(rate),
            "publication_date": target_date.isoformat(),
            "target_publication_date": target_date.isoformat(),
            "effective_date": effective_date.isoformat(),
            "calculation_day_type": day_type,
            "source": "BNR",
            "official_source_url": url,
            "official_source_label": f"BNR — curs de referință publicat {target_date.isoformat()}",
            "operator_override": False,
            "fetched_at_utc": datetime.now(timezone.utc).isoformat(),
            "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        case["fx"] = {
            "rate": float(rate),
            "publication_date": target_date.isoformat(),
            "effective_date": effective_date.isoformat(),
            "source": "BNR",
            "operator_override": False,
            "mode": "bnr_live",
            "evidence_status": "VERIFIED",
            "official_source_url": url,
            "target_publication_date": target_date.isoformat(),
            "calculation_day_type": day_type,
        }
        return evidence
    return None


# ------------------------------------------------------------------ treapta 4

def validate_registry(path: Path, pinned_sha256: Optional[str]) -> Dict[str, Any]:
    if not path.is_file():
        raise FXGateError("FX_REGISTRY_NOT_FOUND", f"Registrul FX local lipsește: {path}")
    if pinned_sha256:
        actual = sha256_file(path)
        if actual != pinned_sha256:
            raise FXGateError(
                "FX_REGISTRY_HASH_MISMATCH",
                "Hashul registrului FX nu corespunde valorii fixate explicit.",
                {"expected": pinned_sha256, "actual": actual},
            )
    registry = load_json(path)
    integrity = registry.get("integrity") or {}
    declared = str(integrity.get("sha256", ""))
    computed = canonical_sha256(registry)
    if declared != computed:
        raise FXGateError(
            "FX_REGISTRY_INTEGRITY_MISMATCH",
            "Conținutul registrului FX nu corespunde amprentei sale interne. "
            "Registrul a fost modificat fără actualizarea câmpului integrity.sha256.",
            {"declared": declared, "computed": computed},
        )
    if registry.get("usable_in_production") is not True:
        raise FXGateError(
            "FX_REGISTRY_NOT_FOR_PRODUCTION",
            "Registrul FX nu este autorizat pentru calcule reale.",
            {"scope": registry.get("scope")},
        )
    return registry


def resolve_local_registry(
    case: Dict[str, Any],
    registry_path: Path,
    pinned_sha256: Optional[str],
    target_date: date,
    day_type: str,
    effective_date: date,
) -> Optional[Dict[str, Any]]:
    registry = validate_registry(registry_path, pinned_sha256)
    record = registry.get("records", {}).get(target_date.isoformat())
    if not isinstance(record, dict):
        return None
    rate = positive_decimal(record.get("rate"), "registry.rate")
    raw_url = str(record.get("official_source_url", ""))
    host = (urlparse(raw_url).hostname or "").lower()
    if host not in BNR_ALLOWED_HOSTS:
        raise FXGateError("FX_SOURCE_NOT_OFFICIAL", "Registrul local trebuie să indice o sursă oficială bnr.ro.")
    evidence = {
        "status": "VERIFIED",
        "mode": "bnr_local_registry",
        "rate": float(rate),
        "publication_date": target_date.isoformat(),
        "target_publication_date": target_date.isoformat(),
        "effective_date": effective_date.isoformat(),
        "calculation_day_type": day_type,
        "source": "BNR",
        "official_source_url": raw_url,
        "official_source_label": record.get("official_source_label"),
        "operator_override": False,
        "registry_id": registry.get("registry_id"),
        "registry_sha256": (registry.get("integrity") or {}).get("sha256"),
        "registry_scope": registry.get("scope"),
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    case["fx"] = {
        "rate": float(rate),
        "publication_date": target_date.isoformat(),
        "effective_date": effective_date.isoformat(),
        "source": "BNR",
        "operator_override": False,
        "mode": "bnr_local_registry",
        "evidence_status": "VERIFIED",
        "official_source_url": raw_url,
        "target_publication_date": target_date.isoformat(),
        "calculation_day_type": day_type,
        "registry_id": registry.get("registry_id"),
    }
    return evidence


# ------------------------------------------------------------------------ run

def run(
    input_path: Path,
    output_case: Path,
    evidence_path: Path,
    result_path: Path,
    registry_path: Path,
    *,
    allow_live: bool = True,
    timeout: float = DEFAULT_TIMEOUT,
    pinned_sha256: Optional[str] = None,
) -> int:
    attempts: list[Dict[str, Any]] = []
    try:
        case = load_json(input_path)
        currency = str(case.get("currency", "EUR")).upper()

        if currency == "RON":
            dump_json(output_case, case)
            evidence = {"status": "NOT_APPLICABLE", "mode": "RON", "source": "RON"}
        else:
            fx = case.get("fx")
            if isinstance(fx, dict) and str(fx.get("mode", "")).lower() == "operator":
                evidence = validate_operator(case, fx)
                attempts.append({"step": "operator", "outcome": "USED"})
            else:
                if isinstance(fx, dict) and (
                    fx.get("operator_override") is True or fx.get("operator_explicit") is True
                ):
                    raise FXGateError(
                        "UNAUTHORIZED_OPERATOR_FX_OVERRIDE",
                        "Override-ul operatorului nu a fost autorizat explicit.",
                    )

                target_date, day_type, effective_date = resolve_target_date(case)
                evidence = None

                if allow_live:
                    evidence = resolve_live_bnr(case, target_date, day_type, effective_date, timeout)
                    attempts.append({
                        "step": "bnr_live",
                        "outcome": "USED" if evidence else "UNAVAILABLE",
                        "target_publication_date": target_date.isoformat(),
                    })
                else:
                    attempts.append({"step": "bnr_live", "outcome": "DISABLED"})

                if evidence is None:
                    try:
                        evidence = resolve_local_registry(
                            case, registry_path, pinned_sha256, target_date, day_type, effective_date
                        )
                        attempts.append({
                            "step": "bnr_local_registry",
                            "outcome": "USED" if evidence else "DATE_NOT_COVERED",
                            "target_publication_date": target_date.isoformat(),
                        })
                    except FXGateError as exc:
                        attempts.append({
                            "step": "bnr_local_registry",
                            "outcome": "REJECTED",
                            "error_code": exc.code,
                        })
                        if exc.code in ("FX_REGISTRY_INTEGRITY_MISMATCH", "FX_REGISTRY_HASH_MISMATCH"):
                            raise
                        evidence = None

                if evidence is None:
                    raise FXClarificationRequired(
                        "Cursul EUR pentru ziua bancară de referință nu a putut fi stabilit automat. "
                        "Indicați cursul BNR aplicabil speței curente.",
                        {
                            "required_field": "fx.rate",
                            "target_publication_date": target_date.isoformat(),
                            "effective_date": effective_date.isoformat(),
                            "calculation_day_type": day_type,
                            "attempts": attempts,
                        },
                    )

            dump_json(output_case, case)

        dump_json(evidence_path, evidence)
        result = {
            "status": "PASS",
            "fx_gate_version": VERSION,
            "mode": evidence.get("mode"),
            "resolution_chain": attempts,
            "output_case": str(output_case),
            "fx_evidence": str(evidence_path),
            "registry": str(registry_path) if evidence.get("mode") == "bnr_local_registry" else None,
            "automatic_propagation": False,
            "human_approval_required": True,
            "core_modified": False,
        }
        dump_json(result_path, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    except FXClarificationRequired as exc:
        result = {
            "status": "NECESITA_CLARIFICARE",
            "stage": "fx_gate",
            "error_code": "FX_RATE_REQUIRED",
            "message": exc.message,
            "details": exc.details,
            "fx_gate_version": VERSION,
            "automatic_propagation": False,
            "human_approval_required": True,
            "core_modified": False,
        }
        dump_json(result_path, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 3

    except FXGateError as exc:
        details = dict(exc.details)
        if attempts:
            details["resolution_chain"] = attempts
        result = {
            "status": "RESPINS_FAIL_CLOSED",
            "stage": "fx_gate",
            "error_code": exc.code,
            "message": exc.message,
            "details": details,
            "fx_gate_version": VERSION,
            "automatic_propagation": False,
            "human_approval_required": True,
            "core_modified": False,
        }
        dump_json(result_path, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2


def main() -> int:
    parser = argparse.ArgumentParser(description="M1-C01 FX gate V2.0")
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output-case", required=True, type=Path)
    parser.add_argument("--evidence", required=True, type=Path)
    parser.add_argument("--result", required=True, type=Path)
    parser.add_argument("--registry", type=Path, default=Path(__file__).resolve().parent / REGISTRY_NAME)
    parser.add_argument("--no-live", action="store_true", help="Dezactivează treapta BNR live.")
    parser.add_argument("--fx-timeout", type=float, default=DEFAULT_TIMEOUT)
    parser.add_argument("--registry-sha256", type=str, default=None,
                        help="Fixează explicit hashul fișierului de registru.")
    args = parser.parse_args()
    return run(
        args.input, args.output_case, args.evidence, args.result, args.registry,
        allow_live=not args.no_live, timeout=args.fx_timeout, pinned_sha256=args.registry_sha256,
    )


if __name__ == "__main__":
    raise SystemExit(main())
