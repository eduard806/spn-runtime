"""SPN STOICA AI — M1-C01 deterministic pipeline orchestrator V3.6.

V3.4 extinde descoperirea dinamică — introdusă în V3.3 doar pentru motor — la
generator, FX Gate și registrul FX, care erau fixate pe nume de versiune în cod.
Aceeași disciplină: exact o versiune activă, altfel oprire fail-closed.

V3.4 propagă de asemenea cererea de curs a FX Gate V2.0 ca NECESITA_CLARIFICARE,
nu ca respingere. V3.3 transforma orice rezultat non-PASS al gate-ului în
RESPINS_FAIL_CLOSED, ceea ce ar fi transformat o întrebare adresată operatorului
într-o eroare de execuție.

V3.6 remediază DEF-08: contractul public de livrare cerea necondiționat toate
trei livrabilele, deci orice `requested_formats` parțial era respins cu
DELIVERY_CONTRACT_INCOMPLETE, deși documentele cerute fuseseră generate corect.
Contractul respectă acum formatele efectiv solicitate; setul implicit rămâne
complet (DOCX + PDF + Word e-mail) când operatorul nu cere altceva.

Nu modifică CORE, formulele, motorul sau conținutul livrabilelor.


Local scope only: ChatBuild M1-C01. This file does not modify CORE, the parent
project, the canonical calculation engine, or the offer generator.

Purpose:
- normalize a compact case envelope into the canonical engine schema;
- execute the active engine and generator atomically;
- remove stale aliases before execution;
- verify generated deliverables and QA before reporting success;
- publish run-bound success and fail-closed audit artifacts;
- emit a compact attachment contract containing only exact root-level download paths;
- preserve human approval and disable automatic sending/propagation.

The runtime remains responsible for supplying a verified FX rate. This script
never invents or downloads an exchange rate.
"""
from __future__ import annotations

import argparse
import contextlib
import io
import hashlib
import importlib.util
import json
import shutil
import sys
import re
import unicodedata
import traceback
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional
from zoneinfo import ZoneInfo

ENGINE_PREFIX = "08_M1C01_REFERENCE_ENGINE_V"
ENGINE_SUFFIX = ".py"
GENERATOR_PREFIX = "11_M1C01_OFFER_GENERATOR_V"
GENERATOR_SUFFIX = ".py"
FX_GATE_PREFIX = "14_M1C01_FX_GATE_V"
FX_GATE_SUFFIX = ".py"
REGISTRY_PREFIX = "17_BNR_FX_REGISTRY"
REGISTRY_SUFFIX = ".json"
# Etichete folosite exclusiv în rapoarte, când componenta nu a fost încă rezolvată.
GENERATOR_NAME = f"{GENERATOR_PREFIX}*{GENERATOR_SUFFIX}"
FX_GATE_NAME = f"{FX_GATE_PREFIX}*{FX_GATE_SUFFIX}"
REGISTRY_NAME = f"{REGISTRY_PREFIX}*{REGISTRY_SUFFIX}"
SESSION_STATE_NAME = "M1C01_SESSION_STATE.json"
ATTACHMENT_RESULT_NAME = "M1C01_ATTACHMENT_RESULT.json"
ATTACHMENT_CONTRACT_VERSION = "M1C01_ATTACH_EXACT_PATHS_V2"
ORCHESTRATOR_VERSION = "3.7"
OUTPUT_BASENAME = "OFERTA_M1-C01_CANONICA"
ARTIFACT_NAMES = (
    "ENGINE_RESULT.json",
    f"{OUTPUT_BASENAME}.docx",
    f"{OUTPUT_BASENAME}.pdf",
    "EMAIL_REZUMAT_M1-C01.docx",
    "RAPORT_QA_GENERATOR.json",
    "PIPELINE_RESULT.json",
    "M1C01_LIVRABIL_CURENT.docx",
    "M1C01_LIVRABIL_CURENT.pdf",
    "M1C01_DELIVERY_MANIFEST.json",
    "M1C01_DELIVERY_LATEST.json",
    ATTACHMENT_RESULT_NAME,
)


class FXClarificationNeeded(RuntimeError):
    """Cursul nu a putut fi stabilit automat; operatorul trebuie să îl indice.

    Nu este eroare de execuție: pipeline-ul raportează NECESITA_CLARIFICARE, la
    fel ca la variantele de tip PF/PJ neprecizate.
    """

    def __init__(self, code: str, message: str, details: Dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


class OrchestratorError(RuntimeError):
    def __init__(self, code: str, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


@dataclass(frozen=True)
class CanonicalFiles:
    engine: Path
    generator: Path


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _json_dump(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _case_sha256(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(_canonical_json_bytes(payload)).hexdigest()


def _new_run_id(case_sha256: str) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    return f"{stamp}_{case_sha256[:10]}"


def _load_json(path: Path) -> Dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise OrchestratorError("INPUT_NOT_FOUND", f"Fișierul de intrare nu există: {path}") from exc
    except json.JSONDecodeError as exc:
        raise OrchestratorError("INPUT_INVALID_JSON", f"JSON invalid în {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise OrchestratorError("INPUT_NOT_OBJECT", "Intrarea trebuie să fie un obiect JSON.")
    return value


def _resolve_candidates(root: Path, filename: str) -> list[Path]:
    direct = root / filename
    candidates = [direct] if direct.is_file() else []
    candidates.extend(p for p in root.rglob(filename) if p.is_file() and p != direct)
    unique: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        resolved = str(path.resolve())
        if resolved not in seen:
            seen.add(resolved)
            unique.append(path)
    return unique


def _select_exact_file(root: Path, filename: str, explicit: Optional[Path] = None) -> Path:
    if explicit is not None:
        if not explicit.is_file() or explicit.name != filename:
            raise OrchestratorError(
                "FILE_CANONIC_NOT_FOUND",
                f"Fișierul explicit nu este versiunea canonică cerută: {filename}",
                {"provided": str(explicit)},
            )
        return explicit.resolve()

    candidates = _resolve_candidates(root, filename)
    if not candidates:
        raise OrchestratorError("FILE_CANONIC_NOT_FOUND", f"Lipsește fișierul canonic {filename}.")

    # Multiple identical Knowledge copies are acceptable; conflicting binaries are not.
    by_hash: Dict[str, list[Path]] = {}
    for candidate in candidates:
        by_hash.setdefault(_sha256(candidate), []).append(candidate)
    if len(by_hash) > 1:
        raise OrchestratorError(
            "CONFLICTING_CANONICAL_FILES",
            f"Există copii binar diferite pentru {filename}.",
            {digest: [str(p) for p in paths] for digest, paths in by_hash.items()},
        )

    # Prefer the shallowest path, then lexical order.
    return sorted(candidates, key=lambda p: (len(p.parts), str(p)))[0].resolve()


def _version_key(path: Path, prefix: str, suffix: str) -> tuple[int, ...]:
    """Extrage versiunea numerică dintr-un nume `PREFIX<versiune>SUFIX`."""
    name = path.name
    if not (name.startswith(prefix) and name.endswith(suffix)):
        return ()
    raw = name[len(prefix):-len(suffix)]
    try:
        return tuple(int(part) for part in raw.split("."))
    except ValueError:
        return ()


def _engine_version_key(path: Path) -> tuple[int, ...]:
    return _version_key(path, ENGINE_PREFIX, ENGINE_SUFFIX)


def _select_versioned_component(
    root: Path,
    prefix: str,
    suffix: str,
    label: str,
    explicit: Optional[Path] = None,
    *,
    require_numeric_version: bool = True,
) -> Path:
    """Descoperă exact o versiune activă a unei componente versionate.

    Aceeași disciplină aplicată motorului începând cu V3.3: se caută întâi la
    rădăcina Knowledge, apoi recursiv. Coexistența mai multor versiuni sau a
    unor copii binar diferite ale aceleiași versiuni oprește fail-closed.
    Orchestratorul nu alege niciodată singur între versiuni.
    """
    def _key(path: Path) -> tuple[int, ...]:
        key = _version_key(path, prefix, suffix)
        if key or not require_numeric_version:
            return key or (0,)
        return ()

    if explicit is not None:
        if not explicit.is_file():
            raise OrchestratorError(
                "FILE_CANONIC_NOT_FOUND",
                f"Fișierul explicit indicat pentru {label} nu există.",
                {"provided": str(explicit)},
            )
        return explicit.resolve()

    direct = sorted(
        (p for p in root.glob(f"{prefix}*{suffix}") if p.is_file() and _key(p)),
        key=_key,
    )
    candidates = direct
    if not candidates:
        candidates = sorted(
            (p for p in root.rglob(f"{prefix}*{suffix}") if p.is_file() and _key(p)),
            key=lambda p: (_key(p), len(p.parts), str(p)),
        )
    if not candidates:
        raise OrchestratorError(
            "FILE_CANONIC_NOT_FOUND",
            f"Lipsește componenta activă {label} ({prefix}*{suffix}).",
        )

    versions: Dict[str, list[Path]] = {}
    for candidate in candidates:
        version = ".".join(str(x) for x in _key(candidate))
        versions.setdefault(version, []).append(candidate)

    if len(versions) != 1:
        raise OrchestratorError(
            "MULTIPLE_ACTIVE_COMPONENT_VERSIONS",
            f"Există mai multe versiuni active pentru {label}; păstrați exact una.",
            {version: [str(p) for p in paths] for version, paths in versions.items()},
        )

    only_paths = next(iter(versions.values()))
    by_hash: Dict[str, list[Path]] = {}
    for candidate in only_paths:
        by_hash.setdefault(_sha256(candidate), []).append(candidate)
    if len(by_hash) > 1:
        raise OrchestratorError(
            "CONFLICTING_CANONICAL_FILES",
            f"Există copii binar diferite ale aceleiași versiuni pentru {label}.",
            {digest: [str(p) for p in paths] for digest, paths in by_hash.items()},
        )
    return sorted(only_paths, key=lambda p: (len(p.parts), str(p)))[0].resolve()


def _select_active_engine(root: Path, explicit: Optional[Path] = None) -> Path:
    if explicit is not None:
        if not explicit.is_file() or not _engine_version_key(explicit):
            raise OrchestratorError(
                "FILE_CANONIC_NOT_FOUND",
                "Fișierul explicit nu este un motor M1-C01 versionat valid.",
                {"provided": str(explicit)},
            )
        return explicit.resolve()

    # The Builder contract requires exactly one active engine version in Knowledge.
    # Search root-level first (normal Builder mount). Recursive fallback is accepted
    # only when it resolves to one version; multiple versions fail closed.
    direct = sorted(
        (p for p in root.glob(f"{ENGINE_PREFIX}*{ENGINE_SUFFIX}") if p.is_file() and _engine_version_key(p)),
        key=_engine_version_key,
    )
    candidates = direct
    if not candidates:
        candidates = sorted(
            (p for p in root.rglob(f"{ENGINE_PREFIX}*{ENGINE_SUFFIX}") if p.is_file() and _engine_version_key(p)),
            key=lambda p: (_engine_version_key(p), len(p.parts), str(p)),
        )

    if not candidates:
        raise OrchestratorError(
            "FILE_CANONIC_NOT_FOUND",
            "Lipsește motorul activ M1-C01 (08_M1C01_REFERENCE_ENGINE_V*.py).",
        )

    versions: Dict[str, list[Path]] = {}
    for candidate in candidates:
        version = ".".join(str(x) for x in _engine_version_key(candidate))
        versions.setdefault(version, []).append(candidate)

    if len(versions) != 1:
        raise OrchestratorError(
            "MULTIPLE_ACTIVE_ENGINE_VERSIONS",
            "Există mai multe versiuni de motor M1-C01 în Knowledge; păstrați exact una.",
            {version: [str(p) for p in paths] for version, paths in versions.items()},
        )

    only_paths = next(iter(versions.values()))
    by_hash: Dict[str, list[Path]] = {}
    for candidate in only_paths:
        by_hash.setdefault(_sha256(candidate), []).append(candidate)
    if len(by_hash) > 1:
        raise OrchestratorError(
            "CONFLICTING_CANONICAL_FILES",
            "Există copii binar diferite ale aceleiași versiuni de motor M1-C01.",
            {digest: [str(p) for p in paths] for digest, paths in by_hash.items()},
        )

    return sorted(only_paths, key=lambda p: (len(p.parts), str(p)))[0].resolve()


def locate_canonical_files(
    search_root: Path,
    engine_path: Optional[Path] = None,
    generator_path: Optional[Path] = None,
) -> CanonicalFiles:
    return CanonicalFiles(
        engine=_select_active_engine(search_root, engine_path),
        generator=_select_versioned_component(
            search_root, GENERATOR_PREFIX, GENERATOR_SUFFIX, "generator ofertă", generator_path
        ),
    )


def _load_module(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise OrchestratorError("MODULE_LOAD_FAILED", f"Nu poate fi încărcat modulul {path.name}.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _first(data: Mapping[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in data and data[key] is not None:
            return data[key]
    return default


def _bool(value: Any) -> Optional[bool]:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "da", "confirmat", "confirmed"}:
        return True
    if text in {"0", "false", "no", "nu", "neconfirmat", "unconfirmed"}:
        return False
    return None


def _person(value: Any) -> Any:
    if value is None:
        return None
    text = str(value).strip().upper()
    aliases = {
        "PF": "PF",
        "PERSOANA FIZICA": "PF",
        "PERSOANĂ FIZICĂ": "PF",
        "FIZICA": "PF",
        "FIZICĂ": "PF",
        "PJ": "PJ",
        "PERSOANA JURIDICA": "PJ",
        "PERSOANĂ JURIDICĂ": "PJ",
        "JURIDICA": "PJ",
        "JURIDICĂ": "PJ",
    }
    return aliases.get(text, text)


def _act(value: Any) -> str:
    text = str(value).strip().lower()
    aliases = {
        "opinion": "opinion",
        "opinie": "opinion",
        "opinie notariala": "opinion",
        "opinie notarială": "opinion",
        "antecontract": "antecontract",
        "promisiune": "antecontract",
        "sale": "sale",
        "vanzare": "sale",
        "vânzare": "sale",
        "contract de vanzare": "sale",
        "contract de vânzare": "sale",
        "mortgage": "mortgage",
        "ipoteca": "mortgage",
        "ipotecă": "mortgage",
        "contract de ipoteca": "mortgage",
        "contract de ipotecă": "mortgage",
        "refinantare": "mortgage",
        "refinanțare": "mortgage",
    }
    return aliases.get(text, text)


def _decimal(value: Any, field: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise OrchestratorError("INVALID_NUMBER", f"Valoare numerică invalidă: {field}.") from exc
    if not result.is_finite() or result < 0:
        raise OrchestratorError("INVALID_NUMBER", f"Valoare numerică negativă sau ne-finită: {field}.")
    return result


def _scope_values(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {"ambele", "both", "sale_and_mortgage", "vanzare_si_ipoteca", "vânzare și ipotecă"}:
            return ["sale", "mortgage"]
        raw = [part.strip() for part in text.replace("+", ",").replace("/", ",").split(",") if part.strip()]
    elif isinstance(value, (list, tuple, set)):
        raw = list(value)
    else:
        raw = [value]
    aliases = {
        "sale": "sale", "vanzare": "sale", "vânzare": "sale", "contract de vanzare": "sale", "contract de vânzare": "sale",
        "mortgage": "mortgage", "ipoteca": "mortgage", "ipotecă": "mortgage", "refinantare": "mortgage", "refinanțare": "mortgage",
    }
    result: list[str] = []
    for item in raw:
        key = str(item).strip().lower()
        mapped = aliases.get(key, key)
        if mapped not in result:
            result.append(mapped)
    return result


def _quantity(value: Any, field: str) -> int:
    d = _decimal(value, field)
    if d != d.to_integral_value():
        raise OrchestratorError("INVALID_QUANTITY", f"Cantitatea trebuie să fie întreagă: {field}.")
    return int(d)


def normalize_case(case: Mapping[str, Any]) -> Dict[str, Any]:
    """Normalize a compact case envelope without changing canonical formulas."""
    raw_acts = _first(case, "acts", "acte", "operations")
    if isinstance(raw_acts, str):
        raw_acts = [part.strip() for part in raw_acts.replace("+", ",").split(",") if part.strip()]
    if not isinstance(raw_acts, list) or not raw_acts:
        raise OrchestratorError("MISSING_ACTS", "Lipsesc actele speței.")
    acts = [_act(v) for v in raw_acts]

    currency = str(_first(case, "currency", "moneda", default="EUR")).strip().upper()
    normalized: Dict[str, Any] = {
        "acts": acts,
        "buyer_type": _person(_first(case, "buyer_type", "cumparator_tip", "promitent_cumparator_tip", "debtor_type")),
        "seller_type": _person(_first(case, "seller_type", "vanzator_tip", "promitent_vanzator_tip")),
        "client": _first(case, "client", "client_name", "nume_client", default="—") or "—",
        "broker": _first(case, "broker", "intermediar", "agent", "agent_name", default="—") or "—",
        "currency": currency,
    }
    buyer_name = _first(
        case,
        "buyer_name", "cumparator_nume", "nume_cumparator",
        "promitent_buyer_name", "promitent_cumparator_nume",
        "debtor_name", "debitor_nume", "constituitor_name", "constituitor_nume",
    )
    seller_name = _first(
        case,
        "seller_name", "vanzator_nume", "nume_vanzator",
        "promitent_seller_name", "promitent_vanzator_nume",
    )
    if buyer_name not in (None, "", "—", "-"):
        normalized["buyer_name"] = str(buyer_name).strip()
    if seller_name not in (None, "", "—", "-"):
        normalized["seller_name"] = str(seller_name).strip()

    for target, aliases in {
        "price": ("price", "pret", "pret_imobil"),
        "advance": ("advance", "avans", "suma_antecontract"),
        "own_funds": ("own_funds", "surse_proprii"),
        "credit": ("credit", "credit_ipotecar", "valoare_credit"),
    }.items():
        value = _first(case, *aliases)
        if value is not None:
            normalized[target] = value

    # Financing percentages are accepted only when price is known and percentages are coherent.
    own_pct = _first(case, "own_funds_percent", "procent_surse_proprii")
    credit_pct = _first(case, "credit_percent", "procent_credit")
    if own_pct is not None or credit_pct is not None:
        if "price" not in normalized:
            raise OrchestratorError("MISSING_PRICE", "Procentele de finanțare necesită prețul.")
        price = _decimal(normalized["price"], "price")
        own = _decimal(own_pct if own_pct is not None else Decimal("100") - _decimal(credit_pct, "credit_percent"), "own_funds_percent")
        credit = _decimal(credit_pct if credit_pct is not None else Decimal("100") - own, "credit_percent")
        if own + credit != Decimal("100"):
            raise OrchestratorError("FINANCING_PERCENT_MISMATCH", "Procentele surse proprii + credit trebuie să fie 100%.")
        normalized["own_funds"] = format(price * own / Decimal("100"), "f")
        normalized["credit"] = format(price * credit / Decimal("100"), "f")

    advance_from_own = _bool(_first(case, "advance_equals_own_funds_confirmed", "avans_egal_surse_proprii", "advance_from_own_funds"))
    if advance_from_own is True:
        normalized["advance_equals_own_funds_confirmed"] = True
        if "advance" in normalized and "own_funds" not in normalized:
            normalized["own_funds"] = normalized["advance"]
        elif "own_funds" in normalized and "advance" not in normalized:
            normalized["advance"] = normalized["own_funds"]
    elif advance_from_own is False:
        normalized["advance_equals_own_funds_confirmed"] = False

    # A directly stated payment at antecontract is the advance; no second confirmation is needed.
    if "antecontract" in acts and "advance" in normalized:
        if "own_funds" in normalized and _decimal(normalized["advance"], "advance") == _decimal(normalized["own_funds"], "own_funds"):
            normalized["advance_equals_own_funds_confirmed"] = True

    seller_tax = _first(case, "seller_tax_percent", "impozit_vanzator", "cota_impozit")
    held_over_three = _bool(_first(
        case,
        "seller_owned_more_than_3_years",
        "seller_held_more_than_3_years",
        "dobandit_peste_3_ani",
        "detinut_peste_3_ani",
    ))
    if seller_tax is not None:
        normalized["seller_tax_percent"] = int(_decimal(seller_tax, "seller_tax_percent"))
    elif normalized.get("seller_type") == "PF" and held_over_three is True:
        # Local M1-C01 normalization approved by the operator; not a CORE rule.
        normalized["seller_tax_percent"] = 1

    _uzu = _first(case, "usufruct_uplift", "uzufruct", "cu_uzufruct")
    if _uzu is None and isinstance(case.get("sale"), Mapping):
        _uzu = _first(case["sale"], "usufruct_uplift", "uzufruct")
    if _uzu is not None:
        if not isinstance(_uzu, bool):
            raise OrchestratorError("INVALID_USUFRUCT_FLAG", "usufruct_uplift trebuie sa fie boolean (true/false).")
        normalized["usufruct_uplift"] = _uzu

    increase_percent = _first(
        case,
        "honorarium_increase_percent",
        "majorare_onorariu_percent",
        "procent_majorare_onorariu",
    )
    raw_adjustment = _first(case, "honorarium_adjustment", "ajustare_onorariu")
    if isinstance(raw_adjustment, Mapping):
        if increase_percent is None:
            increase_percent = _first(raw_adjustment, "percent", "procent")
        raw_scope = _first(raw_adjustment, "scope", "acte")
    else:
        raw_scope = None
    if raw_scope is None:
        raw_af = _first(case, "additional_fees", "taxe_suplimentare")
    if raw_af:
        normalized["additional_fees"] = raw_af
    raw_scope = _first(case, "honorarium_increase_scope", "majorare_onorariu_scope", "acte_majorate")
    if increase_percent is not None:
        pct = _decimal(increase_percent, "honorarium_increase_percent")
        scope = _scope_values(raw_scope)
        available = [act for act in ("sale", "mortgage") if act in acts]
        if not scope:
            if len(available) == 1:
                scope = available
            elif len(available) > 1:
                raise OrchestratorError(
                    "HONORARIUM_SCOPE_REQUIRED",
                    "Precizați dacă majorarea onorariului se aplică vânzării, ipotecii sau ambelor.",
                )
            else:
                raise OrchestratorError(
                    "HONORARIUM_SCOPE_NOT_APPLICABLE",
                    "Majorarea onorariului este disponibilă numai pentru vânzare și/sau ipotecă.",
                )
        if any(item not in {"sale", "mortgage"} for item in scope):
            raise OrchestratorError("INVALID_HONORARIUM_SCOPE", "Scope-ul majorării onorariului este invalid.")
        if any(item not in acts for item in scope):
            raise OrchestratorError("HONORARIUM_SCOPE_NOT_IN_CASE", "Scope-ul majorării include un act absent din speță.")
        normalized["honorarium_adjustment"] = {"percent": format(pct, "f"), "scope": scope}

    raw_quantities = _first(case, "component_quantities", "cantitati_componente") or {}
    if not isinstance(raw_quantities, Mapping):
        raise OrchestratorError("INVALID_COMPONENT_QUANTITIES", "Cantitățile componentelor trebuie să fie un obiect.")
    aliases = {
        "opinion_information_extracts": ("opinion_information_extracts", "opinie_extrase_informare"),
        "opinion_notation_count": ("opinion_notation_count", "opinion_notations", "opinie_notari_carte_funciara", "opinie_notari_cf"),
        "antecontract_buyer_verifications": ("antecontract_buyer_verifications", "antecontract_verificari_cumparator"),
        "antecontract_notation_count": ("antecontract_notation_count", "antecontract_notations", "pv_notation_count", "pv_notari_carte_funciara", "antecontract_notari_cf"),
        "antecontract_seller_information_extracts": ("antecontract_seller_information_extracts", "antecontract_extrase_informare_vanzator"),
        "antecontract_seller_verifications": ("antecontract_seller_verifications", "antecontract_verificari_vanzator"),
        "sale_buyer_verifications": ("sale_buyer_verifications", "vanzare_verificari_cumparator"),
        "sale_seller_authentication_extracts": ("sale_seller_authentication_extracts", "vanzare_extrase_autentificare_vanzator"),
        "sale_seller_information_extracts": ("sale_seller_information_extracts", "vanzare_extrase_informare", "vanzare_extrase_informare_vanzator"),
        "sale_seller_verifications": ("sale_seller_verifications", "vanzare_verificari_vanzator"),
        "sale_notation_count": ("sale_notation_count", "sale_notations", "vanzare_notari_carte_funciara", "vanzare_notari_cf"),
        # PATCH V4.11 (25.08.2026, tichet radiere): cantitatile radierii erau ignorate silentios (fail-open) —
        # motorul (V1.17) si schema (V1.13) le cunosc, tabelul de aliasuri nu le avea.
        "radiere_information_extracts": ("radiere_information_extracts", "radiere_extrase_informare"),
        "radiere_notation_count": ("radiere_notation_count", "radiere_notations", "radiere_radieri_carte_funciara", "radiere_radieri_cf", "radiere_notari_cf", "radieri_cf"),
        "mortgage_bank_proxy_checks": ("mortgage_bank_proxy_checks", "ipoteca_verificari_procuri_bancare"),
        "mortgage_legalized_copies": ("mortgage_legalized_copies", "ipoteca_copii_legalizate"),
        "mortgage_buyer_verifications": ("mortgage_buyer_verifications", "ipoteca_verificari_debitor"),
        "mortgage_authentication_extracts": ("mortgage_authentication_extracts", "ipoteca_extrase_autentificare"),
        "mortgage_notation_count": ("mortgage_notation_count", "mortgage_notations", "ipoteca_notari_carte_funciara", "ipoteca_notari_cf", "taxe_notare_ipoteca"),
        "mortgage_additional_collateral_properties": (
            "mortgage_additional_collateral_properties",
            "ipoteca_imobile_suplimentare_in_garantie",
            "ipoteca_bunuri_suplimentare_in_garantie",
            "additional_collateral_properties",
        ),
    }
    quantities: Dict[str, int] = {}
    for target, keys in aliases.items():
        value = _first(raw_quantities, *keys, default=_first(case, *keys))
        if value is not None:
            quantities[target] = _quantity(value, target)
    # Total collateral properties include the primary property already covered by the base 100 lei.
    total_collateral = _first(
        raw_quantities,
        "mortgage_total_collateral_properties",
        "ipoteca_total_imobile_in_garantie",
        "ipoteca_numar_total_imobile_garantie",
        "collateral_properties_total",
        default=_first(
            case,
            "mortgage_total_collateral_properties",
            "ipoteca_total_imobile_in_garantie",
            "ipoteca_numar_total_imobile_garantie",
            "collateral_properties_total",
        ),
    )
    if total_collateral is not None:
        if "mortgage" not in acts:
            raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Imobilele aduse în garanție sunt aplicabile numai ipotecii.")
        total_qty = _quantity(total_collateral, "mortgage_total_collateral_properties")
        derived_additional = max(total_qty - 1, 0)
        explicit_additional = quantities.get("mortgage_additional_collateral_properties")
        if explicit_additional is not None and explicit_additional != derived_additional:
            raise OrchestratorError(
                "COLLATERAL_PROPERTY_COUNT_CONFLICT",
                "Numărul total al imobilelor în garanție contrazice numărul imobilelor suplimentare.",
                {"total": total_qty, "additional": explicit_additional},
            )
        quantities["mortgage_additional_collateral_properties"] = derived_additional

    # Safe unscoped aliases are resolved only when the target is unambiguous.
    def set_quantity(target: str, value: Any, source: str) -> None:
        qty = _quantity(value, target)
        if target in quantities and quantities[target] != qty:
            raise OrchestratorError(
                "COMPONENT_QUANTITY_CONFLICT",
                f"Cantitatea pentru {target} este contradictorie.",
                {"existing": quantities[target], "incoming": qty, "source": source},
            )
        quantities[target] = qty

    generic_auth = _first(raw_quantities, "authentication_extracts", "extrase_autentificare", default=_first(case, "authentication_extracts", "extrase_autentificare"))
    if generic_auth is not None:
        target = "sale_seller_authentication_extracts" if "sale" in acts else "mortgage_authentication_extracts" if "mortgage" in acts else None
        if target is None:
            raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Extrasele de autentificare nu sunt aplicabile speței.")
        set_quantity(target, generic_auth, "authentication_extracts")

    # Generic «extrase de carte funciară» are routed deterministically by the acts.
    # Sale takes precedence in combined sale+mortgage cases because the final authentication
    # extract is charged to the seller and the mortgage branch deduplicates it.
    generic_land_extracts = _first(
        raw_quantities,
        "land_registry_extracts", "extrase_carte_funciara", "extrase_cf",
        default=_first(case, "land_registry_extracts", "extrase_carte_funciara", "extrase_cf"),
    )
    if generic_land_extracts is not None:
        extract_type_raw = _first(
            raw_quantities,
            "land_registry_extract_type", "tip_extrase_carte_funciara", "tip_extrase_cf",
            default=_first(case, "land_registry_extract_type", "tip_extrase_carte_funciara", "tip_extrase_cf"),
        )
        extract_scope_raw = _first(
            raw_quantities,
            "land_registry_extract_scope", "act_extrase_carte_funciara", "scope_extrase_cf",
            default=_first(case, "land_registry_extract_scope", "act_extrase_carte_funciara", "scope_extrase_cf"),
        )
        type_aliases = {
            "authentication": "authentication", "autentificare": "authentication", "auth": "authentication",
            "information": "information", "informare": "information", "info": "information",
        }
        scope_aliases = {
            "opinion": "opinion", "opinie": "opinion",
            "antecontract": "antecontract", "p-v": "antecontract", "pv": "antecontract", "promisiune": "antecontract",
            "sale": "sale", "vanzare": "sale", "vânzare": "sale", "cvc": "sale",
            "mortgage": "mortgage", "ipoteca": "mortgage", "ipotecă": "mortgage", "ip": "mortgage",
        }
        extract_type = type_aliases.get(str(extract_type_raw).strip().lower()) if extract_type_raw is not None else None
        extract_scope = scope_aliases.get(str(extract_scope_raw).strip().lower()) if extract_scope_raw is not None else None
        if extract_type_raw is not None and extract_type is None:
            raise OrchestratorError("INVALID_EXTRACT_TYPE", "Tipul extraselor trebuie să fie autentificare sau informare.")
        if extract_scope_raw is not None and extract_scope is None:
            raise OrchestratorError("INVALID_EXTRACT_SCOPE", "Actul extraselor de carte funciară este invalid.")
        if extract_scope is not None and extract_scope not in acts:
            raise OrchestratorError("COMPONENT_SCOPE_NOT_IN_CASE", "Actul indicat pentru extrase nu există în speță.")

        target: Optional[str] = None
        if extract_scope == "sale":
            if extract_type == "information":
                raise OrchestratorError("EXTRACT_TYPE_SCOPE_CONFLICT", "Vânzarea utilizează extrase de autentificare.")
            target = "sale_seller_authentication_extracts"
        elif extract_scope == "mortgage":
            if extract_type == "information":
                raise OrchestratorError("EXTRACT_TYPE_SCOPE_CONFLICT", "Ipoteca utilizează extrase de autentificare.")
            target = "mortgage_authentication_extracts"
        elif extract_scope == "opinion":
            if extract_type == "authentication":
                raise OrchestratorError("EXTRACT_TYPE_SCOPE_CONFLICT", "Opinia utilizează extrase de informare.")
            target = "opinion_information_extracts"
        elif extract_scope == "antecontract":
            if extract_type == "authentication":
                raise OrchestratorError("EXTRACT_TYPE_SCOPE_CONFLICT", "Promisiunea de vânzare utilizează extrase de informare.")
            target = "antecontract_seller_information_extracts"
        elif extract_type == "authentication":
            target = "sale_seller_authentication_extracts" if "sale" in acts else "mortgage_authentication_extracts" if "mortgage" in acts else None
            if target is None:
                raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Nu există un act care utilizează extrase de autentificare.")
        elif extract_type == "information":
            # PATCH V4.2 (decizia titularului 13.08.2026): informarea este permisa
            # si la vanzare (ex. radierea unei servituti de trecere).
            info_targets = []
            if "sale" in acts:
                info_targets.append("sale_seller_information_extracts")
            if "opinion" in acts:
                info_targets.append("opinion_information_extracts")
            if "antecontract" in acts:
                info_targets.append("antecontract_seller_information_extracts")
            if "radiere" in acts:
                info_targets.append("radiere_information_extracts")  # PATCH V4.11
            if len(info_targets) != 1:
                raise OrchestratorError("COMPONENT_SCOPE_REQUIRED", "Precizați cărui act îi aparțin extrasele de informare (vânzare / opinie / promisiune).")
            target = info_targets[0]
        else:
            if "sale" in acts:
                target = "sale_seller_authentication_extracts"
            elif "mortgage" in acts:
                target = "mortgage_authentication_extracts"
            elif "opinion" in acts and "antecontract" not in acts:
                target = "opinion_information_extracts"
            elif "antecontract" in acts and "opinion" not in acts:
                target = "antecontract_seller_information_extracts"
            elif "opinion" in acts and "antecontract" in acts:
                raise OrchestratorError("COMPONENT_SCOPE_REQUIRED", "Precizați dacă extrasele de carte funciară aparțin opiniei sau promisiunii de vânzare.")
            elif "radiere" in acts:
                target = "radiere_information_extracts"  # PATCH V4.11
            else:
                raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Extrasele de carte funciară nu sunt aplicabile speței.")
        set_quantity(target, generic_land_extracts, "land_registry_extracts")

    # Generic land-book notation fee (75 lei/unit) is available on every act branch.
    generic_notations = _first(
        raw_quantities,
        "land_book_notation_count", "notari_carte_funciara", "notari_cf", "numar_notari", "taxe_notare_cf",
        default=_first(case, "land_book_notation_count", "notari_carte_funciara", "notari_cf", "numar_notari", "taxe_notare_cf"),
    )
    if generic_notations is not None:
        notation_scope_raw = _first(
            raw_quantities,
            "land_book_notation_scope", "act_notari_carte_funciara", "scope_notari_cf",
            default=_first(case, "land_book_notation_scope", "act_notari_carte_funciara", "scope_notari_cf"),
        )
        notation_scope_aliases = {
            "opinion": "opinion", "opinie": "opinion", "op": "opinion",
            "antecontract": "antecontract", "p-v": "antecontract", "pv": "antecontract", "promisiune": "antecontract",
            "sale": "sale", "vanzare": "sale", "vânzare": "sale", "cvc": "sale",
            "mortgage": "mortgage", "ipoteca": "mortgage", "ipotecă": "mortgage", "ip": "mortgage",
            "radiere": "radiere", "declaratie_radiere": "radiere", "declarație_radiere": "radiere",  # PATCH V4.11
            "all": "all_present_acts", "toate": "all_present_acts", "fiecare": "all_present_acts",
            "all_present_acts": "all_present_acts", "toate_actele": "all_present_acts",
        }
        notation_scope = notation_scope_aliases.get(str(notation_scope_raw).strip().lower()) if notation_scope_raw is not None else None
        if notation_scope_raw is not None and notation_scope is None:
            raise OrchestratorError("INVALID_NOTATION_SCOPE", "Actul notării în cartea funciară este invalid.")
        target_by_act = {
            "opinion": "opinion_notation_count",
            "antecontract": "antecontract_notation_count",
            "sale": "sale_notation_count",
            "mortgage": "mortgage_notation_count",
            "radiere": "radiere_notation_count",  # PATCH V4.11
        }
        if notation_scope == "all_present_acts":
            for act in acts:
                set_quantity(target_by_act[act], generic_notations, "land_book_notation_count:all_present_acts")
        else:
            if notation_scope is not None:
                if notation_scope not in acts:
                    raise OrchestratorError("COMPONENT_SCOPE_NOT_IN_CASE", "Actul indicat pentru notare nu există în speță.")
                notation_target = target_by_act[notation_scope]
            elif len(acts) == 1:
                notation_target = target_by_act[acts[0]]
            else:
                raise OrchestratorError(
                    "COMPONENT_SCOPE_REQUIRED",
                    "Precizați actul pentru taxa de notare de 75 lei: opinie, P-V, vânzare, ipotecă sau toate actele prezente.",
                )
            set_quantity(notation_target, generic_notations, "land_book_notation_count")

    generic_legal = _first(raw_quantities, "legalized_copies", "copii_legalizate", default=_first(case, "legalized_copies", "copii_legalizate"))
    if generic_legal is not None:
        if "mortgage" not in acts:
            raise OrchestratorError("COMPONENT_NOT_IN_CASE", "Copiile legalizate sunt configurabile în ramura ipotecii.")
        quantities["mortgage_legalized_copies"] = _quantity(generic_legal, "mortgage_legalized_copies")
    generic_info = _first(raw_quantities, "information_extracts", "extrase_informare", default=_first(case, "information_extracts", "extrase_informare"))
    if generic_info is not None:
        targets = []
        if "opinion" in acts:
            targets.append("opinion_information_extracts")
        if "antecontract" in acts:
            targets.append("antecontract_seller_information_extracts")
        if len(targets) != 1:
            raise OrchestratorError("COMPONENT_SCOPE_REQUIRED", "Precizați dacă extrasele de informare aparțin opiniei sau antecontractului.")
        quantities[targets[0]] = _quantity(generic_info, targets[0])
    generic_marital = _first(raw_quantities, "marital_regime_checks", "verificari_regim_matrimonial", default=_first(case, "marital_regime_checks", "verificari_regim_matrimonial"))
    if generic_marital is not None:
        candidates = []
        if acts == ["mortgage"] and normalized.get("buyer_type") == "PF":
            candidates.append("mortgage_buyer_verifications")
        elif acts == ["antecontract"]:
            if normalized.get("buyer_type") == "PF": candidates.append("antecontract_buyer_verifications")
            if normalized.get("seller_type") == "PF": candidates.append("antecontract_seller_verifications")
        elif "sale" in acts:
            if normalized.get("buyer_type") == "PF": candidates.append("sale_buyer_verifications")
            if normalized.get("seller_type") == "PF": candidates.append("sale_seller_verifications")
        if len(candidates) != 1:
            raise OrchestratorError("COMPONENT_SCOPE_REQUIRED", "Precizați partea/actul pentru verificările de regim matrimonial.")
        quantities[candidates[0]] = _quantity(generic_marital, candidates[0])
    notation_fields = {
        "opinion_notation_count": ("opinion", "Notările opiniei sunt aplicabile numai opiniei notariale."),
        "antecontract_notation_count": ("antecontract", "Notările P-V sunt aplicabile numai P-V/antecontractului."),
        "sale_notation_count": ("sale", "Notările vânzării sunt aplicabile numai contractului de vânzare."),
        "mortgage_notation_count": ("mortgage", "Notările ipotecii sunt aplicabile numai contractului de ipotecă."),
        "radiere_notation_count": ("radiere", "Radierile din cartea funciară sunt aplicabile numai declarației de radiere."),  # PATCH V4.11
        "radiere_information_extracts": ("radiere", "Extrasele de informare ale radierii sunt aplicabile numai declarației de radiere."),  # PATCH V4.11
    }
    for field, (act, message) in notation_fields.items():
        if field in quantities and act not in acts:
            raise OrchestratorError("COMPONENT_NOT_IN_CASE", message)
    if quantities:
        normalized["component_quantities"] = quantities

    fx = _first(case, "fx", "curs") or {}
    if not isinstance(fx, Mapping):
        raise OrchestratorError("INVALID_FX", "Câmpul fx/curs trebuie să fie un obiect.")
    if currency == "EUR":
        rate = _first(fx, "rate", "rata", default=_first(case, "fx_rate", "curs_valutar"))
        publication = _first(fx, "publication_date", "data_publicarii", default=_first(case, "fx_publication_date", "data_publicare_curs"))
        effective = _first(fx, "effective_date", "data_aplicarii", default=_first(case, "fx_effective_date", "data_calculului"))
        source = _first(fx, "source", "sursa", default=_first(case, "fx_source", "sursa_curs"))
        if rate is None:
            raise OrchestratorError(
                "MISSING_FX_RATE",
                "Lipsește cursul valutar verificat. Furnizați un override al operatorului sau FX_EVIDENCE verificat.",
            )
        if not publication or not effective or not source:
            raise OrchestratorError("MISSING_FX_METADATA", "Metadatele cursului sunt incomplete.")
        _decimal(rate, "fx.rate")
        normalized["fx"] = {
            "rate": rate,
            "publication_date": str(publication),
            "effective_date": str(effective),
            "source": str(source),
            "operator_override": _bool(_first(fx, "operator_override", default=_first(case, "operator_override"))) is True,
        }
    elif currency == "RON":
        normalized["fx"] = {"rate": 1, "publication_date": "N/A", "effective_date": "N/A", "source": "RON"}

    if _bool(_first(case, "finalization_requested", "finalizare_solicitata")) is True:
        normalized["finalization_requested"] = True

    return normalized




def _requested_formats(case: Mapping[str, Any]) -> tuple[list[str], bool]:
    """Return user-facing formats. Internal generation remains DOCX + PDF."""
    raw = _first(
        case,
        "requested_formats",
        "delivery_formats",
        "formats",
        "format",
        "livrabile",
        "format_solicitat",
    )
    if raw is None:
        return ["docx", "pdf", "email_docx"], True
    if isinstance(raw, str):
        text = raw.strip().lower()
        if text in {"ambele", "both", "docx+pdf", "pdf+docx", "word si pdf", "word și pdf"}:
            raw_values = ["docx", "pdf"]
        else:
            raw_values = [part.strip() for part in text.replace("+", ",").replace("/", ",").split(",") if part.strip()]
    elif isinstance(raw, (list, tuple, set)):
        raw_values = list(raw)
    else:
        raw_values = [raw]

    aliases = {
        "docx": "docx", "word": "docx", "document word": "docx", ".docx": "docx",
        "pdf": "pdf", ".pdf": "pdf",
        # `email_docx` este valoarea canonică din Input Schema V1.7 și lipsea din
        # tabelul de aliasuri, deci o cerere conformă cu propria schemă era respinsă.
        "email_docx": "email_docx", "email": "email_docx", "email docx": "email_docx",
        "word email": "email_docx", "email_word": "email_docx", "emaildocx": "email_docx",
    }
    selected: list[str] = []
    for value in raw_values:
        key = str(value).strip().lower()
        fmt = aliases.get(key)
        if fmt and fmt not in selected:
            selected.append(fmt)
    if not selected:
        raise OrchestratorError(
            "INVALID_DELIVERY_FORMAT",
            "Formatul solicitat trebuie să fie DOCX, PDF și/sau Word-ul de e-mail.",
            {"provided": raw},
        )
    if "email_docx" not in selected:
        selected.append("email_docx")
    return selected, False




def _meaningful_text(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text in {"—", "-", "N/A", "n/a", "none", "None"}:
        return None
    return text


def _ascii_name(value: Any, *, max_len: int = 48) -> Optional[str]:
    text = _meaningful_text(value)
    if text is None:
        return None
    folded = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    folded = folded.upper().replace("&", " SI ")
    folded = re.sub(r"[^A-Z0-9]+", "-", folded).strip("-")
    folded = re.sub(r"-+", "-", folded)
    if not folded:
        return None
    return folded[:max_len].rstrip("-") or None


def _act_delivery_code(acts: Iterable[Any]) -> str:
    ordered = ("opinion", "antecontract", "sale", "mortgage")
    codes = {"opinion": "OP", "antecontract": "P-V", "sale": "CVC", "mortgage": "IP"}
    selected = {str(v) for v in acts}
    parts = [codes[act] for act in ordered if act in selected]
    return "-".join(parts) or "DOSAR"


def _delivery_identity(normalized: Mapping[str, Any]) -> str:
    client = _ascii_name(normalized.get("client"))
    if client:
        return client
    buyer = _ascii_name(normalized.get("buyer_name"))
    seller = _ascii_name(normalized.get("seller_name"))
    if buyer and seller:
        return buyer if buyer == seller else f"{buyer}-{seller}"
    if buyer:
        return buyer
    if seller:
        return seller
    broker = _ascii_name(normalized.get("broker"))
    if broker:
        return f"AG-{broker}"
    return "DOSAR"


def _delivery_slug(normalized: Mapping[str, Any]) -> str:
    """Human-readable stable stem. Run uniqueness is added separately."""
    act_code = _act_delivery_code(normalized.get("acts", []))
    identity = _delivery_identity(normalized)
    local_date = datetime.now(ZoneInfo("Europe/Bucharest")).strftime("%Y-%m-%d")
    return f"{act_code}_{identity}_{local_date}"


def _short_run_token(run_id: str) -> str:
    return hashlib.sha256(run_id.encode("utf-8")).hexdigest()[:6].upper()


def _public_delivery_base(delivery_stem: str, run_id: str) -> str:
    return f"{delivery_stem}_{_short_run_token(run_id)}"


def _party_type_variant_request(normalized: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
    """Return a controlled PF/PJ choice request without selecting a variant."""
    acts = set(normalized.get("acts", []))
    buyer_required = bool(acts.intersection({"antecontract", "sale", "mortgage"}))
    seller_required = bool(acts.intersection({"antecontract", "sale"}))

    missing: list[str] = []
    if buyer_required and normalized.get("buyer_type") not in {"PF", "PJ"}:
        missing.append("buyer_type")
    if seller_required and normalized.get("seller_type") not in {"PF", "PJ"}:
        missing.append("seller_type")
    if not missing:
        return None

    buyer_values = [normalized.get("buyer_type")] if "buyer_type" not in missing else ["PF", "PJ"]
    seller_values = [normalized.get("seller_type")] if "seller_type" not in missing else ["PF", "PJ"]
    if not seller_required:
        seller_values = [None]

    if acts == {"mortgage"}:
        buyer_role = "Debitor / constituitor"
    elif "antecontract" in acts and "sale" not in acts:
        buyer_role = "Promitent-cumpărător"
    else:
        buyer_role = "Cumpărător"
    seller_role = "Promitent-vânzător" if "antecontract" in acts and "sale" not in acts else "Vânzător"

    variants: list[Dict[str, Any]] = []
    for buyer in buyer_values:
        for seller in seller_values:
            option: Dict[str, Any] = {"buyer_type": buyer}
            labels = [f"{buyer_role}: {buyer}"]
            if seller_required:
                option["seller_type"] = seller
                labels.append(f"{seller_role}: {seller}")
            option["id"] = "_".join(v for v in (buyer, seller) if v)
            option["label"] = " / ".join(labels)
            variants.append(option)

    if missing == ["buyer_type"]:
        question = "Selectați tipul cumpărătorului/debitorului: PF sau PJ."
    elif missing == ["seller_type"]:
        question = "Selectați tipul vânzătorului: PF sau PJ."
    else:
        question = "Selectați combinația PF/PJ a cumpărătorului și vânzătorului."

    return {
        "status": "NECESITA_CLARIFICARE",
        "clarification_code": "PARTY_TYPE_VARIANTS_REQUIRED",
        "question": question,
        "missing_fields": missing,
        "variants": variants,
        "automatic_selection": False,
        "assumption_applied": False,
        "automatic_propagation": False,
        "human_approval_required": True,
    }


def _validate_fx_audit(
    case: Mapping[str, Any],
    fx_evidence_path: Optional[Path],
    fx_gate_result_path: Optional[Path],
) -> Dict[str, Any]:
    """Validate optional FX audit inputs and bind them to the current case.

    Backward compatibility: RON cases and legacy deterministic regression calls may
    omit these paths. For EUR cases using the active FX gate, Instructions V2.25
    require both files.
    """
    if fx_evidence_path is None and fx_gate_result_path is None:
        return {}
    if fx_evidence_path is None or fx_gate_result_path is None:
        raise OrchestratorError(
            "FX_AUDIT_PAIR_REQUIRED",
            "FX_EVIDENCE și FX_GATE_RESULT trebuie furnizate împreună.",
        )
    evidence = _load_json(fx_evidence_path)
    gate = _load_json(fx_gate_result_path)
    if gate.get("status") != "PASS":
        raise OrchestratorError(
            "FX_GATE_NOT_PASS",
            "Orchestratorul nu poate continua fără FX_GATE_RESULT.status=PASS.",
            {"gate_status": gate.get("status"), "error_code": gate.get("error_code")},
        )
    if evidence.get("status") not in {"VERIFIED", "NOT_APPLICABLE"}:
        raise OrchestratorError(
            "FX_EVIDENCE_NOT_VERIFIED",
            "FX_EVIDENCE nu este VERIFIED/NOT_APPLICABLE.",
            {"evidence_status": evidence.get("status")},
        )
    case_fx = case.get("fx") if isinstance(case.get("fx"), Mapping) else {}
    if str(case.get("currency", "EUR")).upper() != "RON":
        checks = {
            "rate": (case_fx.get("rate"), evidence.get("rate")),
            "publication_date": (case_fx.get("publication_date"), evidence.get("publication_date")),
            "effective_date": (case_fx.get("effective_date"), evidence.get("effective_date")),
            "source": (str(case_fx.get("source", "")).upper(), str(evidence.get("source", "")).upper()),
            "operator_override": (case_fx.get("operator_override"), evidence.get("operator_override")),
        }
        mismatches = {
            key: {"case": left, "evidence": right}
            for key, (left, right) in checks.items()
            if str(left) != str(right)
        }
        if mismatches:
            raise OrchestratorError(
                "FX_AUDIT_CASE_MISMATCH",
                "Metadatele FX din speță nu corespund dovezii validate.",
                mismatches,
            )
    return {"evidence": evidence, "gate": gate}


def _copy_run_bound_json(
    *,
    source: Path,
    run_dir: Path,
    output_dir: Path,
    delivery_stem: str,
    run_id: str,
    suffix: str,
) -> Dict[str, Any]:
    """Persist one JSON both inside the run directory and as a root run-bound copy."""
    run_destination = run_dir / f"{suffix}.json"
    if source.resolve() != run_destination.resolve():
        shutil.copy2(source, run_destination)
    root_destination = output_dir / f"{delivery_stem}_{run_id}_{suffix}.json"
    shutil.copy2(run_destination, root_destination)
    payload = _validate_artifact(root_destination)
    payload["run_path"] = str(run_destination)
    payload["run_id"] = run_id
    return payload


def _publish_success_audit(
    *,
    output_dir: Path,
    run_dir: Path,
    run_id: str,
    delivery_stem: str,
    sources: Mapping[str, Path],
) -> Dict[str, Any]:
    """Publish immutable root-level JSON audit copies for a successful run."""
    suffixes = {
        "case_snapshot": "CASE_SNAPSHOT",
        "normalized_case": "NORMALIZED_CASE",
        "engine_result": "ENGINE_RESULT",
        "qa_report": "RAPORT_QA_GENERATOR",
        "fx_evidence": "FX_EVIDENCE",
        "fx_gate_result": "FX_GATE_RESULT",
    }
    published: Dict[str, Any] = {}
    for key, source in sources.items():
        if key not in suffixes:
            continue
        published[key] = _copy_run_bound_json(
            source=source,
            run_dir=run_dir,
            output_dir=output_dir,
            delivery_stem=delivery_stem,
            run_id=run_id,
            suffix=suffixes[key],
        )
    published["pipeline_result"] = {
        "path": str(output_dir / f"{delivery_stem}_{run_id}_PIPELINE_RESULT.json"),
        "run_path": str(run_dir / "PIPELINE_RESULT.json"),
        "run_id": run_id,
    }
    return published


def _publish_delivery_artifacts(
    *,
    output_dir: Path,
    run_dir: Path,
    run_id: str,
    case_sha: str,
    requested_formats: list[str],
    delivery_stem: str,
    internal_artifacts: Mapping[str, Mapping[str, Any]],
) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """Copy current user-facing deliverables to root and bind them to the run."""
    source_by_format = {
        "docx": Path(str(internal_artifacts["docx"]["path"])),
        "pdf": Path(str(internal_artifacts["pdf"]["path"])),
        "email_docx": Path(str(internal_artifacts["email_docx"]["path"])),
    }
    delivery: Dict[str, Any] = {}
    public_base = _public_delivery_base(delivery_stem, run_id)
    for fmt in requested_formats:
        source = source_by_format[fmt]
        if fmt == "email_docx":
            destination = output_dir / f"{public_base}_EMAIL.docx"
        else:
            destination = output_dir / f"{public_base}.{fmt}"
        shutil.copy2(source, destination)
        delivery[fmt] = _validate_artifact(destination)
        delivery[fmt]["source_path"] = str(source)
        delivery[fmt]["run_id"] = run_id

    manifest_payload: Dict[str, Any] = {
        "status": "READY_FOR_HUMAN_REVIEW",
        "run_id": run_id,
        "run_directory": str(run_dir),
        "case_sha256": case_sha,
        "requested_formats": requested_formats,
        "delivery_artifacts": delivery,
        "internal_generation": ["docx", "pdf", "email_docx"],
        "human_approval_required": True,
        "automatic_send": False,
        "automatic_propagation": False,
        "core_modified": False,
    }
    run_manifest = run_dir / "DELIVERY_MANIFEST.json"
    root_manifest = output_dir / f"M1C01_DELIVERY_MANIFEST_{run_id}.json"
    latest_manifest = output_dir / "M1C01_DELIVERY_LATEST.json"
    _json_dump(run_manifest, manifest_payload)
    _json_dump(root_manifest, manifest_payload)
    _json_dump(latest_manifest, manifest_payload)
    manifests = {
        "run": _validate_artifact(run_manifest),
        "root": _validate_artifact(root_manifest),
        "latest": _validate_artifact(latest_manifest),
    }
    return delivery, manifests



def _publish_fail_closed_audit(
    *,
    output_dir: Path,
    run_dir: Path,
    run_id: str,
    delivery_stem: str,
    sources: Mapping[str, Path],
) -> Dict[str, Any]:
    """Publish run-bound audit JSON files for a fail-closed execution."""
    published: Dict[str, Any] = {}
    suffixes = {
        "engine_result": "ENGINE_RESULT",
        "variant_request": "VARIANT_REQUEST",
        "case_snapshot": "CASE_SNAPSHOT",
        "normalized_case": "NORMALIZED_CASE",
    }
    for key, source in sources.items():
        suffix = suffixes[key]
        destination = output_dir / f"{delivery_stem}_{run_id}_{suffix}.json"
        shutil.copy2(source, destination)
        published[key] = _validate_artifact(destination)
        published[key]["source_path"] = str(source)
        published[key]["run_id"] = run_id
    # PIPELINE_RESULT is written after the final payload is assembled.
    published["pipeline_result"] = {
        "path": str(output_dir / f"{delivery_stem}_{run_id}_PIPELINE_RESULT.json"),
        "run_id": run_id,
    }
    return published

def _clean_outputs(output_dir: Path) -> None:
    for name in ARTIFACT_NAMES:
        path = output_dir / name
        if path.exists():
            if path.is_file() or path.is_symlink():
                path.unlink()
            else:
                shutil.rmtree(path)


def _validate_artifact(path: Path) -> Dict[str, Any]:
    if not path.is_file():
        raise OrchestratorError("DELIVERABLE_MISSING", f"Lipsește livrabilul {path.name}.")
    size = path.stat().st_size
    if size <= 0:
        raise OrchestratorError("DELIVERABLE_EMPTY", f"Livrabilul {path.name} este gol.")
    return {"path": str(path), "size": size, "sha256": _sha256(path)}


def run_pipeline(
    case: Mapping[str, Any],
    *,
    output_dir: Path,
    search_root: Path,
    engine_path: Optional[Path] = None,
    generator_path: Optional[Path] = None,
    input_path: Optional[Path] = None,
    fx_evidence_path: Optional[Path] = None,
    fx_gate_result_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Run one immutable case in a unique directory and publish only a pointer result at root."""
    output_dir.mkdir(parents=True, exist_ok=True)
    # Root-level aliases from older versions are removed so they cannot be attached as current outputs.
    _clean_outputs(output_dir)

    canonical = locate_canonical_files(search_root, engine_path, generator_path)
    requested_formats, delivery_defaulted = _requested_formats(case)
    normalized = normalize_case(case)
    delivery_stem = _delivery_slug(normalized)
    case_sha = _case_sha256(case)
    run_id = _new_run_id(case_sha)
    run_dir = output_dir / f"M1C01_RUN_{run_id}"
    run_dir.mkdir(parents=True, exist_ok=False)

    case_snapshot_path = run_dir / "CASE_SNAPSHOT.json"
    normalized_path = run_dir / "NORMALIZED_CASE.json"
    _json_dump(case_snapshot_path, dict(case))
    _json_dump(normalized_path, normalized)

    fx_audit = _validate_fx_audit(case, fx_evidence_path, fx_gate_result_path)
    fx_run_sources: Dict[str, Path] = {}
    if fx_audit:
        fx_evidence_run = run_dir / "FX_EVIDENCE.json"
        fx_gate_run = run_dir / "FX_GATE_RESULT.json"
        shutil.copy2(fx_evidence_path, fx_evidence_run)
        shutil.copy2(fx_gate_result_path, fx_gate_run)
        fx_run_sources = {
            "fx_evidence": fx_evidence_run,
            "fx_gate_result": fx_gate_run,
        }

    input_file_sha = _sha256(input_path) if input_path is not None and input_path.is_file() else None

    common = {
        "run_id": run_id,
        "run_directory": str(run_dir),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "case_sha256": case_sha,
        "input_file_sha256": input_file_sha,
        "case_snapshot": {"path": str(case_snapshot_path), "sha256": _sha256(case_snapshot_path)},
        "normalized_case": {"path": str(normalized_path), "sha256": _sha256(normalized_path)},
        "orchestrator_version": ORCHESTRATOR_VERSION,
        "engine": {"name": canonical.engine.name, "path": str(canonical.engine), "sha256": _sha256(canonical.engine)},
        "generator": {"name": GENERATOR_NAME, "path": str(canonical.generator), "sha256": _sha256(canonical.generator)},
        "normalized_input": normalized,
        "fx_audit": {
            "provided": bool(fx_run_sources),
            "evidence": _validate_artifact(fx_run_sources["fx_evidence"]) if fx_run_sources else None,
            "gate_result": _validate_artifact(fx_run_sources["fx_gate_result"]) if fx_run_sources else None,
        },
        "delivery_request": {
            "requested_formats": requested_formats,
            "defaulted_to_docx_and_pdf": delivery_defaulted,
            "internal_generation": ["docx", "pdf", "email_docx"],
            "delivery_stem": delivery_stem,
            "public_delivery_base": _public_delivery_base(delivery_stem, run_id),
            "unique_filenames": True,
        },
        "automatic_send": False,
        "automatic_propagation": False,
        "human_approval_required": True,
        "core_modified": False,
    }

    variant_request = _party_type_variant_request(normalized)
    if variant_request is not None:
        variant_request_path = run_dir / "VARIANT_REQUEST.json"
        _json_dump(variant_request_path, variant_request)
        internal_artifacts = {
            "variant_request": _validate_artifact(variant_request_path),
            "case_snapshot": _validate_artifact(case_snapshot_path),
            "normalized_case": _validate_artifact(normalized_path),
        }
        audit_delivery = _publish_fail_closed_audit(
            output_dir=output_dir,
            run_dir=run_dir,
            run_id=run_id,
            delivery_stem=delivery_stem,
            sources={
                "variant_request": variant_request_path,
                "case_snapshot": case_snapshot_path,
                "normalized_case": normalized_path,
            },
        )
        result = {
            **common,
            "status": "NECESITA_CLARIFICARE",
            "stage": "normalization",
            "error_code": "PARTY_TYPE_VARIANTS_REQUIRED",
            "message": "Tipurile PF/PJ nu sunt precizate. Selectați una dintre variante; pipeline-ul nu a ales automat.",
            "missing_fields": variant_request["missing_fields"],
            "variants": variant_request["variants"],
            "engine_status": "NOT_RUN",
            "generator_status": "NOT_RUN",
            "qa_status": "NOT_RUN",
            "variant_request": variant_request,
            "artifacts": internal_artifacts,
            "delivery_artifacts": {},
            "audit_delivery_artifacts": audit_delivery,
        }
        run_result_path = run_dir / "PIPELINE_RESULT.json"
        root_result_path = output_dir / "PIPELINE_RESULT.json"
        unique_result_path = Path(audit_delivery["pipeline_result"]["path"])
        _json_dump(run_result_path, result)
        _json_dump(root_result_path, result)
        _json_dump(unique_result_path, result)
        return result

    engine = _load_module(canonical.engine, "m1c01_reference_engine_active")
    validate = getattr(engine, "validate_and_calculate", None)
    if not callable(validate):
        raise OrchestratorError("ENGINE_ENTRYPOINT_MISSING", "Motorul nu expune validate_and_calculate(...).")

    engine_result = validate(normalized)
    if not isinstance(engine_result, dict):
        raise OrchestratorError("ENGINE_INVALID_RESULT", "Motorul nu a returnat un obiect JSON.")
    engine_result_path = run_dir / "ENGINE_RESULT.json"
    _json_dump(engine_result_path, engine_result)

    if engine_result.get("status") != "CALCULATION_PASS_INTERNAL_DRAFT":
        error_code = engine_result.get("error_code") or "ENGINE_REJECTED"
        message = engine_result.get("message") or "Motorul a oprit execuția fail-closed."
        internal_artifacts = {
            "engine_result": _validate_artifact(engine_result_path),
            "case_snapshot": _validate_artifact(case_snapshot_path),
            "normalized_case": _validate_artifact(normalized_path),
        }
        audit_delivery = _publish_fail_closed_audit(
            output_dir=output_dir,
            run_dir=run_dir,
            run_id=run_id,
            delivery_stem=delivery_stem,
            sources={
                "engine_result": engine_result_path,
                "case_snapshot": case_snapshot_path,
                "normalized_case": normalized_path,
            },
        )
        result = {
            **common,
            "status": engine_result.get("status", "RESPINS_FAIL_CLOSED"),
            "stage": "engine",
            "error_code": error_code,
            "message": message,
            "missing_fields": engine_result.get("missing_fields", []),
            "engine_status": engine_result.get("status"),
            "generator_status": "NOT_RUN",
            "qa_status": "NOT_RUN",
            "engine_result": engine_result,
            "artifacts": internal_artifacts,
            "delivery_artifacts": {},
            "audit_delivery_artifacts": audit_delivery,
        }
        run_result_path = run_dir / "PIPELINE_RESULT.json"
        root_result_path = output_dir / "PIPELINE_RESULT.json"
        unique_result_path = Path(audit_delivery["pipeline_result"]["path"])
        _json_dump(run_result_path, result)
        _json_dump(root_result_path, result)
        _json_dump(unique_result_path, result)
        return result

    generator = _load_module(canonical.generator, "m1c01_offer_generator_v30")
    generate = getattr(generator, "generate", None)
    if not callable(generate):
        raise OrchestratorError("GENERATOR_ENTRYPOINT_MISSING", "Generatorul nu expune generate(...).")

    generator_result = generate(str(engine_result_path), str(run_dir), OUTPUT_BASENAME)
    if not isinstance(generator_result, dict) or generator_result.get("status") != "PASS":
        raise OrchestratorError(
            "GENERATOR_FAILED",
            "Generatorul nu a returnat PASS.",
            {"generator_result": generator_result},
        )

    docx_path = run_dir / f"{OUTPUT_BASENAME}.docx"
    pdf_path = run_dir / f"{OUTPUT_BASENAME}.pdf"
    email_docx_path = run_dir / "EMAIL_REZUMAT_M1-C01.docx"
    qa_path = run_dir / "RAPORT_QA_GENERATOR.json"
    artifacts = {
        "case_snapshot": _validate_artifact(case_snapshot_path),
        "normalized_case": _validate_artifact(normalized_path),
        "engine_result": _validate_artifact(engine_result_path),
        "docx": _validate_artifact(docx_path),
        "pdf": _validate_artifact(pdf_path),
        "email_docx": _validate_artifact(email_docx_path),
        "qa": _validate_artifact(qa_path),
    }
    qa = _load_json(qa_path)
    if qa.get("status") != "PASS":
        raise OrchestratorError("QA_FAILED", "Raportul QA nu este PASS.", {"qa": qa})
    if qa.get("core_modified") is not False or qa.get("automatic_send") is not False or qa.get("automatic_propagation") is not False:
        raise OrchestratorError("GOVERNANCE_QA_FAILED", "Raportul QA indică o abatere de guvernanță.")

    delivery_artifacts, delivery_manifests = _publish_delivery_artifacts(
        output_dir=output_dir,
        run_dir=run_dir,
        run_id=run_id,
        case_sha=case_sha,
        requested_formats=requested_formats,
        delivery_stem=delivery_stem,
        internal_artifacts=artifacts,
    )

    success_sources: Dict[str, Path] = {
        "case_snapshot": case_snapshot_path,
        "normalized_case": normalized_path,
        "engine_result": engine_result_path,
        "qa_report": qa_path,
        **fx_run_sources,
    }
    audit_delivery = _publish_success_audit(
        output_dir=output_dir,
        run_dir=run_dir,
        run_id=run_id,
        delivery_stem=delivery_stem,
        sources=success_sources,
    )

    result = {
        **common,
        "status": "READY_FOR_HUMAN_REVIEW",
        "stage": "complete",
        "engine_status": engine_result.get("status"),
        "generator_status": generator_result.get("status"),
        "qa_status": qa.get("status"),
        "artifacts": artifacts,
        "delivery_artifacts": delivery_artifacts,
        "delivery_manifests": delivery_manifests,
        "audit_delivery_artifacts": audit_delivery,
    }
    run_result_path = run_dir / "PIPELINE_RESULT.json"
    root_result_path = output_dir / "PIPELINE_RESULT.json"
    unique_result_path = Path(audit_delivery["pipeline_result"]["path"])
    _json_dump(run_result_path, result)
    _json_dump(root_result_path, result)
    _json_dump(unique_result_path, result)
    return result



def _merge_patch(base: Any, patch: Any) -> Any:
    """Apply RFC 7396-style merge semantics for a derived case amendment."""
    if not isinstance(patch, Mapping):
        return patch
    result: Dict[str, Any] = dict(base) if isinstance(base, Mapping) else {}
    for key, value in patch.items():
        if value is None:
            result.pop(key, None)
        elif isinstance(value, Mapping):
            result[key] = _merge_patch(result.get(key, {}), value)
        else:
            result[key] = value
    return result


def _session_state_path(output_dir: Path) -> Path:
    return output_dir / SESSION_STATE_NAME


def _load_session_state(output_dir: Path) -> Dict[str, Any]:
    path = _session_state_path(output_dir)
    if not path.is_file():
        raise OrchestratorError(
            "SESSION_STATE_NOT_FOUND",
            "Nu există o speță reușită în conversația curentă din care să pornească modificarea.",
            {"state_path": str(path)},
        )
    state = _load_json(path)
    if state.get("status") != "ACTIVE" or not isinstance(state.get("case"), dict):
        raise OrchestratorError("SESSION_STATE_INVALID", "Snapshotul speței curente este invalid.")
    return state


def _write_session_state(
    *,
    output_dir: Path,
    case: Mapping[str, Any],
    result: Mapping[str, Any],
    mode: str,
    parent_run_id: Optional[str],
) -> Dict[str, Any]:
    previous: Dict[str, Any] = {}
    state_path = _session_state_path(output_dir)
    if state_path.is_file():
        try:
            previous = _load_json(state_path)
        except OrchestratorError:
            previous = {}
    history = list(previous.get("history", [])) if isinstance(previous.get("history"), list) else []
    history.append({
        "run_id": result.get("run_id"),
        "mode": mode,
        "parent_run_id": parent_run_id,
        "created_at_utc": result.get("created_at_utc"),
        "case_sha256": result.get("case_sha256"),
        "delivery_artifacts": result.get("delivery_artifacts", {}),
    })
    state = {
        "status": "ACTIVE",
        "session_protocol": "M1C01_STATEFUL_V1",
        "orchestrator_version": ORCHESTRATOR_VERSION,
        "updated_at_utc": datetime.now(timezone.utc).isoformat(),
        "current_run_id": result.get("run_id"),
        "parent_run_id": parent_run_id,
        "case": dict(case),
        "delivery_artifacts": result.get("delivery_artifacts", {}),
        "delivery_manifests": result.get("delivery_manifests", {}),
        "history": history[-50:],
        "automatic_send": False,
        "automatic_propagation": False,
        "core_modified": False,
    }
    _json_dump(state_path, state)
    return state


def _locate_runtime_file(search_root: Path, filename: str, explicit: Optional[Path] = None) -> Path:
    return _select_exact_file(search_root, filename, explicit)


def _run_fx_gate_internal(
    case: Mapping[str, Any],
    *,
    output_dir: Path,
    search_root: Path,
    fx_gate_path: Optional[Path] = None,
    registry_path: Optional[Path] = None,
) -> tuple[Dict[str, Any], Path, Path, Path]:
    """Execute FX Gate inside the stateful controller so a follow-up needs one command only."""
    gate_path = _select_versioned_component(
        search_root, FX_GATE_PREFIX, FX_GATE_SUFFIX, "FX Gate", fx_gate_path
    )
    registry = _select_versioned_component(
        search_root, REGISTRY_PREFIX, REGISTRY_SUFFIX, "registru FX",
        registry_path, require_numeric_version=False,
    )
    gate = _load_module(gate_path, "m1c01_fx_gate_stateful")
    run = getattr(gate, "run", None)
    if not callable(run):
        raise OrchestratorError("FX_GATE_ENTRYPOINT_MISSING", "FX Gate nu expune run(...).")

    work = output_dir / "M1C01_STATEFUL_WORK"
    work.mkdir(parents=True, exist_ok=True)
    draft_path = work / "M1C01_CASE_DRAFT.json"
    validated_path = work / "M1C01_CASE.json"
    evidence_path = work / "FX_EVIDENCE.json"
    gate_result_path = work / "FX_GATE_RESULT.json"
    _json_dump(draft_path, dict(case))
    fx_stdout = io.StringIO()
    fx_stderr = io.StringIO()
    with contextlib.redirect_stdout(fx_stdout), contextlib.redirect_stderr(fx_stderr):
        exit_code = run(draft_path, validated_path, evidence_path, gate_result_path, registry)
    gate_result = _load_json(gate_result_path)
    gate_result["captured_stdout"] = fx_stdout.getvalue()
    gate_result["captured_stderr"] = fx_stderr.getvalue()
    if gate_result.get("status") == "NECESITA_CLARIFICARE":
        # FX Gate V2.0+ poate cere cursul în loc să respingă speța. Cererea de
        # clarificare nu este un defect: se propagă operatorului ca întrebare.
        raise FXClarificationNeeded(
            str(gate_result.get("error_code") or "FX_RATE_REQUIRED"),
            str(gate_result.get("message") or "Este necesar cursul speței curente."),
            dict(gate_result.get("details") or {}),
        )
    if exit_code != 0 or gate_result.get("status") != "PASS":
        raise OrchestratorError(
            str(gate_result.get("error_code") or "FX_GATE_FAILED"),
            str(gate_result.get("message") or "FX Gate a respins speța."),
            dict(gate_result.get("details") or {}),
        )
    return _load_json(validated_path), evidence_path, gate_result_path, draft_path


def _reattach_latest(output_dir: Path) -> Dict[str, Any]:
    state = _load_session_state(output_dir)
    artifacts = state.get("delivery_artifacts") or {}
    required = {"docx", "pdf", "email_docx"}
    if set(artifacts) != required:
        raise OrchestratorError("LATEST_DELIVERY_INCOMPLETE", "Ultima rulare nu are toate cele trei livrabile.")
    for key, meta in artifacts.items():
        path = Path(str(meta.get("path", "")))
        if not path.is_file() or path.stat().st_size <= 0:
            raise OrchestratorError("LATEST_DELIVERY_MISSING", f"Livrabilul {key} nu mai este accesibil.")
    return {
        "status": "READY_FOR_REATTACH",
        "mode": "reattach",
        "run_id": state.get("current_run_id"),
        "delivery_artifacts": artifacts,
        "message": "Reatașați exact cele trei livrabile ale ultimei rulări, fără recalculare.",
        "automatic_send": False,
        "automatic_propagation": False,
        "core_modified": False,
    }


def run_stateful(
    *,
    mode: str,
    input_payload: Optional[Mapping[str, Any]],
    output_dir: Path,
    search_root: Path,
    engine_path: Optional[Path] = None,
    generator_path: Optional[Path] = None,
    fx_gate_path: Optional[Path] = None,
    registry_path: Optional[Path] = None,
) -> Dict[str, Any]:
    mode = mode.lower()
    if mode == "reattach":
        return _reattach_latest(output_dir)

    parent_run_id: Optional[str] = None
    if mode == "new":
        if not isinstance(input_payload, Mapping):
            raise OrchestratorError("INPUT_REQUIRED", "Modul new necesită speța completă.")
        case = dict(input_payload)
    elif mode in {"amend", "regenerate"}:
        state = _load_session_state(output_dir)
        parent_run_id = str(state.get("current_run_id") or "") or None
        base_case = dict(state["case"])
        if mode == "amend":
            if not isinstance(input_payload, Mapping):
                raise OrchestratorError("AMENDMENT_REQUIRED", "Modul amend necesită un obiect JSON cu modificările.")
            case = _merge_patch(base_case, input_payload)
        else:
            case = base_case
    else:
        raise OrchestratorError("INVALID_MODE", f"Mod de execuție necunoscut: {mode}.")

    # A derived run is fully recalculated. It never reuses old result files.
    validated_case, evidence_path, gate_result_path, draft_path = _run_fx_gate_internal(
        case,
        output_dir=output_dir,
        search_root=search_root,
        fx_gate_path=fx_gate_path,
        registry_path=registry_path,
    )
    result = run_pipeline(
        validated_case,
        output_dir=output_dir,
        search_root=search_root,
        engine_path=engine_path,
        generator_path=generator_path,
        input_path=draft_path,
        fx_evidence_path=evidence_path,
        fx_gate_result_path=gate_result_path,
    )
    result["execution_mode"] = mode
    result["parent_run_id"] = parent_run_id
    if result.get("status") == "READY_FOR_HUMAN_REVIEW":
        state = _write_session_state(
            output_dir=output_dir,
            case=validated_case,
            result=result,
            mode=mode,
            parent_run_id=parent_run_id,
        )
        result["session_state"] = {
            "path": str(_session_state_path(output_dir)),
            "current_run_id": state.get("current_run_id"),
            "parent_run_id": parent_run_id,
            "history_length": len(state.get("history", [])),
        }
        # Re-write result after session binding.
        run_result = Path(str(result.get("run_directory"))) / "PIPELINE_RESULT.json"
        root_result = output_dir / "PIPELINE_RESULT.json"
        unique_result = output_dir / f"{_delivery_slug(normalize_case(validated_case))}_{result['run_id']}_PIPELINE_RESULT.json"
        for path in (run_result, root_result, unique_result):
            _json_dump(path, result)
    return result



DELIVERY_ORDER = ("docx", "pdf", "email_docx")


def _sanitized_delivery_artifacts(
    artifacts: Mapping[str, Any], expected_formats: Optional[Iterable[str]] = None
) -> Dict[str, Any]:
    """Return only root run-bound user-facing metadata; never expose internal aliases.

    `expected_formats` reflectă ce a cerut operatorul. Implicit, setul complet.
    Un format cerut și lipsă este eroare; unul necerut și absent nu este.
    """
    role_names = {
        "docx": "offer_docx",
        "pdf": "offer_pdf",
        "email_docx": "email_docx",
    }
    wanted = [f for f in DELIVERY_ORDER if f in set(expected_formats or DELIVERY_ORDER)]
    if not wanted:
        raise OrchestratorError(
            "DELIVERY_CONTRACT_INCOMPLETE",
            "Nu a fost solicitat niciun livrabil public valid.",
        )
    sanitized: Dict[str, Any] = {}
    for fmt in wanted:
        raw = artifacts.get(fmt)
        if not isinstance(raw, Mapping):
            raise OrchestratorError(
                "DELIVERY_CONTRACT_INCOMPLETE",
                f"Lipsește livrabilul public obligatoriu: {fmt}.",
            )
        path = Path(str(raw.get("path", "")))
        validated = _validate_artifact(path)
        run_id = str(raw.get("run_id") or "")
        if not run_id:
            raise OrchestratorError("DELIVERY_RUN_ID_MISSING", f"Livrabilul {fmt} nu are run_id.")
        if path.name in {"OFERTA_M1-C01_CANONICA.docx", "OFERTA_M1-C01_CANONICA.pdf", "EMAIL_REZUMAT_M1-C01.docx"}:
            raise OrchestratorError(
                "INTERNAL_ALIAS_EXPOSED",
                f"Livrabilul public {fmt} indică un alias intern interzis.",
                {"path": str(path)},
            )
        sanitized[fmt] = {
            "role": role_names[fmt],
            "path": str(path),
            "filename": path.name,
            "size": validated["size"],
            "sha256": validated["sha256"],
            "run_id": run_id,
            "attach": True,
        }
    run_ids = {str(meta["run_id"]) for meta in sanitized.values()}
    if len(run_ids) != 1:
        raise OrchestratorError(
            "DELIVERY_RUN_ID_MISMATCH",
            "Cele trei livrabile publice nu aparțin aceleiași rulări.",
            {"run_ids": sorted(run_ids)},
        )
    return sanitized


def _public_attachment_envelope(result: Mapping[str, Any]) -> Dict[str, Any]:
    """Build the only CLI-visible result used by ChatGPT for actual attachments."""
    status = str(result.get("status") or "RESPINS_FAIL_CLOSED")
    if status not in {"READY_FOR_HUMAN_REVIEW", "READY_FOR_REATTACH"}:
        return {
            "status": status,
            "stage": result.get("stage"),
            "error_code": result.get("error_code"),
            "message": result.get("message"),
            "missing_fields": result.get("missing_fields", []),
            "attachment_contract": ATTACHMENT_CONTRACT_VERSION,
            "attach_exact_paths": False,
            "attachment_paths": [],
            "delivery_artifacts": {},
            "orchestrator_version": ORCHESTRATOR_VERSION,
        }

    requested = (result.get("delivery_request") or {}).get("requested_formats")
    sanitized = _sanitized_delivery_artifacts(result.get("delivery_artifacts") or {}, requested)
    run_id = next(iter({meta["run_id"] for meta in sanitized.values()}))
    ordered_paths = [sanitized[fmt]["path"] for fmt in DELIVERY_ORDER if fmt in sanitized]
    return {
        "status": status,
        "stage": result.get("stage", "complete"),
        "execution_mode": result.get("execution_mode", "legacy"),
        "run_id": run_id,
        "parent_run_id": result.get("parent_run_id"),
        "attachment_contract": ATTACHMENT_CONTRACT_VERSION,
        "attach_exact_paths": True,
        "attachment_paths": ordered_paths,
        "delivery_artifacts": sanitized,
        "attachment_count": len(ordered_paths),
        "internal_aliases_are_not_deliverables": True,
        "message": (
            f"Atașați efectiv exact cele {len(ordered_paths)} fișiere din attachment_paths, "
            "în ordinea indicată."
        ),
        "orchestrator_version": ORCHESTRATOR_VERSION,
    }


def _write_public_attachment_result(output_dir: Path, result: Mapping[str, Any]) -> Dict[str, Any]:
    envelope = _public_attachment_envelope(result)
    _json_dump(output_dir / ATTACHMENT_RESULT_NAME, envelope)
    return envelope

def _failure_payload(exc: BaseException) -> Dict[str, Any]:
    if isinstance(exc, FXClarificationNeeded):
        # Cererea de curs nu este respingere: operatorul primește o întrebare.
        return {
            "status": "NECESITA_CLARIFICARE",
            "stage": "fx_gate",
            "error_code": exc.code,
            "message": exc.message,
            "details": exc.details,
            "missing_fields": ["fx.rate"],
            "engine_status": "NOT_RUN",
            "generator_status": "NOT_RUN",
            "qa_status": "NOT_RUN",
            "orchestrator_version": ORCHESTRATOR_VERSION,
            "automatic_send": False,
            "automatic_propagation": False,
            "human_approval_required": True,
            "core_modified": False,
        }
    if isinstance(exc, OrchestratorError):
        return {
            "status": "RESPINS_FAIL_CLOSED",
            "stage": "orchestrator",
            "error_code": exc.code,
            "message": exc.message,
            "details": exc.details,
            "orchestrator_version": ORCHESTRATOR_VERSION,
            "automatic_send": False,
            "automatic_propagation": False,
            "human_approval_required": True,
            "core_modified": False,
        }
    return {
        "status": "RESPINS_FAIL_CLOSED",
        "stage": "orchestrator",
        "error_code": "UNHANDLED_ORCHESTRATOR_ERROR",
        "message": str(exc),
        "traceback": traceback.format_exc(),
        "orchestrator_version": ORCHESTRATOR_VERSION,
        "automatic_send": False,
        "automatic_propagation": False,
        "human_approval_required": True,
        "core_modified": False,
    }


def main(argv: Optional[Iterable[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="M1-C01 stateful atomic pipeline orchestrator V3.7")
    parser.add_argument("--mode", choices=["legacy", "new", "amend", "regenerate", "reattach"], default="legacy")
    parser.add_argument("--input", type=Path, help="Speță completă (new/legacy) sau patch JSON (amend)")
    parser.add_argument("--output", default=Path("/mnt/data"), type=Path)
    parser.add_argument("--search-root", default=Path("/mnt/data"), type=Path)
    parser.add_argument("--engine", type=Path)
    parser.add_argument("--generator", type=Path)
    parser.add_argument("--fx-gate", type=Path)
    parser.add_argument("--registry", type=Path)
    parser.add_argument("--fx-evidence", type=Path)
    parser.add_argument("--fx-gate-result", type=Path)
    args = parser.parse_args(list(argv) if argv is not None else None)

    try:
        if args.mode == "legacy":
            if args.input is None:
                raise OrchestratorError("INPUT_REQUIRED", "Modul legacy necesită --input.")
            case = _load_json(args.input)
            result = run_pipeline(
                case,
                output_dir=args.output,
                search_root=args.search_root,
                engine_path=args.engine,
                generator_path=args.generator,
                input_path=args.input,
                fx_evidence_path=args.fx_evidence,
                fx_gate_result_path=args.fx_gate_result,
            )
        else:
            payload = _load_json(args.input) if args.input is not None else None
            result = run_stateful(
                mode=args.mode,
                input_payload=payload,
                output_dir=args.output,
                search_root=args.search_root,
                engine_path=args.engine,
                generator_path=args.generator,
                fx_gate_path=args.fx_gate,
                registry_path=args.registry,
            )
        public_result = _write_public_attachment_result(args.output, result)
        print(json.dumps(public_result, ensure_ascii=False, indent=2))
        return 0 if result.get("status") in {"READY_FOR_HUMAN_REVIEW", "READY_FOR_REATTACH"} else 2
    except BaseException as exc:
        payload = _failure_payload(exc)
        args.output.mkdir(parents=True, exist_ok=True)
        _json_dump(args.output / "PIPELINE_RESULT.json", payload)
        public_payload = _write_public_attachment_result(args.output, payload)
        stream = sys.stdout if payload.get("status") == "NECESITA_CLARIFICARE" else sys.stderr
        print(json.dumps(public_payload, ensure_ascii=False, indent=2), file=stream)
        return 3 if payload.get("status") == "NECESITA_CLARIFICARE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
