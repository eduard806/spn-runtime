"""Closed-branch regression suite M1-C01 V2.0.

V2.0 remediază DEF-04 constatat la auditul din 12.08.2026: suita V1.12 indica
`12_M1C01_PIPELINE_ORCHESTRATOR_V1.8.py`, versiune inexistentă, deci nu putea
rula. Vectorii de test și totalurile așteptate sunt păstrați bit-identic; se
schimbă exclusiv modul de localizare a componentelor.

Componentele se descoperă acum dinamic, ca în orchestrator: exact o versiune
activă pentru fiecare. `--engine` și `--generator` rămân opționale și sunt
folosite doar dacă operatorul le indică explicit.

Nu adaugă reguli canonice noi și nu modifică CORE, motorul sau generatorul.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict

ORCHESTRATOR_PREFIX = "12_M1C01_PIPELINE_ORCHESTRATOR_V"
ENGINE_PREFIX = "08_M1C01_REFERENCE_ENGINE_V"
GENERATOR_PREFIX = "11_M1C01_OFFER_GENERATOR_V"


# Contractul de livrare validat: trei livrabile run-bound.
DEFAULT_DELIVERY = ["docx", "pdf", "email_docx"]


def _is_run_bound_name(name: str, run_id: str, fmt: str) -> bool:
    """Denumirile validate sunt `<COD_ACTE>_<IDENTITATE>_<DATA>_<TOKEN>[_EMAIL].<ext>`.

    Verificăm ce contează efectiv: extensia corectă, prezența unui token de
    rulare derivat din run_id și marcajul _EMAIL pentru Word-ul de e-mail.
    """
    ext = "docx" if fmt == "email_docx" else fmt
    if not name.lower().endswith(f".{ext}"):
        return False
    if fmt == "email_docx" and "_EMAIL." not in name:
        return False
    if fmt != "email_docx" and "_EMAIL." in name:
        return False
    stem = name.rsplit(".", 1)[0]
    if fmt == "email_docx":
        stem = stem[: -len("_EMAIL")]
    if stem.endswith("_SCURT"):  # V2.5 (am.367): setul scurt poarta sufixul _SCURT dupa token (si dupa sufixul partii, am.135)
        stem = stem[: -len("_SCURT")]
    for _party in ("_CUMPARATOR", "_VANZATOR"):
        if stem.endswith(_party):
            stem = stem[: -len(_party)]
    token = stem.rsplit("_", 1)[-1]
    # Tokenul public este SHA-256(run_id)[:6], majuscule — nu un fragment din run_id.
    expected = hashlib.sha256(run_id.encode("utf-8")).hexdigest()[:6].upper()
    return token.upper() == expected


def _extract_docx_text(path: Path) -> str:
    """V2.5 (am.367): textul paragrafelor DOCX (python-docx), pentru verificarile pe e-mail."""
    from docx import Document
    return "\n".join(p.text for p in Document(str(path)).paragraphs)


def _extract_pdf_text(path: Path) -> str:
    """PyMuPDF când există, pypdf altfel. Textul extras este echivalent."""
    try:
        import fitz
        with fitz.open(path) as doc:
            return " ".join(page.get_text("text") for page in doc)
    except ImportError:
        from pypdf import PdfReader
        return " ".join((page.extract_text() or "") for page in PdfReader(str(path)).pages)


def _discover(root: Path, prefix: str, label: str) -> Path:
    """Găsește exact o versiune activă a unei componente. Oprește altfel."""
    found = sorted(p for p in root.glob(f"{prefix}*.py") if p.is_file())
    if not found:
        raise SystemExit(f"Componenta {label} lipsește din {root} ({prefix}*.py).")
    if len(found) > 1:
        raise SystemExit(
            f"Există mai multe versiuni active pentru {label}: "
            + ", ".join(p.name for p in found)
        )
    return found[0].resolve()

CASES: Dict[str, Dict[str, Any]] = {
    "NR01_SALE_PF_PF": {
        "case": {
            "acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF",
            "seller_tax_percent": 1, "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {"buyer_without_optional_notation": "17258.31", "seller": "15800.15"},
        "pages": 1,
    },
    "NR24_RADIERE_STANDALONE": {
        "case": {
            "acts": ["radiere"], "buyer_type": "PF", "seller_type": "PF",
            "currency": "RON", "fx": {"mode": "RON"},
            "calculation_date": "2026-08-15",
        },
        "expected_totals": {},
        "expected_components": {"radiere": {"honorarium_net": "800.00", "vat": "168.00",
            "information_extract": "20.00", "ancpi_radiere_fixed": "75.00", "total": "1063.00"}},
        "pages": 1,
    },
    "NR02_SALE_MORTGAGE_PJ_PF": {
        "case": {
            "acts": ["sale", "mortgage"], "price": 420000,
            "own_funds_percent": 45, "credit_percent": 55,
            "buyer_type": "PJ", "seller_type": "PF", "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {
            "buyer_without_optional_notation": "34953.70",
            "seller_tax_1": "22097.15", "seller_tax_3": "66174.15",
        },
        # pages actualizat 12.08.2026 de la 2 la 1. Așteptarea preceda patch-ul
        # LAYOUT_CONTINUU V1.0 (10.08.2026), care a compactat ofertele. Verificat
        # pe generator V3.0 și V3.1 — ambele produc 1 pagină. Nu este regresie.
        "pages": 1,
    },
    "NR03_FULL_PJ_PF": {
        "case": {
            "acts": ["antecontract", "sale", "mortgage"], "price": 250000,
            "advance": 100000, "own_funds": 100000, "credit": 150000,
            "advance_from_own_funds": True,
            "buyer_type": "PJ", "seller_type": "PF",
            "seller_owned_more_than_3_years": True, "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {
            "buyer_without_optional_notation": "23161.77",
            "buyer_with_optional_notation": "23236.77", "seller": "13215.30",
        },
        "pages": 2,
    },
    "T06_ANTECONTRACT_SIMPLE_PJ_PF": {
        "case": {
            "acts": ["antecontract"], "advance": 80000,
            "buyer_type": "PJ", "seller_type": "PF", "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {
            "buyer_without_optional_notation": "5164.03",
            "buyer_with_optional_notation": "5239.03", "seller": "38.15",
        },
        "pages": 1,
    },
    "T07_ANTECONTRACT_PF_PF": {
        "case": {
            "acts": ["antecontract"], "advance": 60000,
            "buyer_type": "PF", "seller_type": "PF", "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {
            "buyer_without_optional_notation": "3882.89",
            "buyer_with_optional_notation": "3957.89", "seller": "38.15",
        },
        "pages": 1,
        "required_phrases": [
            "Antecontract", "Promitent-cumpărător", "Promitent-vânzător",
            "TOTAL PROMITENT-CUMPĂRĂTOR", "TOTAL PROMITENT-VÂNZĂTOR",
        ],
        "forbidden_phrases": [
            "Contract de ipotecă", "Contract de vânzare", "Debitor / constituitor",
        ],
    },
    "T08_ANTECONTRACT_PF_PJ": {
        "case": {
            "acts": ["antecontract"], "advance": 70000,
            "buyer_type": "PF", "seller_type": "PJ", "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {
            "buyer_without_optional_notation": "4518.14",
            "buyer_with_optional_notation": "4593.14", "seller": "50.00",
        },
        "pages": 1,
        "required_phrases": ["Promitent-cumpărător", "persoană fizică", "Promitent-vânzător", "persoană juridică"],
        "forbidden_phrases": ["Contract de ipotecă", "Contract de vânzare"],
    },
    "T09_ANTECONTRACT_PJ_PJ": {
        "case": {
            "acts": ["antecontract"], "advance": 70000,
            "buyer_type": "PJ", "seller_type": "PJ", "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {
            "buyer_without_optional_notation": "4529.99",
            "buyer_with_optional_notation": "4604.99", "seller": "50.00",
        },
        "pages": 1,
        "required_phrases": ["Promitent-cumpărător", "Promitent-vânzător", "RECOM"],
        "forbidden_phrases": ["Verificare regim matrimonial", "Contract de ipotecă", "Contract de vânzare"],
    },
    "T05_STANDALONE_MORTGAGE_PF": {
        "case": {
            "acts": ["mortgage"], "credit": 150000,
            "buyer_type": "PF", "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {
            "buyer_without_optional_notation": "3573.06",
            "buyer_with_optional_notation": "3573.06",
        },
        "pages": 1,
        "required_phrases": [
            "Contract de ipotecă / refinanțare",
            "Debitor / constituitor",
            "TOTAL DEBITOR / CONSTITUITOR",
            "CAPITOLUL 1 - COSTURI DEBITOR / CONSTITUITOR - CONTRACT DE IPOTECĂ / REFINANȚARE",
            "CAPITOLUL 2 - TOTAL GENERAL DEBITOR / CONSTITUITOR",
            "TOTAL GENERAL DEBITOR / CONSTITUITOR",
            "Verificare regim matrimonial",
            "Extras de autentificare",
            "Verificări procuri bancare",
            "Legalizare procură bancară",
            "Taxă OCPI",
        ],
        "forbidden_phrases": [
            "TOTAL CUMPĂRĂTOR",
            "TOTAL GENERAL CUMPĂRĂTOR",
            "CAPITOLUL 5 - TOTAL GENERAL CUMPĂRĂTOR",
            "Vânzător",
            "Contract de vânzare",
            "Antecontract",
        ],
    },
    "T13_FINANCING_MISMATCH_GUARD": {
        "case": {
            "acts": ["sale", "mortgage"], "price": 300000,
            "own_funds": 100000, "credit": 150000,
            "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
            "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_fail_closed": {
            "stage": "engine",
            "error_code": "FINANCING_MISMATCH",
            "message": "Sursele proprii și creditul nu însumează prețul.",
        },
    },
    "T15_PARTY_TYPE_VARIANTS_GUARD": {
        "case": {
            "acts": ["sale"], "price": 300000, "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_variants": {
            "stage": "normalization",
            "error_code": "PARTY_TYPE_VARIANTS_REQUIRED",
            "missing_fields": ["buyer_type", "seller_type"],
            "variant_ids": ["PF_PF", "PF_PJ", "PJ_PF", "PJ_PJ"],
        },
    },
    "T14_ANTECONTRACT_ADVANCE_CLARIFICATION_GUARD": {
        "case": {
            "acts": ["antecontract"], "price": 250000,
            "buyer_type": "PF", "seller_type": "PF", "currency": "EUR",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_clarification": {
            "stage": "engine",
            "missing_fields": ["advance"],
            "clarification_code": "CONFIRM_ANTECONTRACT_ADVANCE",
            "question": "Ce sumă se achită la antecontract?",
        },
    },
    "T16A_OPEN_THRESHOLD_600001_GUARD": {
        "case": {
            "acts": ["sale"], "price": 600001,
            "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
            "currency": "RON",
        },
        "expected_fail_closed": {
            "stage": "engine",
            "error_code": "OPEN_THRESHOLD_600001",
            "message": "Valoarea exactă 600.001 lei rămâne fail-closed până la decizie expresă a titularului.",
        },
    },
    "T16B_OPEN_THRESHOLD_500001_GUARD": {
        "case": {
            "acts": ["mortgage"], "credit": 500001,
            "buyer_type": "PF", "currency": "RON",
        },
        "expected_fail_closed": {
            "stage": "engine",
            "error_code": "OPEN_THRESHOLD_500001",
            "message": "Valoarea exactă 500.001 lei rămâne fail-closed până la decizie expresă a titularului.",
        },
    },
    "T17_INVALID_NUMBER_GUARD": {
        "case": {
            "acts": ["mortgage"], "credit": -10000,
            "buyer_type": "PF", "currency": "RON",
        },
        "expected_fail_closed": {
            "stage": "engine",
            "error_code": "INVALID_NUMBER",
            "message": "Câmp numeric negativ sau ne-finit: amount.",
        },
    },
    "DELIVERY_PDF_ONLY_GUARD": {
        # DEF-08 reparat în orchestrator V3.5: cererea parțială nu mai este respinsă.
        # Word-ul de e-mail rămâne livrabil standard și însoțește orice cerere.
        "case": {"acts": ["opinion"], "currency": "RON", "requested_formats": ["pdf"]},
        "expected_totals": {
            "buyer_without_optional_notation": "504.00",
            "buyer_with_optional_notation": "504.00",
        },
        "pages": 1,
        "expected_delivery": ["pdf", "email_docx"],
        "required_phrases": ["TOTAL SOLICITANT"],
        "forbidden_phrases": ["TOTAL CUMPĂRĂTOR"],
    },
    "DELIVERY_DOCX_ONLY_GUARD": {
        # DEF-08 reparat în orchestrator V3.5. Vezi nota de la cazul anterior.
        "case": {"acts": ["opinion"], "currency": "RON", "requested_formats": ["docx"]},
        "expected_totals": {
            "buyer_without_optional_notation": "504.00",
            "buyer_with_optional_notation": "504.00",
        },
        "pages": 1,
        "expected_delivery": ["docx", "email_docx"],
        "required_phrases": ["TOTAL SOLICITANT"],
        "forbidden_phrases": ["TOTAL CUMPĂRĂTOR"],
    },
    "OPINION_NUMERIC_GUARD": {
        "case": {"acts": ["opinion"], "currency": "RON"},
        "expected_totals": {
            "buyer_without_optional_notation": "504.00",
            "buyer_with_optional_notation": "504.00",
        },
        "pages": 1,
        "required_phrases": ["TOTAL SOLICITANT", "CAPITOLUL 2 - TOTAL GENERAL SOLICITANT", "TOTAL GENERAL SOLICITANT"],
        "forbidden_phrases": ["TOTAL CUMPĂRĂTOR", "CAPITOLUL 5 - TOTAL GENERAL CUMPĂRĂTOR"],
    },
    "T25_SALE_REDUCTION_MINUS20": {
        "case": {
            "acts": ["sale"], "price": 300000,
            "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
            "currency": "EUR",
            "honorarium_increase_percent": -20, "honorarium_increase_scope": "sale",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {"buyer_without_optional_notation": "14293.81", "seller": "15800.15"},
        "pages": 1,
    },
    "T25_RADIERE_REDUCTION_MINUS50": {
        "case": {
            "acts": ["radiere"], "buyer_type": "PF", "seller_type": "PF",
            "currency": "RON", "fx": {"mode": "RON"},
            "calculation_date": "2026-08-31",
            "honorarium_increase_percent": -50, "honorarium_increase_scope": "radiere",
        },
        "expected_totals": {},
        "expected_components": {"radiere": {"honorarium_net": "400", "vat": "84.00",
            "information_extract": "20.00", "ancpi_radiere_fixed": "75.00", "total": "579.00"}},
        "pages": 1,
    },
    "T25_ANTECONTRACT_REDUCTION_MINUS10": {
        "case": {
            "acts": ["antecontract"], "advance": 30000, "buyer_type": "PF", "seller_type": "PF",
            "currency": "RON", "fx": {"mode": "RON"},
            "calculation_date": "2026-08-31",
            "honorarium_increase_percent": -10, "honorarium_increase_scope": "antecontract",
        },
        "expected_totals": {},
        "expected_components": {"antecontract": {"honorarium_net": "450"}},
        "pages": 1,
    },
    "T25_REDUCTION_100_GUARD": {
        "case": {
            "acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
            "currency": "EUR",
            "honorarium_increase_percent": -100, "honorarium_increase_scope": "sale",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_fail_closed": {"stage": "engine", "error_code": "INVALID_HONORARIUM_ADJUSTMENT",
                                 "message": "Reducerea onorariului trebuie să fie sub 100% (honorarium_adjustment.percent)."},
    },
    "ADJ_SALE_23_PERCENT_GUARD": {
        "case": {
            "acts": ["sale"], "price": 300000,
            "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
            "currency": "EUR",
            "honorarium_increase_percent": 23, "honorarium_increase_scope": "sale",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {"buyer_without_optional_notation": "20668.09", "seller": "15800.15"},
        "pages": 1,
    },
    "ADJ_MORTGAGE_14_QUANTITIES_GUARD": {
        "case": {
            "acts": ["mortgage"], "credit": 150000, "buyer_type": "PF", "currency": "EUR",
            "honorarium_increase_percent": 14, "honorarium_increase_scope": "mortgage",
            "component_quantities": {
                "mortgage_authentication_extracts": 4,
                "mortgage_buyer_verifications": 5,
                "mortgage_legalized_copies": 12,
                "mortgage_bank_proxy_checks": 2,
            },
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {"buyer_without_optional_notation": "4152.86", "buyer_with_optional_notation": "4152.86"},
        "pages": 1,
        "required_phrases": ["4 extrase", "5 verificări", "12 copii/pagini"],
    },
    "ADJ_COMPLEX_BOTH_18_PERCENT_GUARD": {
        "case": {
            "acts": ["opinion", "antecontract", "sale", "mortgage"],
            "price": 300000, "advance": 100000, "own_funds": 100000, "credit": 200000,
            "advance_equals_own_funds_confirmed": True,
            "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
            "currency": "EUR",
            "honorarium_increase_percent": 18, "honorarium_increase_scope": "ambele",
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {
            "buyer_without_optional_notation": "23962.85",
            "buyer_with_optional_notation": "24037.85",
            "seller": "15838.30",
        },
        "pages": 2,
    },
    "QTY_OPINION_INFORMATION_EXTRACTS_GUARD": {
        "case": {"acts": ["opinion"], "currency": "RON", "component_quantities": {"opinion_information_extracts": 4}},
        "expected_totals": {"buyer_without_optional_notation": "564.00", "buyer_with_optional_notation": "564.00"},
        "pages": 1,
        "required_phrases": ["4 extrase"],
    },
    "QTY_ANTECONTRACT_COMPONENTS_GUARD": {
        "case": {
            "acts": ["antecontract"], "advance": 70000,
            "buyer_type": "PF", "seller_type": "PF", "currency": "EUR",
            "component_quantities": {
                "antecontract_buyer_verifications": 5,
                "antecontract_seller_information_extracts": 4,
                "antecontract_seller_verifications": 5,
            },
            "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True},
        },
        "expected_totals": {
            "buyer_without_optional_notation": "4590.74",
            "buyer_with_optional_notation": "4665.74",
            "seller": "170.75",
        },
        "pages": 1,
        "required_phrases": ["4 extrase", "5 verificări"],
    },

    # PATCH V4.20 (am.169, T21, 29.08.2026) — R-PROMISIUNE-EXTERNA + R-SERVICII-PE-VANZATOR (lotul B3D4, gol pana acum)
    "T21_EXTERNAL_ANTECONTRACT_DEDUCTION_700": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
                 "scade_promisiune": 700, "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_totals": {"buyer_without_optional_notation": "15969.89", "seller": "15298.15"},
        "expected_components": {"sale": {"gross_honorarium_before_deduction": "11949", "antecontract_honorarium_deduction": "700.00",
                                         "honorarium_net": "11249.00", "antecontract_deduction_source": "operator_extern"}},
        "pages": 1,
    },
    "T21_EXTERNAL_ANTECONTRACT_DEDUCTION_GROSS_847": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF",
                 "scade_promisiune_brut": 847, "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_totals": {"buyer_without_optional_notation": "15969.89", "seller_tax_1": "15298.15", "seller_tax_3": "45778.15"},
        "expected_components": {"sale": {"antecontract_honorarium_deduction": "700.00", "honorarium_net": "11249.00"}},
        "pages": 1,
    },
    "T21_EXTERNAL_DEDUCTION_CONFLICT_GUARD": {
        "case": {"acts": ["antecontract", "sale"], "price": 300000, "advance": 30000, "own_funds": 30000, "advance_from_own_funds": True,
                 "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1, "scade_promisiune": 700, "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_fail_closed": {"stage": "engine", "error_code": "DEDUCTION_CONFLICT",
                                 "message": "Antecontractul este în calcul; nu se acceptă și o promisiune externă de dedus."},
    },
    "T21_EXTERNAL_DEDUCTION_EXCEEDS_GUARD": {
        "case": {"acts": ["sale"], "price": 10000, "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1, "scade_promisiune": 5000, "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_fail_closed": {"stage": "engine", "error_code": "DEDUCTION_EXCEEDS_FEE",
                                 "message": "Deducerea antecontractului depășește onorariul vânzării."},
    },
    "T21_SELLER_SERVICES_SUFFIX_AND_FEES": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF", "client": "TEST T21",
                 "component_quantities": {"verificari_procuri_vanzator": 2, "copii_legalizate_pagini_vanzator": 4, "notari_cf_vanzator": 1,
                                          "radieri_cf_orice_act_vanzator": 1, "verificari_procuri": 1},
                 "taxe_suplimentare": [{"label": "Schimbare denumire creditor", "amount": 100, "quantity": 2, "parte": "vanzator"}, {"label": "Taxa X", "amount": 50}],
                 "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_totals": {"buyer_without_optional_notation": "16885.04", "seller_tax_1": "15708.65", "seller_tax_3": "46188.65",
                            "services_total": "18.15", "services_seller_total": "210.50", "additional_fees_total": "50.00",
                            "additional_fees_seller_total": "200.00", "seller_extra_total": "410.50"},
        "pages": 1,
    },
    "T21_SELLER_SERVICES_GLOBAL_SWITCH": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PJ", "servicii_parte": "vanzator",
                 "component_quantities": {"verificari_procuri": 2, "legalizari_pagini": 4}, "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_totals": {"buyer_without_optional_notation": "16816.89", "seller": "130.50", "services_seller_total": "60.50"},
        "pages": 1,
    },
    "T21_RADIERE_ON_SELLER": {
        "case": {"acts": ["sale", "radiere"], "price": 300000, "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
                 "radiere_parte": "vanzator", "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_totals": {"buyer_without_optional_notation": "16816.89", "seller": "16361.15", "seller_extra_total": "1063.00"},
        "pages": 1,
    },
    "T21_BUYER_SERVICES_UNCHANGED_AM133": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
                 "component_quantities": {"verificari_procuri": 1, "legalizari_pagini": 4}, "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_totals": {"buyer_without_optional_notation": "16859.24", "seller": "15298.15", "services_total": "42.35"},
        "pages": 1,
    },
    # PATCH V4.25 (am.367, T55z, 09.09.2026) — lotul B6A: reparatiile titularului (pt_claude.docx) + formatul scurt
    "T55Z_NOTARI_CF_SINGLE_COUNT": {
        "case": {"acts": ["sale"], "price": "421311.25", "currency": "RON", "buyer_type": "PF", "seller_type": "PJ", "offer_for": "buyer",
                 "honorarium_increase_percent": 10, "component_quantities": {"verificari_pf": 1, "notari_cf": 5},
                 "taxe_suplimentare": [{"label": "Onorariu contract de cesiune", "amount": "2057", "quantity": 1}]},
        "expected_totals": {"buyer_without_optional_notation": "9521.77", "additional_fees_total": "2057.00"},
        "expected_components": {"sale": {"honorarium_net": "5277", "ancpi": "632", "land_book_notation": "375.00", "notation_quantity": 5,
                                         "buyer_verification": "18.15", "buyer_verification_quantity": 1}},
        "expected_services_total": "0",
        "email_must_contain": ["Onorariu contract de cesiune"],
        "pages": 1,
    },
    "T55Z_VERIFICARI_TOTAL_2": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PJ",
                 "component_quantities": {"verificari_pf": 2}, "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_totals": {"buyer_without_optional_notation": "16835.04"},
        "expected_components": {"sale": {"buyer_verification_quantity": 2, "buyer_verification": "36.30"}},
        "expected_services_total": "0",
        "pages": 1,
    },
    "T55Z_VERIFICARI_CONFLICT_GUARD": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PJ",
                 "component_quantities": {"verificari_pf": 2, "verificari_regim_matrimonial": 3}, "currency": "RON"},
        "expected_orchestrator_fail": {"error_code": "VERIFICATION_COUNT_CONFLICT",
                                       "message": "Verificarile de regim matrimonial ale cumparatorului au fost date de doua ori, cu numere diferite."},
    },
    "T55Z_FORMAT_COMPLET": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1, "offer_format": "completa",
                 "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_totals": {"buyer_without_optional_notation": "16816.89", "seller": "15298.15"},
        "expected_offer_format": "complet",
        "pages": 1,
    },
    "T55Z_FORMAT_INVALID_GUARD": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1, "offer_format": "mediu", "currency": "RON"},
        "expected_orchestrator_fail": {"error_code": "INVALID_OFFER_FORMAT",
                                       "message": "offer_format trebuie sa fie scurt / complet (varianta scurta sau varianta completa)."},
    },
    # PATCH V4.24 (am.282, T36, 03.09.2026) — R-IMPOZIT-MIXT-COTE: impozitul pe cote (dobandire prin mai multe acte la date diferite)
    "T36_MIXED_TAX_SHARES_50_50": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF",
                 "impozit_cote": [{"cota": "1/2", "procent": 1, "act": "contract de vânzare-cumpărare 2001"}, {"cota": "1/2", "procent": 3, "act": "partaj 2026"}], "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_totals": {"buyer_without_optional_notation": "16816.89", "seller": "30538.15"},
        "expected_components": {"sale": {"honorarium_net": "11949"}},
        "expected_seller": {"tax": "30480.00", "tax_mode": "MIXT", "tax_percent_label": "1% pe 1/2 + 3% pe 1/2"},
        "required_phrases": ["MIXT pe cote"],
        "pages": 1,
    },
    "T36_MIXED_TAX_SHARES_SUM_GUARD": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF",
                 "seller_tax_shares": [{"cota": "1/2", "tax_percent": 1}, {"cota": "1/4", "tax_percent": 3}], "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_fail_closed": {"stage": "engine", "error_code": "INVALID_TAX_SHARES",
                                 "message": "Cotele impozitului nu însumează întregul (suma = 0.75)."},
    },
    "T36_MIXED_TAX_SHARES_CONFLICT_GUARD": {
        "case": {"acts": ["sale"], "price": 300000, "buyer_type": "PF", "seller_type": "PF", "seller_tax_percent": 1,
                 "seller_tax_shares": [{"cota": "1", "tax_percent": 1}], "currency": "EUR", "fx": {"mode": "operator", "rate": "5.08", "publication_date": "2026-08-25", "effective_date": "2026-08-26", "source": "operator", "operator_override": True, "operator_explicit": True}},
        "expected_fail_closed": {"stage": "engine", "error_code": "TAX_SHARES_CONFLICT",
                                 "message": "Impozitul pe cote (seller_tax_shares) nu se combină cu o cotă unică (seller_tax_percent)."},
    },
}
BATCHES = {
    "B1": [
        "NR01_SALE_PF_PF",
        "NR02_SALE_MORTGAGE_PJ_PF",
        "NR03_FULL_PJ_PF",
        "T06_ANTECONTRACT_SIMPLE_PJ_PF",
    ],
    "B2": [
        "T07_ANTECONTRACT_PF_PF",
        "T08_ANTECONTRACT_PF_PJ",
        "T09_ANTECONTRACT_PJ_PJ",
        "T05_STANDALONE_MORTGAGE_PF",
    ],
    "B3G": [
        "T13_FINANCING_MISMATCH_GUARD",
        "T14_ANTECONTRACT_ADVANCE_CLARIFICATION_GUARD",
        "T15_PARTY_TYPE_VARIANTS_GUARD",
        "T16A_OPEN_THRESHOLD_600001_GUARD",
        "T16B_OPEN_THRESHOLD_500001_GUARD",
        "T17_INVALID_NUMBER_GUARD",
    ],
    "B3D1": ["DELIVERY_PDF_ONLY_GUARD"],
    "B3D2": ["DELIVERY_DOCX_ONLY_GUARD"],
    "B3D3": ["OPINION_NUMERIC_GUARD"],
    "B3D4": ["T21_EXTERNAL_ANTECONTRACT_DEDUCTION_700", "T21_EXTERNAL_ANTECONTRACT_DEDUCTION_GROSS_847", "T21_EXTERNAL_DEDUCTION_CONFLICT_GUARD", "T21_EXTERNAL_DEDUCTION_EXCEEDS_GUARD", "T21_SELLER_SERVICES_SUFFIX_AND_FEES", "T21_SELLER_SERVICES_GLOBAL_SWITCH", "T21_RADIERE_ON_SELLER", "T21_BUYER_SERVICES_UNCHANGED_AM133"],  # am.169 (V4.20)
    "B4A": ["ADJ_SALE_23_PERCENT_GUARD", "ADJ_MORTGAGE_14_QUANTITIES_GUARD", "ADJ_COMPLEX_BOTH_18_PERCENT_GUARD", "T25_SALE_REDUCTION_MINUS20", "T25_RADIERE_REDUCTION_MINUS50", "T25_ANTECONTRACT_REDUCTION_MINUS10", "T25_REDUCTION_100_GUARD"],  # am.174 (V4.22)
    "B4B": ["QTY_OPINION_INFORMATION_EXTRACTS_GUARD", "QTY_ANTECONTRACT_COMPONENTS_GUARD"],
    "B5A": ["T36_MIXED_TAX_SHARES_50_50", "T36_MIXED_TAX_SHARES_SUM_GUARD", "T36_MIXED_TAX_SHARES_CONFLICT_GUARD"],  # am.282 (V4.24)
    "B6A": ["T55Z_NOTARI_CF_SINGLE_COUNT", "T55Z_VERIFICARI_TOTAL_2", "T55Z_VERIFICARI_CONFLICT_GUARD", "T55Z_FORMAT_COMPLET", "T55Z_FORMAT_INVALID_GUARD"],  # am.367 (V4.25)
}
EXPECTED_IDS = set(BATCHES["B1"] + BATCHES["B2"] + BATCHES["B3G"] + BATCHES["B3D1"] + BATCHES["B3D2"] + BATCHES["B3D3"] + BATCHES["B3D4"] + BATCHES["B4A"] + BATCHES["B4B"] + BATCHES["B5A"] + BATCHES["B6A"] + ["DELIVERY_REPEAT_UNIQUE_GUARD"])


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", type=Path)
    parser.add_argument("--generator", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--batch", choices=["B1", "B2", "B3G", "B3D1", "B3D2", "B3D3", "B3D4", "B4A", "B4B", "B5A", "B6A", "all", "aggregate"], default="all")
    parser.add_argument("--search-root", type=Path, default=None,
                        help="Directorul Knowledge. Implicit: directorul acestei suite.")
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)

    if args.batch == "aggregate":
        batch_reports = []
        aggregate_errors = []
        combined_results = []
        for batch_name in ("B1", "B2", "B3G", "B3D1", "B3D2", "B3D3", "B3D4", "B4A", "B4B", "B5A"):
            report_path = args.output / f"REGRESSION_REPORT_{batch_name}.json"
            if not report_path.is_file():
                aggregate_errors.append(f"missing report: {report_path.name}")
                continue
            report = load_json(report_path)
            batch_reports.append(report_path.name)
            if report.get("status") != "PASS":
                aggregate_errors.append(f"{batch_name} status={report.get('status')}")
            combined_results.extend(report.get("results", []))
        ids = [item.get("id") for item in combined_results]
        missing_ids = sorted(EXPECTED_IDS - set(ids))
        duplicate_ids = sorted({item for item in ids if ids.count(item) > 1})
        if missing_ids:
            aggregate_errors.append(f"missing result ids: {missing_ids}")
        if duplicate_ids:
            aggregate_errors.append(f"duplicate result ids: {duplicate_ids}")
        if any(item.get("status") != "PASS" for item in combined_results):
            aggregate_errors.append("one or more individual results are not PASS")
        final_report = {
            "status": "PASS" if not aggregate_errors else "FAIL",
            "suite": "M1-C01_CLOSED_BRANCH_REGRESSION_V2.5",
            "mode": "aggregate",
            "scope": "closed branches through T21 (am.169: external antecontract deduction + seller-routed services); batched unique delivery, clarification, threshold, invalid-number, fail-closed audit and PF/PJ variant guards; no CORE change",
            "batch_reports": batch_reports,
            "errors": aggregate_errors,
            "results": combined_results,
        }
        final_path = args.output / "REGRESSION_REPORT.json"
        final_path.write_text(json.dumps(final_report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(final_report, ensure_ascii=False, indent=2))
        return 0 if final_report["status"] == "PASS" else 1

    here = Path(__file__).resolve().parent
    root = args.search_root.resolve() if args.search_root else here
    orchestrator = _discover(root, ORCHESTRATOR_PREFIX, "orchestrator")
    if args.engine is None:
        args.engine = _discover(root, ENGINE_PREFIX, "motor")
    if args.generator is None:
        args.generator = _discover(root, GENERATOR_PREFIX, "generator")
    results = []
    all_pass = True
    selected_names = list(CASES) if args.batch == "all" else BATCHES[args.batch]

    for name in selected_names:
        spec = CASES[name]
        case_dir = args.output / name
        case_dir.mkdir(parents=True, exist_ok=True)
        input_path = case_dir / "CASE.json"
        input_path.write_text(json.dumps(spec["case"], ensure_ascii=False, indent=2), encoding="utf-8")
        proc = subprocess.run(
            [
                sys.executable, str(orchestrator), "--input", str(input_path),
                "--output", str(case_dir), "--engine", str(args.engine),
                "--generator", str(args.generator),
            ],
            text=True, capture_output=True,
        )
        record: Dict[str, Any] = {"id": name, "returncode": proc.returncode}
        try:
            pipeline = load_json(case_dir / "PIPELINE_RESULT.json")
            if "expected_variants" in spec:
                expected = spec["expected_variants"]
                errors = []
                if pipeline.get("status") != "NECESITA_CLARIFICARE":
                    errors.append(f"pipeline={pipeline.get('status')}")
                if pipeline.get("stage") != expected["stage"]:
                    errors.append(f"stage={pipeline.get('stage')} != {expected['stage']}")
                if pipeline.get("error_code") != expected["error_code"]:
                    errors.append(f"error_code={pipeline.get('error_code')} != {expected['error_code']}")
                if pipeline.get("missing_fields") != expected["missing_fields"]:
                    errors.append(f"missing_fields={pipeline.get('missing_fields')} != {expected['missing_fields']}")
                variants = pipeline.get("variants", [])
                variant_ids = [item.get("id") for item in variants]
                if variant_ids != expected["variant_ids"]:
                    errors.append(f"variant_ids={variant_ids} != {expected['variant_ids']}")
                if any(item.get("buyer_type") not in {"PF", "PJ"} for item in variants):
                    errors.append("invalid buyer_type in variants")
                if any(item.get("seller_type") not in {"PF", "PJ"} for item in variants):
                    errors.append("invalid seller_type in variants")
                if pipeline.get("engine_status") != "NOT_RUN":
                    errors.append(f"engine_status={pipeline.get('engine_status')}")
                if pipeline.get("generator_status") != "NOT_RUN":
                    errors.append(f"generator_status={pipeline.get('generator_status')}")
                if pipeline.get("qa_status") != "NOT_RUN":
                    errors.append(f"qa_status={pipeline.get('qa_status')}")
                if pipeline.get("delivery_artifacts"):
                    errors.append("DOCX/PDF delivery artifacts unexpectedly present")
                request = pipeline.get("variant_request", {})
                if request.get("automatic_selection") is not False or request.get("assumption_applied") is not False:
                    errors.append("automatic selection or assumption was applied")
                audit = pipeline.get("audit_delivery_artifacts", {})
                required_audit = {"variant_request", "case_snapshot", "normalized_case", "pipeline_result"}
                if set(audit) != required_audit:
                    errors.append(f"audit artifacts={sorted(audit)} != {sorted(required_audit)}")
                run_id = pipeline.get("run_id")
                for key in required_audit:
                    path = Path(audit.get(key, {}).get("path", ""))
                    if not path.is_file():
                        errors.append(f"audit artifact missing: {key}")
                    elif path.parent != case_dir.resolve():
                        errors.append(f"audit artifact not at output root: {key}")
                    elif run_id and run_id not in path.name:
                        errors.append(f"audit artifact not run-bound: {key} -> {path.name}")
                run_dir = Path(pipeline.get("run_directory", ""))
                for generated_name in ("ENGINE_RESULT.json", "OFERTA_M1-C01_CANONICA.docx", "OFERTA_M1-C01_CANONICA.pdf", "RAPORT_QA_GENERATOR.json"):
                    if (run_dir / generated_name).exists():
                        errors.append(f"unexpected execution artifact exists: {generated_name}")
                record.update({
                    "status": "PASS" if not errors else "FAIL",
                    "errors": errors,
                    "pipeline_status": pipeline.get("status"),
                    "stage": pipeline.get("stage"),
                    "error_code": pipeline.get("error_code"),
                    "missing_fields": pipeline.get("missing_fields"),
                    "variant_ids": variant_ids,
                    "audit_artifacts": sorted(audit),
                })
                if record["status"] != "PASS":
                    all_pass = False
                results.append(record)
                continue
            if "expected_clarification" in spec:
                expected = spec["expected_clarification"]
                errors = []
                if pipeline.get("status") != "NECESITA_CLARIFICARE":
                    errors.append(f"pipeline={pipeline.get('status')}")
                if pipeline.get("stage") != expected["stage"]:
                    errors.append(f"stage={pipeline.get('stage')} != {expected['stage']}")
                if pipeline.get("missing_fields") != expected["missing_fields"]:
                    errors.append(f"missing_fields={pipeline.get('missing_fields')} != {expected['missing_fields']}")
                nested = pipeline.get("engine_result", {})
                if nested.get("clarification_code") != expected["clarification_code"]:
                    errors.append(f"clarification_code={nested.get('clarification_code')} != {expected['clarification_code']}")
                if nested.get("question") != expected["question"]:
                    errors.append(f"question={nested.get('question')} != {expected['question']}")
                if nested.get("proposed_value") is not None:
                    errors.append(f"proposed_value={nested.get('proposed_value')}")
                if nested.get("assumption_applied") is not False:
                    errors.append(f"assumption_applied={nested.get('assumption_applied')}")
                if pipeline.get("engine_status") != "NECESITA_CLARIFICARE":
                    errors.append(f"engine_status={pipeline.get('engine_status')}")
                if pipeline.get("generator_status") != "NOT_RUN":
                    errors.append(f"generator_status={pipeline.get('generator_status')}")
                if pipeline.get("qa_status") != "NOT_RUN":
                    errors.append(f"qa_status={pipeline.get('qa_status')}")
                if pipeline.get("delivery_artifacts"):
                    errors.append("DOCX/PDF delivery artifacts unexpectedly present")
                audit = pipeline.get("audit_delivery_artifacts", {})
                required_audit = {"engine_result", "case_snapshot", "normalized_case", "pipeline_result"}
                if set(audit) != required_audit:
                    errors.append(f"audit artifacts={sorted(audit)} != {sorted(required_audit)}")
                run_id = pipeline.get("run_id")
                for key in required_audit:
                    path = Path(audit.get(key, {}).get("path", ""))
                    if not path.is_file():
                        errors.append(f"audit artifact missing: {key}")
                    elif path.parent != case_dir.resolve():
                        errors.append(f"audit artifact not at output root: {key}")
                    elif run_id and run_id not in path.name:
                        errors.append(f"audit artifact not run-bound: {key} -> {path.name}")
                run_dir = Path(pipeline.get("run_directory", ""))
                for generated_name in ("OFERTA_M1-C01_CANONICA.docx", "OFERTA_M1-C01_CANONICA.pdf", "RAPORT_QA_GENERATOR.json"):
                    if (run_dir / generated_name).exists():
                        errors.append(f"unexpected generator artifact exists: {generated_name}")
                record.update({
                    "status": "PASS" if not errors else "FAIL",
                    "errors": errors,
                    "pipeline_status": pipeline.get("status"),
                    "stage": pipeline.get("stage"),
                    "clarification_code": nested.get("clarification_code"),
                    "question": nested.get("question"),
                    "missing_fields": pipeline.get("missing_fields"),
                    "audit_artifacts": sorted(audit),
                })
                if record["status"] != "PASS":
                    all_pass = False
                results.append(record)
                continue
            if "expected_orchestrator_fail" in spec:
                # V2.5 (am.367): fail-closed ridicat de orchestrator la normalizare (inainte de motor) — fara artefacte de audit
                expected = spec["expected_orchestrator_fail"]
                errors = []
                if pipeline.get("status") != "RESPINS_FAIL_CLOSED":
                    errors.append(f"pipeline={pipeline.get('status')}")
                if pipeline.get("stage") != "orchestrator":
                    errors.append(f"stage={pipeline.get('stage')}")
                if pipeline.get("error_code") != expected["error_code"]:
                    errors.append(f"error_code={pipeline.get('error_code')} != {expected['error_code']}")
                if expected.get("message") and pipeline.get("message") != expected["message"]:
                    errors.append(f"message={pipeline.get('message')}")
                if pipeline.get("delivery_artifacts"):
                    errors.append("delivery artifacts unexpectedly present")
                if errors:
                    all_pass = False
                results.append({"id": name, "returncode": proc.returncode, "status": "PASS" if not errors else "FAIL", "errors": errors})
                continue
            if "expected_fail_closed" in spec:
                expected = spec["expected_fail_closed"]
                errors = []
                if pipeline.get("status") != "RESPINS_FAIL_CLOSED":
                    errors.append(f"pipeline={pipeline.get('status')}")
                if pipeline.get("stage") != expected["stage"]:
                    errors.append(f"stage={pipeline.get('stage')} != {expected['stage']}")
                if pipeline.get("error_code") != expected["error_code"]:
                    errors.append(f"error_code={pipeline.get('error_code')} != {expected['error_code']}")
                if pipeline.get("message") != expected["message"]:
                    errors.append(f"message={pipeline.get('message')} != {expected['message']}")
                nested = pipeline.get("engine_result", {})
                if nested.get("error_code") != expected["error_code"]:
                    errors.append("nested engine error_code mismatch")
                if pipeline.get("generator_status") != "NOT_RUN":
                    errors.append(f"generator_status={pipeline.get('generator_status')}")
                if pipeline.get("qa_status") != "NOT_RUN":
                    errors.append(f"qa_status={pipeline.get('qa_status')}")
                if pipeline.get("delivery_artifacts"):
                    errors.append("DOCX/PDF delivery artifacts unexpectedly present")
                audit = pipeline.get("audit_delivery_artifacts", {})
                required_audit = {"engine_result", "case_snapshot", "normalized_case", "pipeline_result"}
                if set(audit) != required_audit:
                    errors.append(f"audit artifacts={sorted(audit)} != {sorted(required_audit)}")
                run_id = pipeline.get("run_id")
                for key in required_audit:
                    path = Path(audit.get(key, {}).get("path", ""))
                    if not path.is_file():
                        errors.append(f"audit artifact missing: {key}")
                    elif path.parent != case_dir.resolve():
                        errors.append(f"audit artifact not at output root: {key}")
                    elif run_id and run_id not in path.name:
                        errors.append(f"audit artifact not run-bound: {key} -> {path.name}")
                run_dir = Path(pipeline.get("run_directory", ""))
                for name in ("OFERTA_M1-C01_CANONICA.docx", "OFERTA_M1-C01_CANONICA.pdf", "RAPORT_QA_GENERATOR.json"):
                    if (run_dir / name).exists():
                        errors.append(f"generator artifact unexpectedly exists: {name}")
                record.update({
                    "status": "PASS" if not errors else "FAIL",
                    "errors": errors,
                    "pipeline_status": pipeline.get("status"),
                    "stage": pipeline.get("stage"),
                    "error_code": pipeline.get("error_code"),
                    "message": pipeline.get("message"),
                    "audit_artifacts": sorted(audit),
                })
                if record["status"] != "PASS":
                    all_pass = False
                results.append(record)
                continue
            artifacts = pipeline.get("artifacts", {})
            engine_path = Path(artifacts.get("engine_result", {}).get("path", ""))
            qa_path = Path(artifacts.get("qa", {}).get("path", ""))
            docx_path = Path(artifacts.get("docx", {}).get("path", ""))
            pdf_path = Path(artifacts.get("pdf", {}).get("path", ""))
            delivery_artifacts = pipeline.get("delivery_artifacts", {})
            delivery_manifests = pipeline.get("delivery_manifests", {})
            engine = load_json(engine_path)
            qa = load_json(qa_path)
            errors = []
            expected_case_sha = __import__("hashlib").sha256(
                json.dumps(spec["case"], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
            ).hexdigest()
            if pipeline.get("case_sha256") != expected_case_sha:
                errors.append(f"case_sha256={pipeline.get('case_sha256')} != {expected_case_sha}")
            run_id = pipeline.get("run_id")
            run_dir = Path(pipeline.get("run_directory", ""))
            if not run_id or not run_dir.is_dir() or run_id not in run_dir.name:
                errors.append("missing or invalid unique run directory")
            for artifact_name, artifact in artifacts.items():
                path = Path(artifact.get("path", ""))
                if not path.is_file():
                    errors.append(f"artifact missing: {artifact_name}")
                elif run_dir not in path.parents and path != run_dir:
                    errors.append(f"artifact outside current run: {artifact_name}")

            expected_delivery = spec.get("expected_delivery", DEFAULT_DELIVERY)
            if pipeline.get("delivery_request", {}).get("requested_formats") != expected_delivery:
                errors.append(
                    f"delivery_request={pipeline.get('delivery_request', {}).get('requested_formats')} != {expected_delivery}"
                )
            if set(delivery_artifacts) != set(expected_delivery):
                errors.append(f"delivery formats={sorted(delivery_artifacts)} != {sorted(expected_delivery)}")
            for fmt in expected_delivery:
                delivered = delivery_artifacts.get(fmt, {})
                path = Path(delivered.get("path", ""))
                expected_suffix = f"_{run_id}.{fmt}"
                if not path.is_file():
                    errors.append(f"delivery missing: {fmt}")
                elif path.parent != case_dir.resolve():
                    errors.append(f"delivery not at output root: {fmt} -> {path}")
                elif not _is_run_bound_name(path.name, run_id, fmt):
                    errors.append(f"delivery name is not unique/run-bound: {path.name}")
                elif "LIVRABIL_CURENT" in path.name:
                    errors.append(f"legacy fixed delivery name used: {path.name}")
                _fmt_key = fmt + ("_scurt" if str(pipeline.get("offer_format") or "scurt") == "scurt" else "")  # V2.5 (am.367)
                source_hash = artifacts.get(_fmt_key, {}).get("sha256")
                if delivered.get("sha256") != source_hash:
                    errors.append(f"delivery hash mismatch: {fmt}")
                if str(pipeline.get("offer_format") or "scurt") == "scurt" and "_SCURT" not in path.name:
                    errors.append(f"short format requested but delivery is not the short set: {path.name}")
                if str(pipeline.get("offer_format") or "scurt") == "complet" and "_SCURT" in path.name:
                    errors.append(f"full format requested but delivery is the short set: {path.name}")
                if delivered.get("run_id") != run_id:
                    errors.append(f"delivery run_id mismatch: {fmt}")
            for fmt in set(DEFAULT_DELIVERY) - set(expected_delivery):
                unrequested = list(case_dir.glob(f"M1C01_*_{run_id}.{fmt}"))
                if unrequested:
                    errors.append(f"unrequested root delivery exists: {fmt}")

            root_manifest_path = Path(delivery_manifests.get("root", {}).get("path", ""))
            run_manifest_path = Path(delivery_manifests.get("run", {}).get("path", ""))
            if not root_manifest_path.is_file() or root_manifest_path.parent != case_dir.resolve():
                errors.append("root delivery manifest missing or misplaced")
            elif root_manifest_path.name != f"M1C01_DELIVERY_MANIFEST_{run_id}.json":
                errors.append("root delivery manifest is not run-bound")
            latest_manifest_path = Path(delivery_manifests.get("latest", {}).get("path", ""))
            if not latest_manifest_path.is_file() or latest_manifest_path.name != "M1C01_DELIVERY_LATEST.json":
                errors.append("latest delivery manifest missing")
            if not run_manifest_path.is_file() or run_dir not in run_manifest_path.parents:
                errors.append("run delivery manifest missing or misplaced")
            if root_manifest_path.is_file():
                delivery_manifest = load_json(root_manifest_path)
                if delivery_manifest.get("run_id") != run_id:
                    errors.append("delivery manifest run_id mismatch")
                if delivery_manifest.get("case_sha256") != expected_case_sha:
                    errors.append("delivery manifest case_sha256 mismatch")
                if delivery_manifest.get("requested_formats") != expected_delivery:
                    errors.append("delivery manifest formats mismatch")

            if pipeline.get("status") != "READY_FOR_HUMAN_REVIEW":
                errors.append(f"pipeline={pipeline.get('status')}")
            if engine.get("status") != "CALCULATION_PASS_INTERNAL_DRAFT":
                errors.append(f"engine={engine.get('status')}")
            if qa.get("status") != "PASS":
                errors.append(f"qa={qa.get('status')}")
            for key, value in spec["expected_totals"].items():
                actual = engine.get("totals", {}).get(key)
                if actual != value:
                    errors.append(f"total {key}: {actual} != {value}")
            # V2.3 (am.169): expected_components verificate efectiv (V2.2 le declara la NR24 fara sa le compare)
            for _comp, _fields in (spec.get("expected_components") or {}).items():
                for _k, _v in _fields.items():
                    _actual = (engine.get("components", {}).get(_comp) or {}).get(_k)
                    if str(_actual) != str(_v):
                        errors.append(f"component {_comp}.{_k}: {_actual} != {_v}")
            # V2.5 (am.367): serviciile (0 cand aliasul a fost absorbit), formatul livrat, textul e-mailului complet
            if spec.get("expected_services_total") is not None:
                _st = engine.get("totals", {}).get("services_total") or "0"
                if float(str(_st)) != float(str(spec["expected_services_total"])):
                    errors.append(f"services_total {_st} != {spec['expected_services_total']}")
            if spec.get("expected_offer_format") is not None and str(pipeline.get("offer_format")) != spec["expected_offer_format"]:
                errors.append(f"offer_format {pipeline.get('offer_format')} != {spec['expected_offer_format']}")
            for _needle in (spec.get("email_must_contain") or []):
                _em = artifacts.get("email_docx", {}).get("path")
                _et = _extract_docx_text(Path(str(_em))) if _em and Path(str(_em)).is_file() else ""
                if _needle not in _et:
                    errors.append(f"email lacks: {_needle}")
            # V2.4 (am.282): expected_seller — campurile blocului seller al vanzarii (impozitul pe cote: tax, tax_mode, tax_percent_label)
            for _k, _v in (spec.get("expected_seller") or {}).items():
                _actual = ((engine.get("components", {}).get("sale") or {}).get("seller") or {}).get(_k)
                if str(_actual) != str(_v):
                    errors.append(f"seller.{_k}: {_actual} != {_v}")
            actual_pages = qa.get("details", {}).get("page_count")
            if actual_pages != spec["pages"]:
                errors.append(f"pages={actual_pages} != {spec['pages']}")
            docx_text = ""
            pdf_text = ""
            try:
                from zipfile import ZipFile
                import xml.etree.ElementTree as ET
                with ZipFile(docx_path) as zf:
                    root = ET.fromstring(zf.read("word/document.xml"))
                    docx_text = " ".join(t.text or "" for t in root.iter() if t.tag.endswith("}t"))
                pdf_text = _extract_pdf_text(pdf_path)
            except Exception as exc:
                errors.append(f"text extraction failed: {exc!r}")
            combined = (docx_text + "\n" + pdf_text).lower()
            for phrase in spec.get("required_phrases", []):
                if phrase.lower() not in combined:
                    errors.append(f"missing phrase: {phrase}")
            for phrase in spec.get("forbidden_phrases", []):
                if phrase.lower() in combined:
                    errors.append(f"forbidden phrase: {phrase}")
            record.update({
                "status": "PASS" if not errors else "FAIL",
                "errors": errors,
                "totals": engine.get("totals"),
                "page_count": actual_pages,
                "qa_status": qa.get("status"),
                "delivery_formats": sorted(delivery_artifacts),
            })
        except Exception as exc:
            record.update({"status": "FAIL", "errors": [repr(exc)], "stderr": proc.stderr[-4000:]})
        if record["status"] != "PASS":
            all_pass = False
        results.append(record)

    # Repeat-delivery guard belongs to B3D (or the legacy all mode).
    if args.batch in {"B3D4", "all"}:
        # Repeat-delivery guard: two successive runs in the same output directory must publish distinct filenames.
        repeat_dir = args.output / "DELIVERY_REPEAT_UNIQUE_GUARD"
        repeat_dir.mkdir(parents=True, exist_ok=True)
        repeat_paths = []
        repeat_errors = []
        for idx, repeat_case in enumerate((
            {"acts": ["opinion"], "currency": "RON"},
            {"acts": ["antecontract"], "advance": 70000, "buyer_type": "PJ", "seller_type": "PJ", "currency": "EUR",
             "fx": {"rate": 5.2473, "publication_date": "2026-07-31", "effective_date": "2026-08-02", "source": "operator", "operator_override": True}},
        ), start=1):
            inp = repeat_dir / f"CASE_{idx}.json"
            inp.write_text(json.dumps(repeat_case, ensure_ascii=False, indent=2), encoding="utf-8")
            proc = subprocess.run([sys.executable, str(orchestrator), "--input", str(inp), "--output", str(repeat_dir), "--engine", str(args.engine), "--generator", str(args.generator)], text=True, capture_output=True)
            try:
                pipe = load_json(repeat_dir / "PIPELINE_RESULT.json")
                if pipe.get("status") != "READY_FOR_HUMAN_REVIEW":
                    repeat_errors.append(f"run {idx} pipeline={pipe.get('status')}")
                names = [Path(v.get("path", "")).name for v in pipe.get("delivery_artifacts", {}).values()]
                if not names or any("LIVRABIL_CURENT" in name for name in names):
                    repeat_errors.append(f"run {idx} invalid names={names}")
                repeat_paths.extend(names)
            except Exception as exc:
                repeat_errors.append(f"run {idx}: {exc!r}; stderr={proc.stderr[-1000:]}")
        if len(repeat_paths) != len(set(repeat_paths)):
            repeat_errors.append(f"delivery filenames reused: {repeat_paths}")
        repeat_record = {"id": "DELIVERY_REPEAT_UNIQUE_GUARD", "status": "PASS" if not repeat_errors else "FAIL", "errors": repeat_errors, "delivery_names": repeat_paths}
        if repeat_record["status"] != "PASS":
            all_pass = False
        results.append(repeat_record)
        
    report = {
        "status": "PASS" if all_pass else "FAIL",
        "suite": "M1-C01_CLOSED_BRANCH_REGRESSION_V2.5",
        "batch": args.batch,
        "scope": "am.367 (T55z, 09.09.2026): R-FORMAT-OFERTA (offer_format scurt implicit / complet, setul _SCURT run-bound), coliziunea notari_cf (o singura numarare), verificarile cumparatorului pe vanzare = TOTAL, taxele suplimentare in e-mail (+5 cazuri, lot B6A); closed branches through T17 plus operator honorarium/quantity adjustments; am.174 (T25, 31.08.2026): R-REDUCERE-ONORARIU — reducerea procentuala pe toate procedurile (+4 cazuri); am.367 (T55z, 09.09.2026, decizia titularului «B, rotunjim in sus»): etaloanele ANCPI pe ROTUNJIRE IN SUS la leu (supersedeaza am.172 / Î14c pe dosarele noi; etaloanele inghetate raman trunchiate, R-71); split batches with unique run-bound delivery, clarification, threshold, invalid-number, fail-closed audit and PF/PJ variant guards; no CORE change",
        "results": results,
    }
    report_name = "REGRESSION_REPORT.json" if args.batch == "all" else f"REGRESSION_REPORT_{args.batch}.json"
    report_path = args.output / report_name
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if all_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
