"""SPN STOICA AI — M1-C01 offer generator V3.13 (V4.26, am.368, titular 09.09.2026: SETUL SCURT PE LAYOUTUL OFERTEI COMPLETE).

V3.13 (am.368): decizia titularului «Nu respecta layoutul din oferta initiala si nici formatul pe tabele si nici de la cine e
si numele oamenilor si scoate taxa de arhivare din varianta scurta». Setul scurt (`_SCURT.docx` / `_SCURT.pdf` /
`EMAIL_SCURT`) se construieste cu ACELEASI functii de layout ca oferta completa (`_docx_generator`, `_pdf_generator_autofit`,
`_email_docx_generator`, parametrizate cu un model de layout): antetul biroului, blocul «Datele utilizate pentru calcul»
(client, broker, parti, acte, pret, moneda, curs), tabele eticheta / mod de calcul / suma, stilul (fonturi, culori, linii),
subsolul. Continutul e redus la sectiunile din `oferta_minimalista_taxe_vanzare.docx`. Randul «Taxa de arhivare» IESE din
setul scurt; suma ramane in calcul («Onorariu + TVA» = onorariu + arhivare + TVA, totalul inchide cu ENGINE_RESULT).
PDF-ul scurt prin `_pdf_generator_autofit` (nu DOCX -> LibreOffice), o pagina (QA `short_pdf_one_page`). Oferta completa
se produce si se verifica INTOTDEAUNA — fara `model` functiile de layout dau iesirea V3.12 neschimbata.

V3.12 (am.367): (1) e-mailul complet randeaza si taxele suplimentare declarate de operator pe cumparator (intrau in
total din V4.3, dar linia lipsea din e-mail — TIC-T55Z-EMAIL-TAXE-SUPLIMENTARE); (2) R-FORMAT-OFERTA: `offer_format`
= scurt (implicit) / complet — pe scurt se produce si setul scurt `<basename>_SCURT.docx/.pdf` + `EMAIL_SCURT_M1-C01.docx`
(litera «oferta_minimalista_taxe_vanzare.docx»), cu QA propriu (totalurile partii, fara tokeni interni, PDF randat).
Oferta completa se produce si se verifica INTOTDEAUNA; formatul decide doar livrarea (orchestrator V3.14).

V3.11 (V4.24, am.282, titular 03.09.2026: IMPOZITUL MIXT PE COTE).

V3.11 (am.282 — R-IMPOZIT-MIXT-COTE): când motorul întoarce `seller.tax_shares` (impozit pe cote), oferta scrie
«Impozit MIXT pe cote — 1% pe 1/2 + 3% pe 1/2» cu suma însumată din motor, în sinteză, în capitolul vânzătorului
și în e-mail; QA nu interzice nicio variantă (ambele procente sunt legitime în act). Fără cote → bit-identic cu V3.10.

--- istoric V3.9 ---

V3.9 (am.135 — R-OFERTA-INDIVIDUALA): calculul rămâne comun (același ENGINE_RESULT, același run_id, aceleași sume);
se sparge DOAR livrarea. `offer_for` ∈ {both, buyer, seller, split}: both = oferta comună de până acum (bit-identică);
buyer / seller = numai capitolele, rândurile de sinteză, totalurile și observațiile părții respective, capitolele
renumerotate 1..n, antetul fără rolul/numele celeilalte părți; split = două seturi de documente (CUMPARATOR + VANZATOR)
dintr-o singură rulare. `include_broker` (implicit true): brokerul rămâne în antet; dispare NUMAI la comandă explicită
(decizia titularului 26.08.2026: «brokerul rămâne, se scoate doar la comandă»). Serviciile suplimentare (am.133) intră
în totalul clientului (cumpărător / solicitant / debitor), deci apar pe oferta cumpărătorului, nu pe a vânzătorului.

--- istoric V3.1 ---

V3.1 corectează două defecte de livrare constatate la auditul din 12.08.2026.
Nu modifică CORE, formulele de calcul, tarifele sau conținutul ofertei. Sumele,
rândurile și textele rămân bit-identice cu V3.0; se schimbă exclusiv modul în
care conținutul este așezat în pagină și modul în care QA citește PDF-ul.

DEF-01 — flux de paginare
    La spețe aflate la limita paginii (constatat pe antecontract + vânzare),
    reportlab spărgea ultimul tabel lăsând două rânduri orfane pe o pagină
    altfel goală, iar DOCX-ul aceleiași oferte încăpea pe o singură pagină.
    V3.1 măsoară înălțimea reală a conținutului înainte de a desena și, dacă
    ultima pagină ar rămâne sub pragul de umplere, aplică o compactare
    verticală progresivă până când conținutul încape. Compactarea este
    limitată; dacă nici la limita minimă nu încape, ruptura este acceptată,
    dar se garantează un număr minim de rânduri pe pagina nouă (anti-orfan).
    Spețele care ocupă legitim mai multe pagini nu sunt compactate.

DEF-02 — dependență PyMuPDF nedeclarată
    V3.0 importa `fitz` necondiționat în QA. În lipsa bibliotecii, QA returna
    FAIL și orchestratorul raporta GENERATOR_FAILED, deși toate cele trei
    livrabile fuseseră generate corect. V3.1 folosește PyMuPDF când există și
    degradează la pypdf altfel, consemnând în raport extractorul folosit.

Calculul este furnizat de motorul V1.9.
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
import math
from decimal import Decimal as _D  # am.169
from typing import Any, Dict, Iterable, List, Tuple

LOGO_B64 = """iVBORw0KGgoAAAANSUhEUgAAAT8AAADICAMAAACpmBaMAAAAwFBMVEXTq5kcHSTg2J8hJi9fW1C7sZsAW1uydHKmm3fir3gbJ050dCkgJS/fxZ8AagDGrY4AAP//AP/w8GMA//9qHx9VAFUA/wB//3/ZwZ0AAADPt5QeJC4dIy0gJjEdIy3bwZwdIy0dIy0AAFX///8dIy3QuZEcIy0lJSrOtpOqqqrOtpP//3/OtpQAPT3OtpQXJiw6OjrPt5TOtpMcHDB/f39mZmYAADq/v3///wD/qqr/f38hJC7iyKL/AACqqlUAAH9o4lj4AAAAQHRSTlMQFAtaBg0CBAkFBgSU/wJGAQEEAQMDAQKIAPz6bf7R/lCvAwGPFDAOtwNNAigEjBQFz3AQAgUEBAEDAjD/AQMCcBkdsAAAH3BJREFUeNrtnQubojizgNWenp6Z3f3u3zkngphAuKggIK63vv3/f3WqKgkE1G57Zmdm14Z9tkcRIrxWqiqVVDFgP3rLhYzgn+wPbRRbi6TIf/jdDH74N8bexBG8+gMRYjsVF87Ei98FPwc2j4SQ+d/cHLUQSdXo++EHm3DzbyaIZ+eu0C2+G34e/D+ZOI7k30QQz+RSNYVNvht+bha5wsP79tyvNSZkMlzViHCjzH1P/OhFhB0PjMlN9WYpxKOrGzAZqAYiwva++G38D/TmnpSXvH9zM/eSVOg9Ifvgb94ZPxSg9QdimIP19FQ/vnSDfuuBBSd378OHNQnklfLLzvEbhPjud8Ww4lK60WXubx65UpIDCex+x3/CwTl+2V+c3zPYx6it3RS/31mYJKv0FvesfycKEY+i4tUWiwiOI/K/r4ldukqSENrr8PPJLeRwBX9lfiAWYCCiY/n7naXjh/G4XM5TLUh3+Nkl/R/+v9Nim86X5RjaSY/5AT0wL+4f4KH/ZH5kYi0/r+GH27RhyD7NLmpz9ok17KbUSocf+YVknK+CHzq43k2sCbb5EcMpMiR1yLaHF9s7bOmfENlNp3ULLX7wLfGNhz71lfCbSBAG8JRzdpqfQjhOFMPDeSmcHRS7ZGzDO5K/HLxqEHl5LfI34aj2XSHIRznJr2a4gq68Xp9sC3eDseiy6/JTXwSGiF8NPzcjP6K44VF2np9mmMxB0E4JH2Pz5AS7Nr8s4jdkxLPMvR5+6IfdflIO2Yv8yKIkKXs6aumJpcl4euYcix8Zok/4RdfEr5ixZblc3bLHV/khwfmRBD6x+Vl6Nr9HNljBN7FZcXX8HqbTOVtfwA+2OWvb4QPge2Fr+M2Q88NV8psilgv5lWEQWM0EQTi+nN94+u75TVdsbzUzorN7fhfzG5eDfzat7IKw7OXvTfwAyaJuZfH6wT2/IwvSdOA9m097fm/iB6Z6W7ey7fl9Bb9e/r5N/82soVuv/97O72B5zz2/t/ovn1v+86D3X97mPy8t84EGpPef3yZ/7QjC7OXhb8/vaAtZq/+yfvz7Fn4AYNFqZ8GSac9v/Ib41awTfJ738nc5v3J/1NK+7Pldyq8TvVJDkNW053chvyZ6upgt6ghq2fO7jB+I30xDM39QA66mPb+L+JUDxWzHWJqmTHkywfoFAez5nRA/cPoSeJtoV/AlAez52eK3JV7/PnxKHsbl+CEZHf5NPEdlz+8Cftr3a4JWqdkx7/m9ym+a6KFHHTStQ6nnByE9P4vF41Nn0shMJT09pr38vcKv9l3QfiwfYM9DsgvqUdwZE9LzO7HwYMdGS9izDNGRedmJ7vmdiRwsx8tLogg9v7r/luGijvyN9sBvNqqjgIuw7Pvva/a3UYCo78btt739fd3/C3eHJuhi8Tvswt7/e50f3LwJXo2I376muZz2/C6IH6Rm7mNL/LbGnUn7+MFF8YPkbmb4zZt1MLO7pI8fXBY/NT4M8Bsbfi/OgPT8Ok70IejwCw59/Pkt8x+zDr9ZP//R4Re+vnpoT/zQ/r6ygih8l/J3XqCmCWXQNPyeXpo/n75D+SvYLaWyvWhCMISaqhfz8/DG5SqE9t4XP7qtEaWhnjEhswD5lcgvmJ1Zv9YkvvrvjN8XpoKi4fx0VhtNoT9pfmcmzzHXkK4fdOWXd8VPxvTZboa6LV2eJBgG6wXxW6xPZh9Nx0tMW9/vd8Qolu+InykfhjEpUG/hCYLIQPObnRj4KnqzJz3SUwXE3gc/Z6LKh0U6oR8JpskpH+YW9tPf4w8TpLdQX4GVIqhKgHP1/HYzrOzgKYTinrENCSHsnXdDo9Mk2BK/bdD1XablHFwaylLfGHpYBYvD3t11y98tTo4Pqe4X/CdNwZH1ATvxkQ/DwgQu8Mh3WYZNjj/oPWzJc6Mh/BDbEQrr1fJboa/xO5Vu0aXT3Ca4fMSpDIMwCY/njOwEf7cp4saoGNFgdcX8sEAEIlxj7aAYS7RMhCkdtgbRafdh8GFCELW27zIFizIywncvJlhcJtYtsnCVGNtzdfxWqvSDcdrWWOUBSwQ1IriF7trWdOFoOQo7WnHQZDa4ji5uVKxtV3KK8Yfr4pcVfpiuysbv/QR98Bc4gHuTifyij4Yxb8tTATladves69oSX+Rk4mFho1+gN982fni5Sm/94prqR0hTBi3VY94pjVnZHggWIER13eHDjq3aqm7VVoorVk8u5QJEt1D0BqtSNasKyNCWyeup3+QIl2tGGDaY1g7wFgBE3sQb6vsMblsAp+WqpRJXTK1tg6OHcBZ03WJbD2CmWrkiW65ryl4LP0cVKf2gpVBLCxgHdrdhlSQUatu3JbBsS9/eHAbQZcU2d2bwghKtJO+DKq3qXBc/zVBy5fGl+qZXt2wNndi1Sl/fdbqwja92W2IPlCr7T8A+rfRPoeDFXNbsro4fIYSuHKt+XJqRBBhP7nhVY4ZPR1uW7M4cUnkOp/PUqKVcUR3GWNWjtbe/Pj+O1esmHYQcnZe7OTlrScieCsYnoj7pZLUSwPevR3OEmHB0iULVwBy5FrwDj76V/8X5YYXdiLtSmIrZhqG4QV04T1S1pt0XAFjLyi4YHUXrp8k22NUyDfi+/KIqOmG5MfaLKmVswGE1bSFdHt1/94KyP6z+bkUYnYaih84HlVQbLwP2AaDcm2Kla3Y0ZitDk4/+zO4B9Qdc2wYW9+8oeq7XkHMIXPWjbusH8PP9pg/lEZei7mJU9hlU2G8wqPjARGNDjgsepLbtEHD0bTIl5akKQeuK+pJbNXzt7/3ryx/cT1ZDlCZgh6NfMKEP5YCtK0vb37Gu33xnWaQKBfRhvPqEI2ATTpQ1usz/cTf1w+tna4oRFw3BQYIAwdQ06qqVsW+bXhaj6U3LB4xsGXpClTT+oeR+Ej8tRMpXI5UlC3a3moKCY0LWR7SWOpcjqxqbBEMdltPlJ1ZI/RCHuG6TvQ9+NUIKAno3jP19XN6uI6uAs60C7VowsRetAR/YDaqx67k/Ed7P5AfbR6aDgI4o2O04AQF0VUBfGWHdg+3eu2EuiF8yHrDiV0eH/qid98iP6Yd44JOLbthtuQJ91ny0PtyWZjWWVZAX9OWqvEXhU6G/7OfewE/mpzYOMG7YoEzZr9aDLEwPbmU03P8KtmPAbhwV+vvp25+AH+iuHCwBAEwYt6E8QQ8GQ9EqxgsHLP/ObsDq5D9R6/3J5M9H3wUArkbsxtqt1h2EO7uc9g0brRAf/1PQ+5Pw0wG9m2B1x+2Rl8pf+Jc9CuSf5sGNFS7s+dVDO2/CRqOhPeIHJ3DZLsQbD0cjNvFy1vM7BugINuo+AiTsRHNYyoTz58H3Z+LHImcYfGjveqxzL/X2IRg6Eev5ndjAN5asw6+LDz6Xlo/d82v3YPcCMm7Oevk7s8Wv+yR+zHp+17P1/Hp+Pb+eX8+v33p+Pb+eX8+v33p+Pb+eX8+v33p+Pb+eX8+v33p+Pb+eX8+v33p+Pb/Xtu+d+2Hab/jtdr00fa38HfaYl3zYztRasfVPuJCMFjJnF/zwVl6R77fe1lskpSulEN/rYrnEDdMtkJ+9PnYW/JTedub11245x/TLife9rjd2TfsDqoOWrpKyTJIl5r9vt4OUPV7a0uN+Njr8AVeESeOeEJQLs8ny+zOH/cJd3mwubPj3xEpySorzvt8vju1jyu0AOivlQCar+XyVUEp9umRvQ/LN/Z1j0rhEIsKRFbx3z/TkZ13qyvGQHebFYvUh0T16w/jke/KLqbgH8ZtRunypq1ak5Xg5T5adpye+sM3mq9W32vACf0xTgwNQuly45zWhylU1y6QrzL854ud/Z35Zw08ly6fsdr9YbLEAy8P4QRUaCBaL/eBF0dqxQTKdYgL04pv6AiY8V2zjk/0oBEjUC3njUpHJcCvUDvkT+Jn+m6oMKS1Di4AtW4UaXhY+9YiiacKCr3Z+KMMfCxU0CMSLeffyiIwnfiI/SjKbrw2w9WyQaPkL03S+SlnwOr8y+Hp+H5nAW7XXNFN1iIv5ZZgS5/80fipFKqgFDh/bBPrvka2xOMNDRxR3LS87CMLkgQoYzM4d8vr+ivRZy+By5wX9dyx/kTgh1D+SH3TAxgY8sSQBfvsRlQaZb0dGtx107R/zL2zbWbhaLi13Z69ArrdtvbmoTz12jCLKo26rME++hV8u266jb/Pzi6JopVVn8H5zaijWeOWZdUpm/a0P7MofSFBtKQ5BuqJl74mutacRIMZRGIZ43KKN56nuz9jtw/Bgjte78ejbMPy0Y+zY0kTKIWklJUT8ZWtzXrKGcfUV8pdX8fmRT1xZS66rGN/kDb+yrkm4X1uGNVyqcpDJ6v/mGg062ckS/seKy4RssMJtmaTkAe4W7G6+VIdgLaWZkrV1QKculwkWa749Mk25cki86MKhxwv8sPiQBz44sDD8Ku0nRs0xtKPJdI85DMTgROHqY3J9CungHItBecKtKElPt89Yw8/U+kHHWVuR3SMW05sT2WU6V65hmowfkvQzG8zLBzwY5GgXpuXD9LfplPRfoKoBzcN/hvPxgymohKCxyssq/F/aXc473vZHBQRN8GVFR87yyzETm+c5x1s3/OLIw5EWOERKwJ5zd2IP7SqJdchirOY2Idcd+mok6BCX/VdVT8L6oMB2iHnKPAfeQLD2/0a6wJkpp9yYW6v/kpM91Y8S+5xMtcn4h5Wh+/g/iyVVoqc+jAXCVtgWPUTV7J6rgzuDm9jUvfEotcO/nN/HuKUHJkYLRFIV+KCj7qlt3ihU+kgYS+WYwkdYvsgbWlfk4ijNvc8jdO9z0jO6vkAkqVyy8p/ropmmrCERfFxsSf5Wh9GaqeKb5eCw37Fgq4rbILNgrbo/vA4WqsApGwVsNyJSD2DGD6r5FZbcDPbqJxl0dWBkagdhQv6rBGt+MEiT1q/gTbBQox7F3Dfj32Gb30bJlKgHPk6M+Uwb4jORui3FTwrVJVwQV1LT3KQ+UfUQ4rewqo7qsoYoH+C/GDQgQ3qMonqeru81R2c7NAfp53OMlGX5TI9LAEnbsxU+gzFEJci2AR4zPfbOoY81Jdrc+FL5y8BM+63dVT3+jRop9Vr8/JrfMzqaiMy39HDeiCjnwldo0UNHL7Uub5GT06/kb6FrwBmEqxHqLIufenDTNHlcKwfucTfQ1XEXNb/BTo9jVN/c7ub6DY5n4BVJ3F514PI43oD5507TjS/gF8c5qKmm4E6k7sc/4f+d46d/uNqykB/PG343prQtiKyrpbM48v9I8dsl6LHA7ZPNTz03bFo/CAuw1DtqfmrXfLdXjjX4RaVSpWsQzLlKId8Hit/2xJgmsguAifvX+DlCqNKzvr3XfSO/ZxA6zxTdUvxUE0pFNr8jj6SC65/gx/CmLYJkHBp+I/2kmGYkt1XDtvKp6b+62k1qXEEQO/UIGfYYsLlO4v2s+ngZHvPDIuyNDKJQvDJ+q6r83pK/zGv5kJfKH3maz3Zgx+KnjQlZ6ajto7b5gUQtVA3WpkL1vub3WT/HuLlrUxgjZTU/vSdsumaTda8f/743tE/x046XV5cCiy6xv43+69zf5fxqhakLPTb8rIKEvm6/OsdPuX5hU4MehK2RPwoxlP+smzvUbktQ85sfkWlebbeq58+Xqxf5obdrLIlXvcH+6hjOV/ErCq2B3U7/tYaUPrl7TlOey+J3MCPSYKSKn+uSP8Gi5kfFDEsrbKBGLQ8ri9/qtw6ZulllbMM5DJTD9GV+Gfqzugu7F8hfUdm34zR5/W+TvwKL6rlH+s+u/an4FfUZVvzU4jKjALTuibM2v8TmR9jAgOwafuimlJ+PyKAOTOdmSDd/Rf5ID2oBjC8ffxh+8dv5DWnihaZdXuInz/KDIZk1G/TZVH6cs+1r/Nry93CSDHg4VKyYCjMPgpP87v/7ekDhMn5W/3Uv81+wApxHNVM2F8jfsOEnDb/lvDV/OdCFC+ds0NF/QVf/TY/0n35smz2xhM75FIv7gf2YnZa/jrey0Rd7LoR6cvzLu8jleX6y5kcW3zXhqfP8jP6zKgeIml/SGg4EgeE26Njf27qWw3n7mzYFrlXMKxyrkcvngNVPIWvzK7Dqn39iQPwG+asiJbMWcs85w09zEkaoRF2+7SV+3d8nr8e/y3EaWAIIaj9Rt9z0X8Nm3fH/Qsv/G5XmoVmtuCAN2EqmHsG9P8PP6ai6zIyk/M3mIn6R3HSqPVcWP9Hmlzta/uIO85f6b66PzVpBX4pfPSztm35k9LScsrEf+8WOiDbjj8W58QcYabtnBnf0WKPpcjfTo7oT/jOqkk6Va/pxvYvjVz76Mbo/+VofctHhZ74CuqKn+UXtiYOs6z+3roraN+VVdCMm/je3AAZkUoHNoR6/HfT4t77rxxEJ5AAUWnv82+7AIKZLJD9dPs6scd8Jfp2+OlQCA0ZOCH6J/EmpO5hxGv8m3YafO7H9lUq6LX5RW2uc48dtn+A5F9Lih8Jm3TT2OOiagY7/zdZP6r5THXeiQ9B63B3HX8q7hWnqM0uTcKn670wZk1PjjwL1uZd17MdExOgjTCbHZqTLbwN3LuvR/0YLZB1/MWOHXB8sOdc8c7v/bo7GH21+KqTFzRVKPrHiz3BHnym4Aj403SONY1WvnWGEYY+vEziIuAyUhC7qIq/zwyxYrJWsMXa7OKwXOKQu57VZvg0C0LJm/BF05c8RsYmsbaj7wi/9kXknBlpdfljOFxWACpNqAcm9yIpfKV2PVYsoBK9AeZvahuYmJkr6D2eTTFfeWFFyHeCheFblVeT/eWr+d/pAyzeeMGBCZanRDdmSS4c80jk73C1JA7LZYMF0oHRBjqB+TlEAinNLUrrUwYLtqiS1+FvjO65WZpTcth8TfAxSbGbCYnhP75jXHoXa4WOvFblxMLBEPYwGdDEMJkjIdH+2jKcrKi1olYnbKpmKBYVY1KBt6NRtWR6ljkmjLPJ6wDOAcQEGDpbpnkZZOLlxq6YzsEQ1gFotQ/Wkg/EDsUmTB3x6XUBzasuHKfw3TgeBmv+A32K8nKc44oBjZrv1Z4zrTJN0EKbLFTT5m1psY0eghYvP4nJU3DR3MQAYa6cB+m/bOTTTFxMZ0YYLjiY6bIxVQB1xf+9iAJHTUSLfYJTKJVASDpZDxlQLsiow/IcOYF5Frow0cjgil3SEw/OOj4nFkqOI2teN5IM5+hZqag1GWeoRLgc1yiDrSRFp6KlsPV+WJR5T0pMTafULjGnVlsK7YME+4QNVqY/iMQpSSrug+RRdoZJEtFXTj+rgR1J4QuJzBkRz2VzKrhfIhZACD5RqE7S5JvqgH2wI0ujRUXpOSptjbG1TfwQ/0lA9pkZImnlBmwCiFbu6bclPxYewlbhuZMAen2iiEVdrpCHCNM+UDHBnuNWRFDQBMzgoJZyLTohlUc//hiBpIT2jbK3mUXBGOKVd+LN8CtPw5LAXp8oiHuXfVt4qNw0Uw84kVR5Vevgax50PcvODVfevTAEWsTnYNDJ4VOsDzNgiaBYX0Myt9ai6vXm1b/ztxX673e5n9cqM/aL7AmdJmln0Azs1hd7M8LdfvXUpavZCWOJ0e9npM30/y04sCz5xPXX8ZResD+ugM/wP1q2FQbsAdgQvr01Vx3R2resFRvDxT1kh/L22Pv+j59fz6/n1/K55+5Zsro+nHu/gf9TNvlf5424vf5dtOJwQR4tqLi7CHQlxHAmPpbjBUY0bXz2/yvOiXE7k0RxVKzzlN39bezHRg2Kv9UcRPiLiHhcQ+rh45sr5behZe6xwnFYUgrme9cRNq2Z8XDRDEx0Lc6WSVD3RLiYYrOS/RvgsEn7t/TejRz0y1p0wiVwMXH1UsQXJb1yMvOY3krs6aBBJ15U3FS7mpafUcYzeuBt62C7PuZQuRgzl9fNz8WEXrnePPa8J7MSVo5fwcnyaQ4ypqJGHMUJ3Iv+Ge0WMDzW9x/7LWSUwo0JMKM7tYbAW467Qf9lgcYWbPcIeSlzsltM8gTEEOacwNgkgyNMGQ1+Ig+bXkFKEodGYZgY5TsVEIL+0ZjJS/GIPUUp4ef32lwsxwbAePThOaT982l6EIvRMHHECP8JZl0ivzIiRDAZwOVP82L1acw8vu/yS69vKVRMiK4QzZLigXjJhpm9jt6oqTFPEp4bHtPD+njpmrqPeXDRLWbmeOx5GXJ7iN726DReuL4yoSbWmHMyFK6vad6bka730ucJccgeXXymLDMDAOrf5xWhkIn6K3/j6tmnND5WaC4rMx1kno/0qnhdZln8BAaxYHKk1cxOQUVxzaOSvttf4FiwHrsQ/yS+8vm3UzBDkKEmsiNEiGH4qOewZzQHIpvucKZnjpP8yVIgxTenj7GUew0eR7sMn+V133AAnR9H/xYVqN7pLmkd8fQHTWzD1GD6PyNBSLJJYTw1YCjcHOxNFZENwfknb32HDL7jCzZphoKQuIbzaJGSuWRqME80Sh3dx7mL5ADiUV7kEoXxGX1BEw8iNPoLRkGBrvPuco5SieeYI1MvzdzB+o5GDEDJGo1Eo42vyBGM0IlEMA9p60OFy12Th4RADJDVHU5PjOx4z91ea3eRDaMyN8Gjex0/fukWtWM718/NVWQpWmEnMeq7Sz3y13MiexqzX3Bc+5VCr+kY+TWf6BalKyfIMW8E/vfy9WR84vJ//+Jb+K1nP71vC2VXP7xu2Ycx6fn/c1vPr+R1t+RCrjnzPb6DMu1jx87Osdomsl82bTDlLtDFVuMt8pCemm32+9aE5y6+bswrZNAepM/zWK3C17C9vH8/srz5eg+bjKt3Iu2H+0Qf1NXWuutWcdcXdBvwmLsFzV5yWP//sm5+9PV9qIwUN2b6rF+gJeoj4AAckrplZiWBEV38vvskpXoYxMl3yMdqY4o9REwuKzL7cvDSxIvVm2BwU16Mg803m5Kp+5bPmonJ9afdwMZEetma6aXOZsQnrWbdn+bh5/UXNV1e0374Tc8mRvhHrxMp8xq2Z9HvlxwwK4Zj6cbl6qeK0lX6DhU9ckyzhODwzGeKSYVRtgouN3SZrXOc/Gx9TJ5RzGvc49Qr2SO2XWZ0t6Hi5KaTj5eZKaB04BuKaK8tgj2rcM9kJulggnzTMIjtXLdLL+YVjfbVb53ni6xjrdSAznYUJ+7JCt4jJg57KZMCyg6ZVoaLXA+lglAFLiOae4+ZZ5FKsVb+RIKTErwKSeRyDZo7jSjpRTuuMpeOhEsBPHEFFpDwP/onrVcyeyPNcTQziJ1VE07Fw5TyGximfwoXGqjjPM5wgi80ruqgIR0uRupg4G7qU38F1brWnsmNgp7o7biETnpV9ENH6fF/xixzQXFWECxLgMkFI4G9uzsByJcLJY/zcrVuMPU8P2epCg5iU4xHwgVdHqoW+AI7nmjcYe9T8Gtl1dWJF7Lj1VetEF689UU141cmermYj2EdPLz6htQGubgETS43NNK346h7kxFyZxLtCiYv1Mb94IlICaI1Lhw53m2IFeKsuzUbSag711bpJ4WxIr0IbEi9qo6WUWtf35jpDXaWj5vcReOe0AmQApDUp6pH6XEyJ2tTfr/nFFVUii6HFnBqBi8xg/3OLn1/B1vArsGIZfuh5RQwv4RqwQZrqinG/q9MvkR/IdlX9DUtiqYtS/Co4TF8ZTchyoeRZ5ZlHTN1dze8ZGoJzXJOYCl8n8YdCMsg6R4OK97NBppXC4RTEA/nFRTykgxW/Aq5YaRGr0CXeAuWNDmKhEyOiiSlaCPcROXZpmkb/IaRC8yPi5rXhJ9rJ90r+SKKVvKAINZIiPGyAci0ikySPH5qL+kj3EDnNlWGaC68wfUi1p+TknsVWq7kqXZVb148aBJG4dSeHE/1C81O3iDwKLX/YTei7Y8VO3Yfhh7wzOskfoCURqEOHcJN6iYxDn220/6LlT1C15YbfR3Uxue7YRv4cOmxY2w/McaGZVXop0To0d+oRPw83TtW6cIuVeROO0UFDxxT+wR6OWj2aeHhuRk1tYrqvplWJghHVAkji7ji5dGwlCddr+GnNEeleTpeJufrqYPieQnOv5Q8UF6L2qmfl/6EerXCNzQaz47C7qDd+q/8a31vLXOXRnevUxjP6Dw9RWUACX9IcIXbbzKeSXbLTf+1zK1yjRzLg6Sv7D14VWUUQY9j5AWdz6BLI0nB/gx4usKKdZp4jUsZWoGTdwzfCVyunQvP7G5YQVWcMC3WZKN+Z4sfVZ2T0PeF/8fHCpfpauJJBVCkdiSWhXT2tglpdvalAkk7zw4Q9EhcXPv7wgv3YPNeyRiaWpgh1Hh7+yrb9qL3DqpY2ugftssjJjeJH9asphVeqSxCWaLnmunjDb0gcyO3g+qtzlfteUfUJVTJRaclY6dJCtSjUZ0rlCqMgqDO6cEsDD+t+oyeBWttzuevRBNTGvImM/lMVv3ktf5lBpZZytvqvy/2a3z/0+EfrK7y8oZgIFwweXaXNT914FauLcqSiUlhXprwySloVjNRQrRcVSx6blFcwWDW/gkpA0Hxc/dWGH3U4fUaGlgQuWWiJVjevdX3hKQa5W3sqfEDVAR012uGeSr9jrTekjnWVTbylTPkvEaoe39/QCx9rKTX2ozYgnqjNOD4NwVddlqn8d6Hdg7x2ixxdxkVfVK7sh28uhuOXR0quKmgarwwvwUd3getvvnEi7Me+OZVOyLSxwvinp7IsaVwrPaXnfLoTPEN6uFwBVap+m/sMP5OgDvTNcYF35W82Q0/8Py3YXK55kDebAAAAAElFTkSuQmCC"""

NAVY = "172433"
BEIGE = "D8C49A"
LIGHT_BEIGE = "F2EBDD"
MID_GREY = "E8E8E8"
DARK = "1F2933"
WHITE = "FFFFFF"
CONTACT = "+40 722 222 281    contact@notariatstoica.ro"
OFFICE = 'Societate Profesională Notarială „STOICA S. EDUARD & ASOCIAȚII”'
FOOTER_OFFICE = 'SPN STOICA S. EDUARD & ASOCIAȚII'
ADDRESS = "Sediul: București, Sector 1, str. George Enescu nr. 27-29, incinta U.G.I.R."
ACCOUNT = "Cont: Libra Bank RO15 BREL 0002 0018 8670 0100"
CIF = "C.I.F.: RO39694340"
LICENSE = "Nr. licență de funcționare: 14/08.01.2025"


def money(value: Any) -> str:
    if value is None:
        return "—"
    try:
        v = float(str(value))
    except Exception:
        return str(value)
    return f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".") + " lei"


def num(value: Any) -> str:
    if value is None:
        return "—"
    return f"{float(str(value)):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _write_logo(target_dir: Path) -> Path:
    p = target_dir / "spn_stoica_logo.png"
    p.write_bytes(base64.b64decode(LOGO_B64.encode("ascii")))
    return p


def _person_label(code: str | None) -> str:
    return {"PF": "persoană fizică", "PJ": "persoană juridică"}.get(code or "", "—")


def _source_label(value: Any) -> str:
    raw = str(value or "—").strip()
    if raw.lower() in {"operator", "curs furnizat de operator", "curs furnizat expres de operator"}:
        return "curs furnizat de operator"
    return raw


# ---------------------------------------------------------------------------
# PATCH V4.17 (am.135, R-OFERTA-INDIVIDUALA): oferta individuală pe parte
# ---------------------------------------------------------------------------
OFFER_SCOPES = ("both", "buyer", "seller", "split")
OFFER_PARTY_SUFFIX = {"buyer": "CUMPARATOR", "seller": "VANZATOR"}
_SELLER_MARKERS = ("vânzător", "vanzator", "vînzător")


def _offer_scope(data: Dict[str, Any]) -> str:
    """Scope-ul de livrare al ofertei, citit din configurația în memorie (both implicit = comportamentul V3.8)."""
    raw = str((data.get("configuration") or {}).get("offer_for") or "both").strip().lower()
    return raw if raw in ("both", "buyer", "seller") else "both"


def _broker_included(data: Dict[str, Any]) -> bool:
    """Brokerul rămâne implicit; dispare numai la comandă explicită (include_broker == False)."""
    return (data.get("configuration") or {}).get("include_broker", True) is not False


def _party_of_label(label: str) -> str:
    """Clasificarea unui rând/capitol după etichetă: «vânzător» → seller; restul (cumpărător, solicitant, debitor, servicii) → buyer."""
    low = str(label).lower()
    return "seller" if any(m in low for m in _SELLER_MARKERS) else "buyer"


def _scope_keep(label: str, scope: str) -> bool:
    return scope == "both" or _party_of_label(label) == scope


_CHAPTER_RE = re.compile(r"^CAPITOLUL\s+\d+[A-Z]?\s+-\s+")


def _renumber_sections(sections: List[Tuple[str, List[Tuple[str, str, str]], str | None]]) -> List[Tuple[str, List[Tuple[str, str, str]], str | None]]:
    out = []
    for idx, (title, rows, subtotal) in enumerate(sections, start=1):
        out.append((_CHAPTER_RE.sub(f"CAPITOLUL {idx} - ", title), rows, subtotal))
    return out


def _scoped_data(data: Dict[str, Any], scope: str, include_broker: bool) -> Dict[str, Any]:
    """Copie superficială a ENGINE_RESULT cu scope-ul de livrare în configurație; sumele NU se ating."""
    out = dict(data)
    cfg = dict(data.get("configuration") or {})
    cfg["offer_for"] = scope
    cfg["include_broker"] = bool(include_broker)
    out["configuration"] = cfg
    return out


def _expected_totals(data: Dict[str, Any], scope: str) -> List[str]:
    """Totalurile care TREBUIE să apară în documentele scope-ului (QA): la both = toate, ca în V3.8."""
    totals = data.get("totals", {}) or {}
    comps = data.get("components", {}) or {}
    buyer_keys = ("buyer_without_optional_notation", "buyer_with_optional_notation")
    seller_keys = ("seller_tax_1", "seller_tax_3", "seller_total", "seller")
    keys = buyer_keys + seller_keys if scope == "both" else (buyer_keys if scope == "buyer" else seller_keys)
    expected: List[str] = []
    for key in keys:
        if totals.get(key) is not None:
            value = num(totals.get(key))
            if value not in expected:
                expected.append(value)
    comp_buyer = ("buyer_total", "buyer_without_notation", "buyer_with_notation")
    comp_seller = ("seller_total",)
    for name, component in comps.items():
        if not isinstance(component, dict):
            continue
        ckeys: Tuple[str, ...]
        if scope == "both":
            ckeys = comp_buyer + comp_seller + ("total",)
        elif scope == "buyer":
            ckeys = comp_buyer + (("total",) if name in ("opinion", "radiere") else ())
        else:
            ckeys = comp_seller
        for key in ckeys:
            if component.get(key) is not None:
                value = num(component.get(key))
                if value not in expected:
                    expected.append(value)
    return expected


def _acts_title(acts: Iterable[str]) -> str:
    acts = list(acts)
    if set(acts) == {"mortgage"}:
        return "Contract de ipotecă / refinanțare"
    names = {
        "opinion": "Opinie notarială",
        "radiere": "Declarație de Radiere",
        "antecontract": "Antecontract",
        "sale": "Contract de vânzare",
        "mortgage": "Contract de ipotecă",
    }
    return " + ".join(names[a] for a in acts if a in names)


def _configuration_rows(data: Dict[str, Any]) -> List[Tuple[str, str]]:
    cfg = data.get("configuration", {})
    fx = cfg.get("fx", {}) or {}
    acts = cfg.get("acts", [])
    standalone_ante = set(acts) == {"antecontract"}
    standalone_opinion = set(acts) in ({"opinion"}, {"radiere"}, {"opinion", "radiere"})
    standalone_mortgage = set(acts) == {"mortgage"}
    buyer_role = "Promitent-cumpărător" if standalone_ante else "Cumpărător"
    seller_role = "Promitent-vânzător" if standalone_ante else "Vânzător"
    if standalone_opinion:
        rows = [
            ("Client", cfg.get("client") or "—"),
            ("Broker / intermediar", cfg.get("broker") or "—"),
            ("Acte", _acts_title(acts)),
            ("Solicitant", "—"),
            ("Monedă", cfg.get("currency") or "—"),
            ("Curs utilizat", f"{fx.get('rate', '—')} lei/{cfg.get('currency', 'RON')}"),
            ("Data publicării cursului", fx.get("publication_date") or "—"),
            ("Data aplicării cursului", fx.get("effective_date") or "—"),
            ("Sursa cursului", _source_label(fx.get("source"))),
        ]
    elif standalone_mortgage:
        rows = [
            ("Client", cfg.get("client") or "—"),
            ("Broker / intermediar", cfg.get("broker") or "—"),
            ("Acte", _acts_title(acts)),
            ("Debitor / constituitor", _person_label(cfg.get("buyer_type"))),
            ("Monedă", cfg.get("currency") or "—"),
            ("Curs utilizat", f"{fx.get('rate', '—')} lei/{cfg.get('currency', 'EUR')}"),
            ("Data publicării cursului", fx.get("publication_date") or "—"),
            ("Data aplicării cursului", fx.get("effective_date") or "—"),
            ("Sursa cursului", _source_label(fx.get("source"))),
        ]
    else:
        rows = [
            ("Client", cfg.get("client") or "—"),
            ("Broker / intermediar", cfg.get("broker") or "—"),
            ("Acte", _acts_title(acts)),
            (buyer_role, _person_label(cfg.get("buyer_type"))),
            (seller_role, _person_label(cfg.get("seller_type"))),
            ("Monedă", cfg.get("currency") or "—"),
            ("Curs utilizat", f"{fx.get('rate', '—')} lei/{cfg.get('currency', 'EUR')}"),
            ("Data publicării cursului", fx.get("publication_date") or "—"),
            ("Data aplicării cursului", fx.get("effective_date") or "—"),
            ("Sursa cursului", _source_label(fx.get("source"))),
        ]
    comps = data.get("components", {})
    if "sale" in comps:
        rows.append(("Valoarea tranzacției", money(comps["sale"].get("price_lei"))))
    if "antecontract" in comps:
        rows.append(("Avans la antecontract", money(comps["antecontract"].get("advance_lei"))))
    if "mortgage" in comps:
        rows.append(("Valoarea creditului", money(comps["mortgage"].get("credit_lei"))))
    # PATCH V4.17 (am.135): oferta individuală — fără rolul celeilalte părți; brokerul dispare NUMAI la comandă
    scope = _offer_scope(data)
    if scope == "buyer":
        rows = [r for r in rows if r[0] != seller_role]
    elif scope == "seller":
        # TIC-T9-01 (implicit până la decizia titularului): valoarea creditului e a cumpărătorului, nu apare pe oferta vânzătorului
        rows = [r for r in rows if r[0] not in (buyer_role, "Debitor / constituitor", "Solicitant", "Valoarea creditului")]
    if not _broker_included(data):
        rows = [r for r in rows if r[0] != "Broker / intermediar"]
    return rows


def _summary_rows(data: Dict[str, Any]) -> List[Tuple[str, str, str, str]]:
    """PATCH V4.17 (am.135): sinteza filtrată pe scope (both = neschimbată)."""
    scope = _offer_scope(data)
    rows = _summary_rows_all(data)
    if scope == "both":
        return rows
    return [r for r in rows if _scope_keep(r[0], scope)]


def _summary_rows_all(data: Dict[str, Any]) -> List[Tuple[str, str, str, str]]:
    cfg = data.get("configuration", {})
    comps = data.get("components", {})
    totals = data.get("totals", {})
    buyer = _person_label(cfg.get("buyer_type"))
    seller = _person_label(cfg.get("seller_type"))
    has_ante = "antecontract" in comps
    standalone_ante = has_ante and "sale" not in comps and "mortgage" not in comps and "opinion" not in comps and "radiere" not in comps
    standalone_opinion = (("opinion" in comps or "radiere" in comps) and all(a in ("opinion", "radiere") for a in comps))
    standalone_mortgage = "mortgage" in comps and len(comps) == 1
    other_act_notation_present = any(
        str((comps.get(act) or {}).get("land_book_notation", "0")) not in ("0", "0.00", "None")
        for act in ("opinion", "radiere", "sale", "mortgage")
    )
    rows: List[Tuple[str, str, str, str]] = []

    if "opinion" in comps:
        rows.append(("Opinie notarială", "tarif standard", "Solicitant", money(comps["opinion"].get("total"))))
    if "radiere" in comps:
        rows.append(("Declarație de Radiere", "tarif standard", "Solicitant", money(comps["radiere"].get("total"))))
    if has_ante:
        a = comps["antecontract"]
        ante_buyer_label = "Antecontract - promitent-cumpărător" if standalone_ante else "Antecontract - cumpărător"
        rows.append((ante_buyer_label, money(a.get("advance_lei")), buyer, money(a.get("buyer_without_notation"))))
        rows.append(("Taxă opțională de notare", _qty_mode(a.get("notation_quantity", 1), "notări", a.get("notation_unit", 75), default_quantity=1, default_text="1 notare opțională"), buyer, money(a.get("optional_notation"))))
    if "sale" in comps:
        s = comps["sale"]
        rows.append(("Contract de vânzare - cumpărător", money(s.get("price_lei")), buyer, money(s.get("buyer_total"))))
    if "mortgage" in comps:
        m = comps["mortgage"]
        if standalone_mortgage:
            rows.append(("Contract de ipotecă / refinanțare - debitor / constituitor", money(m.get("credit_lei")), buyer, money(m.get("buyer_total"))))
        else:
            rows.append(("Contract de ipotecă - cumpărător", money(m.get("credit_lei")), buyer, money(m.get("buyer_total"))))

    if has_ante:
        if totals.get("buyer_without_optional_notation") is not None:
            total_label = "TOTAL PROMITENT-CUMPĂRĂTOR - FĂRĂ NOTARE" if standalone_ante else ("TOTAL CUMPĂRĂTOR - FĂRĂ NOTAREA P-V" if other_act_notation_present else "TOTAL CUMPĂRĂTOR - FĂRĂ NOTARE")
            rows.append((total_label, "—", buyer, money(totals.get("buyer_without_optional_notation"))))
        if totals.get("buyer_with_optional_notation") is not None:
            total_label = "TOTAL PROMITENT-CUMPĂRĂTOR - CU NOTARE" if standalone_ante else ("TOTAL CUMPĂRĂTOR - CU NOTAREA P-V" if other_act_notation_present else "TOTAL CUMPĂRĂTOR - CU NOTARE")
            rows.append((total_label, "—", buyer, money(totals.get("buyer_with_optional_notation"))))
    else:
        buyer_total = totals.get("buyer_without_optional_notation")
        if buyer_total is None:
            buyer_total = totals.get("buyer_with_optional_notation")
        if buyer_total is not None:
            if standalone_opinion:
                rows.append(("TOTAL SOLICITANT", "—", "Solicitant", money(buyer_total)))
            elif standalone_mortgage:
                rows.append(("TOTAL DEBITOR / CONSTITUITOR", "—", buyer, money(buyer_total)))
            else:
                rows.append(("TOTAL CUMPĂRĂTOR", "—", buyer, money(buyer_total)))

    # PATCH V4.16 (am.133): serviciile universale (orice act) — randuri proprii in sinteza, inaintea totalurilor vanzatorului
    for _sv in (data.get("services") or []):
        rows.append((str(_sv.get("label")), _qty_mode(_sv.get("quantity"), str(_sv.get("unit_label")), _sv.get("unit_amount")), ("Solicitant" if standalone_opinion else buyer), money(_sv.get("amount"))))
    # PATCH V4.20 (am.169): serviciile/taxele in sarcina vanzatorului — randuri proprii, cu «vânzător» in eticheta (clasificare am.135)
    for _sv in (data.get("services_seller") or []):
        rows.append((str(_sv.get("label")), _qty_mode(_sv.get("quantity"), str(_sv.get("unit_label")), _sv.get("unit_amount")), seller, money(_sv.get("amount"))))
    for _af in (comps.get("additional_fees") or []):
        if str(_af.get("party") or "buyer") == "seller":
            rows.append((f"{_af.get('label')} (vânzător)", _qty_mode(_af.get("quantity"), "unități", _af.get("unit_amount")), seller, money(_af.get("amount"))))
    if "radiere" in comps and str(comps["radiere"].get("party") or "buyer") == "seller":
        rows.append(("Declarație de radiere - vânzător", "în sarcina vânzătorului", seller, money(comps["radiere"].get("total"))))
    if has_ante:
        a = comps["antecontract"]
        seller_label = "TOTAL PROMITENT-VÂNZĂTOR" if standalone_ante else "Antecontract - vânzător"
        rows.append((seller_label, "extras + verificare", seller, money(a.get("seller_total"))))

    if totals.get("seller_tax_1") is not None:
        rows.append(("TOTAL VÂNZĂTOR - IMPOZIT 1%", "alternativ", seller, money(totals.get("seller_tax_1"))))
    if totals.get("seller_tax_3") is not None:
        rows.append(("TOTAL VÂNZĂTOR - IMPOZIT 3%", "alternativ", seller, money(totals.get("seller_tax_3"))))
    global_seller_total = totals.get("seller_total")
    if global_seller_total is None:
        global_seller_total = totals.get("seller")
    if global_seller_total is not None and not standalone_ante:
        rows.append(("TOTAL VÂNZĂTOR", "—", seller, money(global_seller_total)))
    elif not has_ante and "sale" in comps:
        sale_seller_total = (comps["sale"].get("seller") or {}).get("total")
        if sale_seller_total is not None:
            rows.append(("TOTAL VÂNZĂTOR", "—", seller, money(sale_seller_total)))
    return rows

def _qty_mode(quantity: Any, unit_label: str, unit_price: Any, *, default_quantity: int | None = None, default_text: str | None = None) -> str:
    try:
        qty = int(quantity)
    except (TypeError, ValueError):
        qty = default_quantity if default_quantity is not None else 1
    if default_text is not None and default_quantity is not None and qty == default_quantity:
        return default_text
    return f"{qty} {unit_label} x {money(unit_price)}"


# PATCH V4.27 (am.374, T56j, titular 09.09.2026 — «Taxa ancpi de 3x 75 lei e pe 2 randuri»):
# taxa fixa a procedurii (`ancpi_radiere_fixed`, 75,00, cantitate 1) si radierile cerute de operator
# (`land_book_notation` = `notation_unit` x `notation_qty`) poarta ACELASI tarif, deci ies pe UN rand.
# Fail-open pe forma neasteptata (tiparul am.370): tarif diferit, cantitate 0 sau suma care nu se
# reface din unitate x cantitate -> raman cele doua randuri de dinainte, ca sa nu minta despre tarif.
def _ancpi_radiere_randuri_am374(rz: Dict[str, Any]) -> List[Tuple[str, str, Any]]:
    fix = rz.get("ancpi_radiere_fixed")
    notat = rz.get("land_book_notation")
    unit = rz.get("notation_unit", 75)
    try:
        qty = int(float(str(rz.get("notation_quantity", 0) or 0)))
    except Exception:
        qty = 0
    rand_fix = ("Taxă ANCPI de radiere", "tarif fix, fără TVA", fix)
    rand_notare = ("Taxă de radiere din cartea funciară",
                   _qty_mode(qty, "radieri" if qty != 1 else "radiere", unit), notat)
    if qty <= 0 or notat is None or str(notat) in ("0", "0.00", "None"):
        return [rand_fix]
    try:
        u = _D(str(unit)); f = _D(str(fix or 0)); n = _D(str(notat))
    except Exception:
        return [rand_fix, rand_notare]
    if u != f or n != u * qty:
        return [rand_fix, rand_notare]
    return [("Taxă ANCPI de radiere", f"{qty + 1} × {money(u)}, fără TVA", f + n)]


# PATCH V4.27 (am.374, T56j — «Emailul incepe cu „Pentru autentificarea contractului"»):
# fraza de deschidere se compune din forma la genitiv tinuta in 04_M1_C01_RULES (B-4).
_FORME_ACTE_AM374: Dict[str, Any] | None = None


def _forme_acte_am374() -> Dict[str, Any]:
    global _FORME_ACTE_AM374
    if _FORME_ACTE_AM374 is None:
        _FORME_ACTE_AM374 = {}
        try:
            for _p in sorted(Path(__file__).resolve().parent.glob("04_M1_C01_RULES_V*.json")):
                _d = json.loads(_p.read_text(encoding="utf-8"))
                if isinstance(_d.get("acte_forme_am374"), dict):
                    _FORME_ACTE_AM374 = _d["acte_forme_am374"]
                    break
        except Exception:
            _FORME_ACTE_AM374 = {}
    return _FORME_ACTE_AM374


def _fraza_deschidere_am374(acts: Any) -> str:
    forme = _forme_acte_am374()
    neutru = str(forme.get("_multi") or "Pentru autentificarea actelor solicitate, costurile principale estimate sunt următoarele:")
    lista = [a for a in (acts or [])]
    if len(lista) != 1:
        return neutru
    intrare = forme.get(lista[0])
    if not isinstance(intrare, dict):
        return neutru
    if intrare.get("fraza"):
        return str(intrare["fraza"])
    gen = intrare.get("genitiv")
    if not gen:
        return neutru
    sablon = str(forme.get("_sablon") or "Pentru autentificarea {genitiv}, costurile principale estimate sunt următoarele:")
    return sablon.replace("{genitiv}", str(gen))


def _detail_sections(data: Dict[str, Any]) -> List[Tuple[str, List[Tuple[str, str, str]], str | None]]:
    """PATCH V4.17 (am.135): capitolele filtrate pe scope și renumerotate 1..n (both = neschimbate)."""
    scope = _offer_scope(data)
    sections = _detail_sections_all(data)
    if scope == "both":
        return sections
    return _renumber_sections([sec for sec in sections if _scope_keep(sec[0], scope)])


def _detail_sections_all(data: Dict[str, Any]) -> List[Tuple[str, List[Tuple[str, str, str]], str | None]]:
    cfg = data.get("configuration", {})
    comps = data.get("components", {})
    totals = data.get("totals", {})
    buyer_type = cfg.get("buyer_type")
    seller_type = cfg.get("seller_type")
    buyer_check = "Verificare regim matrimonial" if buyer_type == "PF" else "RECOM"
    seller_check = "Verificare regim matrimonial" if seller_type == "PF" else "RECOM"
    has_ante = "antecontract" in comps
    has_mortgage = "mortgage" in comps
    standalone_ante = has_ante and "sale" not in comps and not has_mortgage and "opinion" not in comps and "radiere" not in comps
    standalone_opinion = (("opinion" in comps or "radiere" in comps) and all(a in ("opinion", "radiere") for a in comps))
    standalone_mortgage = "mortgage" in comps and len(comps) == 1
    other_act_notation_present = any(
        str((comps.get(act) or {}).get("land_book_notation", "0")) not in ("0", "0.00", "None")
        for act in ("opinion", "radiere", "sale", "mortgage")
    )
    sections: List[Tuple[str, List[Tuple[str, str, str]], str | None]] = []

    if "radiere" in comps:
        rz = comps["radiere"]
        sections.append(("CAPITOLUL 1 - DECLARAȚIE DE RADIERE" if "opinion" not in comps else "CAPITOLUL 2 - DECLARAȚIE DE RADIERE", [
            ("Onorariu", "tarif standard", money(rz.get("honorarium_net"))),
            ("TVA 21%", "aplicată onorariului", money(rz.get("vat"))),
            ("Extras de informare", _qty_mode(rz.get("information_extract_quantity", 1), "extrase", rz.get("information_extract_unit", 20), default_quantity=1, default_text="1 extras, fără TVA"), money(rz.get("information_extract"))),
            # PATCH V4.27 (am.374): perechea ANCPI, un rand cand tariful e acelasi (am.110 pastrat in fallback)
            *[(_l, _n, money(_v)) for _l, _n, _v in _ancpi_radiere_randuri_am374(rz)],
        ], money(rz.get("total"))))

    if "opinion" in comps:
        o = comps["opinion"]
        sections.append(("CAPITOLUL 1 - OPINIE NOTARIALĂ", [
            ("Onorariu", "tarif standard", money(o.get("honorarium_net"))),
            ("TVA 21%", "aplicată onorariului", money(o.get("vat"))),
            ("Extras de informare", _qty_mode(o.get("information_extract_quantity", 1), "extrase", o.get("information_extract_unit", 20), default_quantity=1, default_text="1 extras, fără TVA"), money(o.get("information_extract"))),
            *(([("Taxă de notare în cartea funciară", _qty_mode(o.get("notation_quantity", 0), "notări", o.get("notation_unit", 75)), money(o.get("land_book_notation")))]) if str(o.get("land_book_notation", "0")) not in ("0", "0.00") else []),
        ], money(o.get("total"))))

    if has_ante:
        a = comps["antecontract"]
        ante_buyer_title = "CAPITOLUL 1 - COSTURI PROMITENT-CUMPĂRĂTOR" if standalone_ante else "CAPITOLUL 2 - COSTURI PROMITENT-CUMPĂRĂTOR"
        sections.append((ante_buyer_title, [
            ("Onorariu", "1% din suma achitată, minimum operațional 500 lei", money(a.get("honorarium_net"))),
            ("Arhivare", "sumă fixă, fără TVA", money(a.get("archive"))),
            ("TVA 21%", "la onorariu și arhivare", money(a.get("vat"))),
            (buyer_check, _qty_mode(a.get("buyer_verification_quantity", 1), "verificări", a.get("buyer_verification_unit"), default_quantity=1, default_text="verificare aplicată direct tipului persoanei"), money(a.get("buyer_verification"))),
            ("TOTAL FĂRĂ NOTARE", "", money(a.get("buyer_without_notation"))),
            ("Taxă opțională de notare", _qty_mode(a.get("notation_quantity", 1), "notări", a.get("notation_unit", 75), default_quantity=1, default_text="1 notare opțională, fără TVA"), money(a.get("optional_notation"))),
            ("TOTAL CU NOTARE", "", money(a.get("buyer_with_notation"))),
        ], None))

    if "sale" in comps:
        s = comps["sale"]
        if has_ante:
            rows = [
                ("Onorariu integral", "potrivit tranșei aplicabile valorii în lei", money(s.get("gross_honorarium_before_deduction"))),
                ("Deducere onorariu antecontract", "deducere din onorariul net al vânzării", money(s.get("antecontract_honorarium_deduction"))),
                ("Onorariu aplicat", "onorariu net aplicat speței", money(s.get("honorarium_net"))),
            ]
        elif str(s.get("antecontract_deduction_source") or "") == "operator_extern":  # PATCH V4.20 (am.169, R-PROMISIUNE-EXTERNA)
            rows = [
                ("Onorariu integral", "potrivit tranșei aplicabile valorii în lei", money(s.get("gross_honorarium_before_deduction"))),
                ("Deducere onorariu antecontract achitat anterior", "declarat de operator, în afara calculului; deducere din onorariul net al vânzării", money(s.get("antecontract_honorarium_deduction"))),
                ("Onorariu aplicat", "onorariu net aplicat speței", money(s.get("honorarium_net"))),
            ]
        else:
            rows = [("Onorariu", "potrivit tranșei aplicabile valorii în lei", money(s.get("honorarium_net")))]
        rows.extend([
            ("Arhivare", "sumă fixă, fără TVA", money(s.get("archive"))),
            ("TVA 21%", "la onorariu și arhivare", money(s.get("vat"))),
            ("Taxă ANCPI", "0,15% PF / 0,5% PJ din preț", money(s.get("ancpi"))),
        ])
        if str(s.get("land_book_notation", "0")) not in ("0", "0.00"):
            rows.append(("Taxă de notare în cartea funciară", _qty_mode(s.get("notation_quantity", 0), "notări", s.get("notation_unit", 75)), money(s.get("land_book_notation"))))
        if str(s.get("buyer_verification", "0")) not in ("0", "0.00"):
            verification_mode = "verificare comună actelor finale" if has_mortgage else "verificare aferentă vânzării"
            rows.append((buyer_check, _qty_mode(s.get("buyer_verification_quantity", 1), "verificări", s.get("buyer_verification_unit"), default_quantity=1, default_text=verification_mode), money(s.get("buyer_verification"))))
        sections.append(("CAPITOLUL 3 - COSTURI CUMPĂRĂTOR - CONTRACT DE VÂNZARE", rows, money(s.get("buyer_total"))))

    if has_mortgage:
        m = comps["mortgage"]
        additional_collateral_qty = int(m.get("additional_collateral_property_quantity", 0) or 0)
        if additional_collateral_qty:
            collateral_label = "imobil suplimentar" if additional_collateral_qty == 1 else "imobile suplimentare"
            ocpi_mode = (
                f"100 lei + 0,1% din valoarea creditului + "
                f"{additional_collateral_qty} {collateral_label} x 100 lei"
            )
        else:
            ocpi_mode = "100 lei + 0,1% din valoarea creditului"
        rows = [
            ("Onorariu", "potrivit tranșei aplicabile valorii creditului", money(m.get("honorarium_net"))),
            ("Arhivare", "sumă fixă, fără TVA", money(m.get("archive"))),
            ("TVA 21%", "la onorariu și arhivare", money(m.get("vat"))),
            ("Taxă OCPI", ocpi_mode, money(m.get("ocpi"))),
            *(([("Taxă de notare în cartea funciară", f"{int(m.get('notation_quantity', 0) or 0)} {'notare' if int(m.get('notation_quantity', 0) or 0) == 1 else 'notări'} x {money(m.get('notation_unit', 75))}", money(m.get("land_book_notation")))]) if str(m.get("land_book_notation", "0")) not in ("0", "0.00") else []),
            ("Verificări procuri bancare", _qty_mode(m.get("bank_proxy_check_quantity", 2), "verificări", m.get("bank_proxy_check_unit", 18.15), default_quantity=2, default_text="2 procuri x verificare"), money(m.get("bank_proxy_checks"))),
            ("Legalizare procură bancară / copii", _qty_mode(m.get("legalized_copy_quantity", 6), "copii/pagini", m.get("legalized_copy_unit", 6.05), default_quantity=6, default_text="estimativ 6 pagini"), money(m.get("bank_proxy_legalization"))),
        ]
        if str(m.get("buyer_verification", "0")) not in ("0", "0.00"):
            rows.append((buyer_check, _qty_mode(m.get("buyer_verification_quantity", 1), "verificări", m.get("buyer_verification_unit"), default_quantity=1, default_text="verificare aplicabilă"), money(m.get("buyer_verification"))))
        if str(m.get("authentication_extract", "0")) not in ("0", "0.00"):
            rows.append(("Extras de autentificare", _qty_mode(m.get("authentication_extract_quantity", 1), "extrase", m.get("authentication_extract_unit", 40), default_quantity=1, default_text="act autonom"), money(m.get("authentication_extract"))))
        mortgage_title = (
            "CAPITOLUL 1 - COSTURI DEBITOR / CONSTITUITOR - CONTRACT DE IPOTECĂ / REFINANȚARE"
            if standalone_mortgage else
            "CAPITOLUL 4 - COSTURI CUMPĂRĂTOR - CONTRACT DE IPOTECĂ"
        )
        sections.append((mortgage_title, rows, money(m.get("buyer_total"))))

    buyer_total_rows: List[Tuple[str, str, str]] = []
    if "opinion" in comps:
        buyer_total_rows.append(("Subtotal opinie notarială", "", money(comps["opinion"].get("total"))))
    if "radiere" in comps:
        buyer_total_rows.append(("Subtotal Declarație de Radiere", "", money(comps["radiere"].get("total"))))
    if has_ante:
        buyer_total_rows.append(("Subtotal antecontract - fără notare", "", money(comps["antecontract"].get("buyer_without_notation"))))
        buyer_total_rows.append(("Taxă opțională de notare", "", money(comps["antecontract"].get("optional_notation"))))
    if "sale" in comps:
        buyer_total_rows.append(("Subtotal contract de vânzare", "", money(comps["sale"].get("buyer_total"))))
    if has_mortgage:
        mortgage_subtotal_label = "Subtotal contract de ipotecă / refinanțare" if standalone_mortgage else "Subtotal contract de ipotecă"
        buyer_total_rows.append((mortgage_subtotal_label, "", money(comps["mortgage"].get("buyer_total"))))
    if has_ante:
        if totals.get("buyer_without_optional_notation") is not None:
            label = "TOTAL GENERAL PROMITENT-CUMPĂRĂTOR - FĂRĂ NOTARE" if standalone_ante else ("TOTAL GENERAL CUMPĂRĂTOR - FĂRĂ NOTAREA P-V" if other_act_notation_present else "TOTAL GENERAL CUMPĂRĂTOR - FĂRĂ NOTARE")
            buyer_total_rows.append((label, "", money(totals.get("buyer_without_optional_notation"))))
        if totals.get("buyer_with_optional_notation") is not None:
            label = "TOTAL GENERAL PROMITENT-CUMPĂRĂTOR - CU NOTARE" if standalone_ante else ("TOTAL GENERAL CUMPĂRĂTOR - CU NOTAREA P-V" if other_act_notation_present else "TOTAL GENERAL CUMPĂRĂTOR - CU NOTARE")
            buyer_total_rows.append((label, "", money(totals.get("buyer_with_optional_notation"))))
    else:
        buyer_total = totals.get("buyer_without_optional_notation")
        if buyer_total is None:
            buyer_total = totals.get("buyer_with_optional_notation")
        if buyer_total is not None:
            if standalone_opinion:
                total_label = "TOTAL GENERAL SOLICITANT"
            elif standalone_mortgage:
                total_label = "TOTAL GENERAL DEBITOR / CONSTITUITOR"
            else:
                total_label = "TOTAL GENERAL CUMPĂRĂTOR"
            buyer_total_rows.append((total_label, "", money(buyer_total)))
    if buyer_total_rows:
        if standalone_ante:
            buyer_total_title = "CAPITOLUL 2 - TOTAL GENERAL PROMITENT-CUMPĂRĂTOR"
        elif standalone_opinion:
            buyer_total_title = "CAPITOLUL 2 - TOTAL GENERAL SOLICITANT"
        elif standalone_mortgage:
            buyer_total_title = "CAPITOLUL 2 - TOTAL GENERAL DEBITOR / CONSTITUITOR"
        else:
            buyer_total_title = "CAPITOLUL 5 - TOTAL GENERAL CUMPĂRĂTOR"
        sections.append((buyer_total_title, buyer_total_rows, None))

    if has_ante:
        a = comps["antecontract"]
        ante_seller_title = "CAPITOLUL 3 - COSTURI PROMITENT-VÂNZĂTOR" if standalone_ante else "CAPITOLUL 6A - COSTURI PROMITENT-VÂNZĂTOR"
        sections.append((ante_seller_title, [
            ("Extras de informare", _qty_mode(a.get("seller_information_extract_quantity", 1), "extrase", a.get("seller_information_extract_unit", 20), default_quantity=1, default_text="1 extras, fără TVA"), money(a.get("seller_information_extract"))),
            (seller_check, _qty_mode(a.get("seller_verification_quantity", 1), "verificări", a.get("seller_verification_unit"), default_quantity=1, default_text="verificare aplicată direct tipului persoanei"), money(a.get("seller_verification"))),
        ], money(a.get("seller_total"))))

    if "sale" in comps:
        seller = comps["sale"].get("seller", {})
        rows: List[Tuple[str, str, str]] = []
        if seller.get("tax_1") is not None:
            rows.append(("Impozit - varianta 1%", "alternativă", money(seller.get("tax_1"))))
        if seller.get("tax_3") is not None:
            rows.append(("Impozit - varianta 3%", "alternativă", money(seller.get("tax_3"))))
        if seller.get("tax") is not None and seller.get("tax_shares"):
            rows.append((f"Impozit MIXT pe cote - {seller.get('tax_percent_label')}", "impozit pe cote (am.282)", money(seller.get("tax"))))  # am.282 (V3.11)
        elif seller.get("tax") is not None:
            rows.append((f"Impozit - {seller.get('tax_percent')}%", "cotă aplicabilă speței", money(seller.get("tax"))))
        default_extract_mode = "un singur extras pentru vânzare + ipotecă" if has_mortgage else "1 extras de autentificare aferent vânzării"
        extract_mode = _qty_mode(seller.get("authentication_extract_quantity", 1), "extrase", seller.get("authentication_extract_unit", 40), default_quantity=1, default_text=default_extract_mode)
        default_verification_mode = "verificare pentru actele finale" if has_mortgage else "verificare aferentă vânzării"
        verification_mode = _qty_mode(seller.get("seller_verification_quantity", 1), "verificări", seller.get("seller_verification_unit"), default_quantity=1, default_text=default_verification_mode)
        rows.extend([
            ("Extras de autentificare", extract_mode, money(seller.get("authentication_extract"))),
            (seller_check, verification_mode, money(seller.get("seller_verification"))),
        ])
        if seller.get("total") is not None:
            rows.append(("TOTAL VÂNZĂTOR", "", money(seller.get("total"))))
        if seller.get("total_1") is not None:
            rows.append(("Subtotal vânzător - varianta 1%", "", money(seller.get("total_1"))))
        if seller.get("total_3") is not None:
            rows.append(("Subtotal vânzător - varianta 3%", "", money(seller.get("total_3"))))
        if totals.get("seller_tax_1") is not None:
            rows.append(("TOTAL GENERAL VÂNZĂTOR - IMPOZIT 1%", "", money(totals.get("seller_tax_1"))))
        if totals.get("seller_tax_3") is not None:
            rows.append(("TOTAL GENERAL VÂNZĂTOR - IMPOZIT 3%", "", money(totals.get("seller_tax_3"))))
        if totals.get("seller_extra_total") is not None:  # PATCH V4.20 (am.169)
            rows.append(("Servicii și taxe în sarcina vânzătorului", "vezi capitolul dedicat", money(totals.get("seller_extra_total"))))
        global_seller_total = totals.get("seller_total")
        if global_seller_total is None:
            global_seller_total = totals.get("seller")
        sale_final_total = seller.get("total")
        if global_seller_total is not None and (has_ante or str(global_seller_total) != str(sale_final_total)):
            rows.append(("TOTAL GENERAL VÂNZĂTOR", "", money(global_seller_total)))
        section_title = "CAPITOLUL 6B - COSTURI VÂNZĂTOR - ACTE FINALE" if has_mortgage else "CAPITOLUL 6 - COSTURI VÂNZĂTOR - CONTRACT DE VÂNZARE"
        sections.append((section_title, rows, None))

    # PATCH V4.16 (am.133): SERVICII SUPLIMENTARE — compunibile pe orice act (tarife pinuite, cantitati explicite)
    _svs = data.get("services") or []
    _afs_b = [a for a in (comps.get("additional_fees") or []) if str(a.get("party") or "buyer") != "seller"]
    if _svs or _afs_b:
        _rows = [(str(s.get("label")), _qty_mode(s.get("quantity"), str(s.get("unit_label")), s.get("unit_amount")) + (f", {s.get('note')}" if s.get("note") else ""), money(s.get("amount"))) for s in _svs]
        # PATCH V4.20 (am.169, sanitizare): taxele suplimentare declarate de operator (V4.3) intrau in total, dar nu erau randate
        _rows += [(str(a.get("label")), _qty_mode(a.get("quantity"), "unități", a.get("unit_amount")) + ", declarată de operator", money(a.get("amount"))) for a in _afs_b]
        _sub = _D(str(totals.get("services_total") or "0")) + _D(str(totals.get("additional_fees_total") or "0"))
        sections.append((f"CAPITOLUL {len(sections) + 1} - SERVICII SUPLIMENTARE (aplicabile oricărui act)", _rows, money(_sub)))
    # PATCH V4.20 (am.169, R-SERVICII-PE-VANZATOR): capitol propriu pentru tot ce cade pe vanzator in afara actelor
    _svs_s = data.get("services_seller") or []
    _afs_s = [a for a in (comps.get("additional_fees") or []) if str(a.get("party") or "buyer") == "seller"]
    _rad_s = comps.get("radiere") if ("radiere" in comps and str(comps["radiere"].get("party") or "buyer") == "seller") else None
    if _svs_s or _afs_s or _rad_s:
        _rows = [(str(s.get("label")), _qty_mode(s.get("quantity"), str(s.get("unit_label")), s.get("unit_amount")) + (f", {s.get('note')}" if s.get("note") else ""), money(s.get("amount"))) for s in _svs_s]
        _rows += [(f"{a.get('label')} (vânzător)", _qty_mode(a.get("quantity"), "unități", a.get("unit_amount")) + ", declarată de operator", money(a.get("amount"))) for a in _afs_s]
        if _rad_s:
            _rows.append(("Declarație de radiere (vânzător)", "onorariu + TVA + extras + taxa ANCPI de radiere, în sarcina vânzătorului", money(_rad_s.get("total"))))
        sections.append((f"CAPITOLUL {len(sections) + 1} - COSTURI VÂNZĂTOR - SERVICII ȘI TAXE ÎN SARCINA VÂNZĂTORULUI", _rows, money(totals.get("seller_extra_total"))))
    return sections


def _observations_text(data: Dict[str, Any]) -> str:
    comps = data.get("components", {})
    sale_seller = (comps.get("sale") or {}).get("seller", {}) or {}
    parts = ["Valorile sunt calculate pe baza datelor furnizate și a cursului indicat."]
    if "antecontract" in comps:
        parts.append("Notarea aferentă P-V este prezentată ca opțiune.")
        if "sale" not in comps and "mortgage" not in comps:
            parts.append("Onorariul net al antecontractului se deduce ulterior din onorariul net al contractului de vânzare, dacă acesta se încheie.")
    if sale_seller.get("tax_1") is not None and sale_seller.get("tax_3") is not None:
        parts.append("Variantele de impozit de 1% și 3% sunt alternative și nu se cumulează.")
    # PATCH V4.17 (am.135): observațiile părții — notarea/deducerea privesc cumpărătorul, impozitul privește vânzătorul
    scope = _offer_scope(data)
    if scope == "buyer":
        parts = [x for x in parts if not x.startswith("Variantele de impozit")]
    elif scope == "seller":
        parts = [x for x in parts if not (x.startswith("Notarea aferentă") or x.startswith("Onorariul net al antecontractului"))]
    return " ".join(parts)

def _full_layout_model(data: Dict[str, Any]) -> Dict[str, Any]:
    """am.368: modelul de layout al ofertei COMPLETE — aceleasi surse de continut ca V3.12 (bit-identic fara `model`)."""
    return {"title": "OFERTĂ DE PREȚ", "subtitle": _acts_title(data.get("configuration", {}).get("acts", [])),
            "cfg_rows": _configuration_rows(data), "summary": _summary_rows(data), "sections": _detail_sections(data),
            "closing": [("Observații: ", _observations_text(data))], "closing_size": 7.0}


def _docx_generator(data: Dict[str, Any], output_path: Path, logo_path: Path, compact: float = 1.0,
                    model: Dict[str, Any] | None = None) -> None:
    """`compact` (am.135, numai pe oferta individuală): scalează exclusiv spațierea verticală a paragrafelor și
    interlinia din celule, oglindind compactarea PDF-ului; textul, fonturile și lățimile rămân neschimbate.
    La compact == 1.0 documentul este bit-identic cu V3.8.
    `model` (am.368): modelul de layout; None = oferta completa (`_full_layout_model`), altfel setul scurt."""
    model = model or _full_layout_model(data)
    from docx import Document
    from docx.enum.section import WD_SECTION
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Inches, Pt, RGBColor

    _c = float(compact) if compact and 0.5 < float(compact) < 1.0 else 1.0

    def _VPt(value: float):
        return Pt(value * _c)

    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Cm(21)
    sec.page_height = Cm(29.7)
    sec.top_margin = Cm(1.15)
    sec.bottom_margin = Cm(1.3)
    sec.left_margin = Cm(1.4)
    sec.right_margin = Cm(1.4)
    sec.different_first_page_header_footer = True

    styles = doc.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(8.2)
    styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")

    def shade(cell, fill: str):
        tc_pr = cell._tc.get_or_add_tcPr()
        shd = tc_pr.find(qn("w:shd"))
        if shd is None:
            shd = OxmlElement("w:shd")
            tc_pr.append(shd)
        shd.set(qn("w:fill"), fill)

    def set_cell_text(cell, text, bold=False, color=DARK, size=8.0, align=None):
        cell.text = ""
        p = cell.paragraphs[0]
        if align is not None:
            p.alignment = align
        p.paragraph_format.space_after = _VPt(0)
        p.paragraph_format.space_before = _VPt(0)
        if _c < 1.0:
            p.paragraph_format.line_spacing = max(0.86, _c)
        r = p.add_run(str(text))
        r.bold = bold
        r.font.name = "Arial"
        r.font.size = Pt(size)
        r.font.color.rgb = RGBColor.from_string(color)

    def set_repeat_table_header(row):
        tr_pr = row._tr.get_or_add_trPr()
        tbl_header = OxmlElement("w:tblHeader")
        tbl_header.set(qn("w:val"), "true")
        tr_pr.append(tbl_header)

    def prevent_row_split(row):
        tr_pr = row._tr.get_or_add_trPr()
        cant = OxmlElement("w:cantSplit")
        tr_pr.append(cant)

    def add_page_field(paragraph):
        run = paragraph.add_run()
        fld_char1 = OxmlElement("w:fldChar")
        fld_char1.set(qn("w:fldCharType"), "begin")
        instr_text = OxmlElement("w:instrText")
        instr_text.set(qn("xml:space"), "preserve")
        instr_text.text = "PAGE"
        fld_char2 = OxmlElement("w:fldChar")
        fld_char2.set(qn("w:fldCharType"), "end")
        run._r.extend([fld_char1, instr_text, fld_char2])

    # compact logo in default header (pages 2+)
    header = sec.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    hp.add_run().add_picture(str(logo_path), width=Inches(0.78))
    hp.paragraph_format.space_after = _VPt(1)

    # footer for first and subsequent pages
    for footer in (sec.footer, sec.first_page_footer):
        table = footer.add_table(rows=1, cols=3, width=Inches(7.2))
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        widths = [3.0, 1.2, 3.0]
        for i, w in enumerate(widths):
            table.columns[i].width = Inches(w)
        set_cell_text(table.cell(0, 0), CONTACT, size=7.2)
        set_cell_text(table.cell(0, 1), "Pagina ", bold=True, color=WHITE, size=7.2, align=WD_ALIGN_PARAGRAPH.CENTER)
        shade(table.cell(0, 1), NAVY)
        add_page_field(table.cell(0, 1).paragraphs[0])
        set_cell_text(table.cell(0, 2), OFFICE, size=6.8, align=WD_ALIGN_PARAGRAPH.RIGHT)

    # page border
    sect_pr = sec._sectPr
    pg_borders = OxmlElement("w:pgBorders")
    pg_borders.set(qn("w:offsetFrom"), "page")
    for edge in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "6")
        el.set(qn("w:space"), "18")
        el.set(qn("w:color"), "D6D9DD")
        pg_borders.append(el)
    sect_pr.append(pg_borders)

    # first page office header
    t = doc.add_table(rows=1, cols=2)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    t.columns[0].width = Cm(3.5)
    t.columns[1].width = Cm(14.0)
    c0, c1 = t.rows[0].cells
    p = c0.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(logo_path), width=Cm(2.7))
    set_cell_text(c1, "", size=7.5)
    p = c1.paragraphs[0]
    p.paragraph_format.space_after = _VPt(0)
    for idx, txt in enumerate([OFFICE, ADDRESS, ACCOUNT, CIF, LICENSE]):
        r = p.add_run(txt + ("\n" if idx < 4 else ""))
        r.bold = idx == 0
        r.font.name = "Arial"
        r.font.size = Pt(8.3 if idx == 0 else 7.3)
        r.font.color.rgb = RGBColor.from_string(NAVY)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_before = _VPt(5)
    title.paragraph_format.space_after = _VPt(2)
    r = title.add_run(model["title"])
    r.bold = True
    r.font.name = "Times New Roman"
    r.font.size = Pt(17)
    r.font.color.rgb = RGBColor.from_string(NAVY)
    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.paragraph_format.space_after = _VPt(5)
    rr = sub.add_run(model["subtitle"])
    rr.bold = True
    rr.font.size = Pt(9)
    rr.font.color.rgb = RGBColor.from_string("B28B45")

    # configuration table
    cfg_rows = model["cfg_rows"]
    cfg_table = doc.add_table(rows=0, cols=4)
    cfg_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cfg_table.autofit = False
    widths = [Cm(3.4), Cm(5.4), Cm(3.4), Cm(5.4)]
    for col, w in zip(cfg_table.columns, widths):
        col.width = w
    for i in range(0, len(cfg_rows), 2):
        row = cfg_table.add_row()
        prevent_row_split(row)
        pairs = cfg_rows[i:i+2]
        while len(pairs) < 2:
            pairs.append(("", ""))
        for j, (label, val) in enumerate(pairs):
            set_cell_text(row.cells[j*2], label, bold=True, color=NAVY, size=7.2)
            shade(row.cells[j*2], MID_GREY)
            set_cell_text(row.cells[j*2+1], val, size=7.2)
            row.cells[j*2].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            row.cells[j*2+1].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

    doc.add_paragraph().paragraph_format.space_after = _VPt(1)
    if model.get("summary") is not None:  # am.368: setul scurt nu are sinteza
      h = doc.add_paragraph()
      h.paragraph_format.space_after = _VPt(1)
      run = h.add_run("REZUMAT EXECUTIV AL COSTURILOR")
      run.bold = True
      run.font.size = Pt(9)
      run.font.color.rgb = RGBColor.from_string(NAVY)

      summary = doc.add_table(rows=1, cols=4)
      summary.alignment = WD_TABLE_ALIGNMENT.CENTER
      summary.autofit = False
      headers = ["Capitol / act", "Bază / explicație", "Parte", "Subtotal / total"]
      for i, txt in enumerate(headers):
        set_cell_text(summary.cell(0, i), txt, bold=True, color=WHITE, size=7.2)
        shade(summary.cell(0, i), NAVY)
      set_repeat_table_header(summary.rows[0])
      for act, base, party, total in model["summary"]:
        row = summary.add_row()
        prevent_row_split(row)
        for i, txt in enumerate((act, base, party, total)):
            set_cell_text(row.cells[i], txt, bold=act.startswith("TOTAL"), size=7.0,
                          align=WD_ALIGN_PARAGRAPH.RIGHT if i == 3 else None)
        if act.startswith("TOTAL"):
            for c in row.cells:
                shade(c, LIGHT_BEIGE)

    # Politică de layout continuu: capitolele curg în ordinea logică, fără
    # page-break forțat între vânzare și ipotecă. Word decide natural
    # paginația; rândurile individuale rămân protejate împotriva ruperii.
    for idx, (title_text, rows, subtotal) in enumerate(model["sections"]):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = _VPt(2)
        p.paragraph_format.space_after = _VPt(1)
        p.paragraph_format.keep_with_next = True
        r = p.add_run(title_text)
        r.bold = True
        r.font.size = Pt(8.2)
        r.font.color.rgb = RGBColor.from_string(NAVY)
        # chapter table
        table = doc.add_table(rows=1, cols=3)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.autofit = False
        table.columns[0].width = Cm(6.2)
        table.columns[1].width = Cm(7.7)
        table.columns[2].width = Cm(3.6)
        for i, txt in enumerate(("Componentă", "Mod de calcul", "Valoare")):
            set_cell_text(table.cell(0, i), txt, bold=True, color=WHITE, size=7.1)
            shade(table.cell(0, i), NAVY)
        set_repeat_table_header(table.rows[0])
        for component, mode, value in rows:
            row = table.add_row()
            prevent_row_split(row)
            set_cell_text(row.cells[0], component, bold=component.startswith("TOTAL"), size=7.0)
            set_cell_text(row.cells[1], mode, size=6.8)
            set_cell_text(row.cells[2], value, bold=component.startswith("TOTAL"), size=7.0, align=WD_ALIGN_PARAGRAPH.RIGHT)
            if component.startswith("TOTAL"):
                for c in row.cells:
                    shade(c, LIGHT_BEIGE)
        if subtotal:
            row = table.add_row()
            prevent_row_split(row)
            merged = row.cells[0].merge(row.cells[1])
            set_cell_text(merged, "SUBTOTAL", bold=True, color=WHITE, size=7.2)
            shade(merged, NAVY)
            set_cell_text(row.cells[2], subtotal, bold=True, color=WHITE, size=7.2, align=WD_ALIGN_PARAGRAPH.RIGHT)
            shade(row.cells[2], NAVY)
    _cs = float(model.get("closing_size", 7.0))
    for _ci, (_lab, _txt) in enumerate(model["closing"]):  # am.368: oferta completa = «Observații: …»; scurt = Mentiune
        obs = doc.add_paragraph()
        obs.paragraph_format.space_before = _VPt(5 if _ci == 0 else 2)
        obs.paragraph_format.space_after = _VPt(0)
        if _lab:
            rr = obs.add_run(_lab)
            rr.bold = True
            rr.font.size = Pt(_cs)
        rr2 = obs.add_run(_txt)
        rr2.font.size = Pt(_cs)

    doc.save(output_path)




def _positive(value: Any) -> bool:
    try:
        return float(str(value)) > 0
    except Exception:
        return False


def _email_subject(data: Dict[str, Any]) -> str:
    cfg = data.get("configuration", {})
    comps = data.get("components", {})
    acts = cfg.get("acts", [])
    title = _acts_title(acts).replace("Contract de ", "").replace("Contract ", "")
    if "sale" in comps:
        currency = cfg.get("currency", "EUR")
        rate = (cfg.get("fx") or {}).get("rate")
        price_lei = comps["sale"].get("price_lei")
        if currency == "EUR" and rate:
            try:
                price = float(str(price_lei)) / float(str(rate))
                value = f"{price:,.0f}".replace(",", ".") + " EUR"
                return f"Calcul estimativ taxe notariale — {title.lower()} — {value}"
            except Exception:
                pass
    return f"Calcul estimativ taxe notariale — {title.lower()}"


def _email_docx_generator(data: Dict[str, Any], output_path: Path, logo_path: Path, short_model: Dict[str, Any] | None = None) -> None:
    """Generate a concise, client-facing Word draft for manual email copy/paste.
    `short_model` (am.368): e-mailul SCURT — acelasi antet, titlu, subiect, bloc de date si semnatura; continutul
    redus la sectiunile modelului scurt + Mentiune (litera titularului)."""
    from docx import Document
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt, RGBColor

    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Cm(0.9)
    sec.bottom_margin = Cm(0.65)
    sec.left_margin = Cm(1.45)
    sec.right_margin = Cm(1.45)

    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"].font.size = Pt(9.0)
    styles["Normal"].font.color.rgb = RGBColor.from_string(DARK)
    styles["Normal"].paragraph_format.space_after = Pt(0)
    styles["Normal"].paragraph_format.line_spacing = 1.0

    def shade(cell, fill: str) -> None:
        tc_pr = cell._tc.get_or_add_tcPr()
        shd = tc_pr.find(qn("w:shd"))
        if shd is None:
            shd = OxmlElement("w:shd")
            tc_pr.append(shd)
        shd.set(qn("w:fill"), fill)

    def set_cell_margins(cell, top=80, start=100, bottom=80, end=100) -> None:
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        tcMar = tcPr.first_child_found_in("w:tcMar")
        if tcMar is None:
            tcMar = OxmlElement("w:tcMar")
            tcPr.append(tcMar)
        for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
            node = tcMar.find(qn(f"w:{m}"))
            if node is None:
                node = OxmlElement(f"w:{m}")
                tcMar.append(node)
            node.set(qn("w:w"), str(v))
            node.set(qn("w:type"), "dxa")

    header = doc.add_table(rows=1, cols=2)
    header.alignment = WD_TABLE_ALIGNMENT.CENTER
    header.autofit = False
    header.columns[0].width = Cm(3.3)
    header.columns[1].width = Cm(13.3)
    left, right = header.rows[0].cells
    left.width = Cm(3.3)
    right.width = Cm(13.3)
    left.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    right.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    set_cell_margins(left, 0, 0, 0, 0)
    set_cell_margins(right, 0, 100, 0, 0)
    p_logo = left.paragraphs[0]
    p_logo.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p_logo.add_run().add_picture(str(logo_path), width=Cm(2.6))
    p_office = right.paragraphs[0]
    p_office.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = p_office.add_run(OFFICE)
    r.bold = True
    r.font.size = Pt(10)
    r.font.color.rgb = RGBColor.from_string(NAVY)
    p2 = right.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = p2.add_run(CONTACT)
    r.font.size = Pt(8.5)
    r.font.color.rgb = RGBColor.from_string(DARK)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_before = Pt(10)
    title.paragraph_format.space_after = Pt(4)
    r = title.add_run("CONȚINUT E-MAIL — CALCUL ESTIMATIV")
    r.bold = True
    r.font.size = Pt(13)
    r.font.color.rgb = RGBColor.from_string(NAVY)

    subject = doc.add_paragraph()
    subject.paragraph_format.space_after = Pt(10)
    rs = subject.add_run("Subiect recomandat: ")
    rs.bold = True
    rs.font.color.rgb = RGBColor.from_string(NAVY)
    subject.add_run(_email_subject(data))

    def add_body(text: str = "", *, bold_prefix: str | None = None) -> None:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(1)
        if bold_prefix and text.startswith(bold_prefix):
            a, b = text.split(bold_prefix, 1)
            if a:
                p.add_run(a)
            rr = p.add_run(bold_prefix)
            rr.bold = True
            p.add_run(b)
        else:
            p.add_run(text)

    # PATCH V4.17 (am.135): poarta părții — titlurile de nivel 1 setează partea curentă; rândurile/totalurile
    # altei părți decât scope-ul nu se scriu. Titlurile generice (fără parte) trec mereu.
    _email_scope = _offer_scope(data)
    _cur = {"party": None}

    def _heading_party(text: str) -> str | None:
        up = str(text).upper()
        if any(m.upper() in up for m in _SELLER_MARKERS):
            return "seller"
        if any(k in up for k in ("CUMPĂRĂTOR", "SOLICITANT", "DEBITOR", "SERVICII SUPLIMENTARE")):
            return "buyer"
        return None

    def _gated() -> bool:
        return _email_scope != "both" and _cur["party"] is not None and _cur["party"] != _email_scope

    def add_heading(text: str, level: int = 1) -> None:
        if level == 1:
            _cur["party"] = _heading_party(text)
        if _gated():
            return
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(5 if level == 1 else 3)
        p.paragraph_format.space_after = Pt(1)
        r = p.add_run(text)
        r.bold = True
        r.font.color.rgb = RGBColor.from_string(NAVY)
        r.font.size = Pt(10.5 if level == 1 else 9.5)
        if level == 1:
            pPr = p._p.get_or_add_pPr()
            shd = OxmlElement("w:shd")
            shd.set(qn("w:fill"), LIGHT_BEIGE)
            pPr.append(shd)

    def add_line(label: str, value: Any, *, note: str | None = None) -> None:
        if not _positive(value) or _gated():
            return
        p = doc.add_paragraph(style=None)
        p.style = doc.styles["Normal"]
        p.paragraph_format.left_indent = Cm(0.35)
        p.paragraph_format.first_line_indent = Cm(-0.2)
        p.paragraph_format.space_after = Pt(1)
        p.add_run("• ")
        rr = p.add_run(label + ": ")
        rr.bold = True
        p.add_run(money(value))
        if note:
            rn = p.add_run(f" ({note})")
            rn.italic = True

    def quantity_note(quantity: Any, singular: str, plural: str, unit_price: Any) -> str | None:
        try:
            qty = int(float(str(quantity)))
        except Exception:
            return None
        if qty <= 0:
            return None
        noun = singular if qty == 1 else plural
        return f"{qty} {noun} × {money(unit_price)}"

    def add_total(label: str, value: Any) -> None:
        if not _positive(value) or _gated():
            return
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(f"{label}: {money(value)}")
        r.bold = True
        r.font.color.rgb = RGBColor.from_string(NAVY)

    cfg = data.get("configuration", {})
    fx = cfg.get("fx", {}) or {}
    comps = data.get("components", {})
    totals = data.get("totals", {})
    acts = cfg.get("acts", [])
    currency = cfg.get("currency", "EUR")

    add_body("Bună ziua,")
    add_body("Vă mulțumim pentru solicitare.")
    if short_model is not None:  # am.368
        add_body(_fraza_deschidere_am374(acts))  # PATCH V4.27 (am.374, LOT T56j-1 B-1..B-4)
    else:
        add_body("Pe baza informațiilor comunicate, am pregătit calculul estimativ al costurilor aferente tranzacției dumneavoastră.")

    add_heading("Datele utilizate pentru calcul")
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0.35)
    p.add_run("• ")
    rr = p.add_run("Acte: "); rr.bold = True
    p.add_run(_acts_title(acts))
    if "sale" in comps:
        p = doc.add_paragraph(); p.paragraph_format.left_indent = Cm(0.35); p.add_run("• ")
        rr=p.add_run("Prețul vânzării: "); rr.bold=True
        if currency == "EUR" and fx.get("rate"):
            eur = float(str(comps["sale"].get("price_lei"))) / float(str(fx.get("rate")))
            p.add_run(f"{eur:,.0f}".replace(",", ".") + f" {currency}")
        else:
            p.add_run(money(comps["sale"].get("price_lei")))
    if "antecontract" in comps:
        p = doc.add_paragraph(); p.paragraph_format.left_indent = Cm(0.35); p.add_run("• ")
        rr=p.add_run("Avansul la antecontract: "); rr.bold=True
        if currency == "EUR" and fx.get("rate"):
            eur = float(str(comps["antecontract"].get("advance_lei"))) / float(str(fx.get("rate")))
            p.add_run(f"{eur:,.0f}".replace(",", ".") + f" {currency}")
        else:
            p.add_run(money(comps["antecontract"].get("advance_lei")))
    if "mortgage" in comps:
        p = doc.add_paragraph(); p.paragraph_format.left_indent = Cm(0.35); p.add_run("• ")
        rr=p.add_run("Valoarea creditului: "); rr.bold=True
        if currency == "EUR" and fx.get("rate"):
            eur = float(str(comps["mortgage"].get("credit_lei"))) / float(str(fx.get("rate")))
            p.add_run(f"{eur:,.0f}".replace(",", ".") + f" {currency}")
        else:
            p.add_run(money(comps["mortgage"].get("credit_lei")))
    if currency == "EUR":
        p = doc.add_paragraph(); p.paragraph_format.left_indent = Cm(0.35); p.add_run("• ")
        rr=p.add_run("Curs utilizat: "); rr.bold=True
        p.add_run(f"{fx.get('rate', '—')} lei/EUR")
        source = str(fx.get("source") or "").strip()
        if source.upper() == "BNR" and fx.get("publication_date"):
            p.add_run(f" — curs BNR publicat la {fx.get('publication_date')}")
        elif source:
            p.add_run(" — curs comunicat pentru această speță")
    if cfg.get("buyer_type") and _email_scope != "seller":
        p = doc.add_paragraph(); p.paragraph_format.left_indent = Cm(0.35); p.add_run("• ")
        role = "Debitor / constituitor" if set(acts) == {"mortgage"} else ("Promitent-cumpărător" if set(acts)=={"antecontract"} else "Cumpărător")
        rr=p.add_run(role + ": "); rr.bold=True; p.add_run(_person_label(cfg.get("buyer_type")))
    if cfg.get("seller_type") and any(a in acts for a in ("sale", "antecontract")) and _email_scope != "buyer":
        p = doc.add_paragraph(); p.paragraph_format.left_indent = Cm(0.35); p.add_run("• ")
        role = "Promitent-vânzător" if set(acts)=={"antecontract"} else "Vânzător"
        rr=p.add_run(role + ": "); rr.bold=True; p.add_run(_person_label(cfg.get("seller_type")))

    if short_model is not None:  # am.368: e-mailul scurt — sectiunile modelului scurt, apoi Mentiune si semnatura
        _cur["party"] = None
        for _title, _rows, _sub in short_model["sections"]:
            if not all(_r[0].startswith("TOTAL") for _r in _rows):  # sectiunea de total pe parte nu isi repeta titlul in e-mail
              p = doc.add_paragraph()
              p.paragraph_format.space_before = Pt(5)
              p.paragraph_format.space_after = Pt(1)
              r = p.add_run(_title)
              r.bold = True
              r.font.color.rgb = RGBColor.from_string(NAVY)
              r.font.size = Pt(10.5)
              pPr = p._p.get_or_add_pPr()
              shd = OxmlElement("w:shd")
              shd.set(qn("w:fill"), LIGHT_BEIGE)
              pPr.append(shd)
            for _lab, _mode, _amt in _rows:
                _tot = _lab.startswith("TOTAL")
                p = doc.add_paragraph()
                p.paragraph_format.left_indent = Cm(0.35)
                p.paragraph_format.first_line_indent = Cm(-0.2)
                p.paragraph_format.space_after = Pt(1)
                if _tot:
                    r = p.add_run(f"{_lab}: {_amt}")
                    r.bold = True
                    r.font.color.rgb = RGBColor.from_string(NAVY)
                else:
                    p.add_run("• ")
                    rr = p.add_run(_lab + ": ")
                    rr.bold = True
                    p.add_run(_amt)
                    if _mode:
                        rn = p.add_run(f" ({_mode})")
                        rn.italic = True
            if _sub:
                p = doc.add_paragraph()
                p.paragraph_format.space_before = Pt(2)
                p.paragraph_format.space_after = Pt(3)
                r = p.add_run(f"Subtotal: {_sub}")
                r.bold = True
                r.font.color.rgb = RGBColor.from_string(NAVY)
        add_heading("Mențiune")
        for _lab, _txt in short_model["closing"]:
            add_body(_txt)
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(3)
        p.paragraph_format.space_after = Pt(1)
        p.add_run("Cu stimă,\n")
        r = p.add_run("SPN STOICA S. EDUARD & ASOCIAȚII")
        r.bold = True
        r.font.color.rgb = RGBColor.from_string(NAVY)
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(0)
        p.add_run("Telefon: +40 722 222 281   |   E-mail: contact@notariatstoica.ro")
        footer = sec.footer.paragraphs[0]
        footer.text = ""
        doc.save(output_path)
        return

    add_heading("Rezumatul costurilor estimate")

    if "sale" in comps:
        seller = (comps["sale"].get("seller") or {})
        add_heading("VÂNZĂTOR", 1)
        add_heading("Taxe datorate statului", 2)
        if seller.get("tax") is not None and seller.get("tax_shares"):
            add_line(f"Impozit pe venitul din transferul proprietății — MIXT pe cote ({seller.get('tax_percent_label')})", seller.get("tax"))  # am.282 (V3.11)
        elif seller.get("tax") is not None:
            pct = seller.get("tax_percent")
            add_line(f"Impozit pe venitul din transferul proprietății — {pct}%", seller.get("tax"))
        else:
            add_line("Varianta impozit 1%", seller.get("tax_1"))
            add_line("Varianta impozit 3%", seller.get("tax_3"))
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.35)
            rr = p.add_run("Cele două variante sunt alternative și nu se cumulează.")
            rr.italic = True
        add_heading("Extrase și verificări", 2)
        add_line("Extras de carte funciară pentru autentificare", seller.get("authentication_extract"), note=quantity_note(seller.get("authentication_extract_quantity", 1), "extras", "extrase", seller.get("authentication_extract_unit", 40)))
        add_line("Verificări în registrele notariale", seller.get("seller_verification"), note=quantity_note(seller.get("seller_verification_quantity", 1), "verificare", "verificări", seller.get("seller_verification_unit", 18.15)))
        if seller.get("total") is not None:
            add_total("TOTAL ESTIMATIV VÂNZĂTOR", seller.get("total"))
        else:
            add_total("TOTAL ESTIMATIV VÂNZĂTOR — VARIANTA 1%", totals.get("seller_tax_1"))
            add_total("TOTAL ESTIMATIV VÂNZĂTOR — VARIANTA 3%", totals.get("seller_tax_3"))

    if "sale" in comps:
        s = comps["sale"]
        add_heading("CUMPĂRĂTOR — CONTRACT DE VÂNZARE", 1)
        add_heading("Sume aferente serviciului notarial", 2)
        add_line("Onorariu notarial net", s.get("honorarium_net"))
        add_line("TVA aferent onorariului și arhivării", s.get("vat"), note="colectată pentru stat")
        add_line("Arhivare", s.get("archive"))
        add_heading("Taxe și formalități către stat / alte instituții", 2)
        add_line("Taxă ANCPI pentru intabularea dreptului de proprietate", s.get("ancpi"))
        add_line("Taxă de notare în cartea funciară", s.get("land_book_notation"), note=quantity_note(s.get("notation_quantity", 0), "notare", "notări", s.get("notation_unit", 75)))
        add_line("Verificări în registrele notariale", s.get("buyer_verification"), note=quantity_note(s.get("buyer_verification_quantity", 1), "verificare", "verificări", s.get("buyer_verification_unit", 18.15)))
        add_total("Subtotal contract de vânzare", s.get("buyer_total"))

    if "mortgage" in comps:
        m = comps["mortgage"]
        standalone = set(acts) == {"mortgage"}
        add_heading(("DEBITOR / CONSTITUITOR" if standalone else "CUMPĂRĂTOR") + " — CONTRACT DE IPOTECĂ / REFINANȚARE", 1)
        add_heading("Sume aferente serviciului notarial", 2)
        add_line("Onorariu notarial net", m.get("honorarium_net"))
        add_line("TVA aferent onorariului și arhivării", m.get("vat"), note="colectată pentru stat")
        add_line("Arhivare", m.get("archive"))
        add_heading("Taxe și formalități către stat / alte instituții", 2)
        additional_collateral_qty = int(m.get("additional_collateral_property_quantity", 0) or 0)
        collateral_note = None
        if additional_collateral_qty:
            noun = "imobil suplimentar" if additional_collateral_qty == 1 else "imobile suplimentare"
            collateral_note = (
                f"include {additional_collateral_qty} {noun} × "
                f"{money(m.get('additional_collateral_property_unit', 100))}"
            )
        add_line("Taxă OCPI pentru înscrierea ipotecii", m.get("ocpi"), note=collateral_note)
        add_line("Taxă de notare în cartea funciară", m.get("land_book_notation"), note=quantity_note(m.get("notation_quantity", 0), "notare", "notări", m.get("notation_unit", 75)))
        add_line("Verificări procuri bancare", m.get("bank_proxy_checks"), note=quantity_note(m.get("bank_proxy_check_quantity", 2), "verificare", "verificări", m.get("bank_proxy_check_unit", 18.15)))
        add_line("Legalizare procură bancară / copii", m.get("bank_proxy_legalization"), note=quantity_note(m.get("legalized_copy_quantity", 6), "pagină", "pagini", m.get("legalized_copy_unit", 6.05)))
        add_line("Verificări în registrele notariale", m.get("buyer_verification"), note=quantity_note(m.get("buyer_verification_quantity", 1), "verificare", "verificări", m.get("buyer_verification_unit", 18.15)))
        add_line("Extras de carte funciară pentru autentificare", m.get("authentication_extract"), note=quantity_note(m.get("authentication_extract_quantity", 1), "extras", "extrase", m.get("authentication_extract_unit", 40)))
        add_total("Subtotal contract de ipotecă / refinanțare", m.get("buyer_total"))

    if "antecontract" in comps:
        a = comps["antecontract"]
        add_heading("PROMITENT-CUMPĂRĂTOR — ANTECONTRACT", 1)
        add_heading("Sume aferente serviciului notarial", 2)
        add_line("Onorariu notarial net", a.get("honorarium_net"))
        add_line("TVA aferent onorariului și arhivării", a.get("vat"), note="colectată pentru stat")
        add_line("Arhivare", a.get("archive"))
        add_heading("Taxe și formalități către stat / alte instituții", 2)
        add_line("Verificări în registrele notariale", a.get("buyer_verification"), note=quantity_note(a.get("buyer_verification_quantity", 1), "verificare", "verificări", a.get("buyer_verification_unit", 18.15)))
        add_line("Taxă opțională de notare", a.get("optional_notation"), note=quantity_note(a.get("notation_quantity", 1), "notare", "notări", a.get("notation_unit", 75)))
        add_total("Total fără notare", a.get("buyer_without_notation"))
        add_total("Total cu notare", a.get("buyer_with_notation"))
        add_heading("PROMITENT-VÂNZĂTOR — ANTECONTRACT", 1)
        add_line("Extras de carte funciară pentru informare", a.get("seller_information_extract"), note=quantity_note(a.get("seller_information_extract_quantity", 1), "extras", "extrase", a.get("seller_information_extract_unit", 20)))
        add_line("Verificări în registrele notariale", a.get("seller_verification"), note=quantity_note(a.get("seller_verification_quantity", 1), "verificare", "verificări", a.get("seller_verification_unit", 18.15)))
        add_total("Total estimativ promitent-vânzător", a.get("seller_total"))

    if "radiere" in comps:
        rz = comps["radiere"]
        add_heading("SOLICITANT — DECLARAȚIE DE RADIERE", 1)
        add_heading("Sume aferente serviciului notarial", 2)
        add_line("Onorariu notarial net", rz.get("honorarium_net"))
        add_line("TVA aferent onorariului", rz.get("vat"), note="colectată pentru stat")
        add_heading("Taxe și formalități către stat / alte instituții", 2)
        add_line("Extras de carte funciară pentru informare", rz.get("information_extract"), note=quantity_note(rz.get("information_extract_quantity", 1), "extras", "extrase", rz.get("information_extract_unit", 20)))
        for _l, _n, _v in _ancpi_radiere_randuri_am374(rz):  # PATCH V4.27 (am.374)
            add_line(_l, _v, note=_n)
        add_total("Total estimativ solicitant", rz.get("total"))

    if "opinion" in comps:
        o = comps["opinion"]
        add_heading("SOLICITANT — OPINIE NOTARIALĂ", 1)
        add_heading("Sume aferente serviciului notarial", 2)
        add_line("Onorariu notarial net", o.get("honorarium_net"))
        add_line("TVA aferent onorariului", o.get("vat"), note="colectată pentru stat")
        add_heading("Taxe și formalități către stat / alte instituții", 2)
        add_line("Extras de carte funciară pentru informare", o.get("information_extract"), note=quantity_note(o.get("information_extract_quantity", 1), "extras", "extrase", o.get("information_extract_unit", 20)))
        add_line("Taxă de notare în cartea funciară", o.get("land_book_notation"), note=quantity_note(o.get("notation_quantity", 0), "notare", "notări", o.get("notation_unit", 75)))
        add_total("Total estimativ solicitant", o.get("total"))

    other_act_notation_present = any(
        str((comps.get(act) or {}).get("land_book_notation", "0")) not in ("0", "0.00", "None")
        for act in ("opinion", "radiere", "sale", "mortgage")
    )
    _svs_e = data.get("services") or []
    # PATCH V4.25 (am.367, TIC-T55Z-EMAIL-TAXE-SUPLIMENTARE): taxele suplimentare declarate de operator pe cumparator
    # intrau in total (V4.3) si in oferta DOCX (am.169), dar NU in e-mail — linia disparea, totalul ramanea corect.
    _afs_b_e = [a for a in (comps.get("additional_fees") or []) if str(a.get("party") or "buyer") != "seller"]
    if _svs_e or _afs_b_e:
        add_heading("SERVICII SUPLIMENTARE", 1)
        for _s in _svs_e:
            add_line(str(_s.get("label")), _s.get("amount"), note=quantity_note(_s.get("quantity"), str(_s.get("unit_singular")), str(_s.get("unit_label")), _s.get("unit_amount")))
        for _a in _afs_b_e:
            add_line(str(_a.get("label")), _a.get("amount"), note="declarată de operator")
    _cur["party"] = "buyer"  # am.135: totalurile finale ale cumpărătorului
    if len(comps) > 1 or "sale" in comps or _svs_e or _afs_b_e:
        buyer_without = totals.get("buyer_without_optional_notation")
        buyer_with = totals.get("buyer_with_optional_notation")
        if buyer_without is not None:
            if buyer_with is not None and str(buyer_with) != str(buyer_without):
                without_label = "TOTAL GENERAL ESTIMATIV CUMPĂRĂTOR — FĂRĂ NOTAREA P-V" if other_act_notation_present else "TOTAL GENERAL ESTIMATIV CUMPĂRĂTOR — FĂRĂ NOTARE"
                with_label = "TOTAL GENERAL ESTIMATIV CUMPĂRĂTOR — CU NOTAREA P-V" if other_act_notation_present else "TOTAL GENERAL ESTIMATIV CUMPĂRĂTOR — CU NOTARE"
                add_total(without_label, buyer_without)
                add_total(with_label, buyer_with)
            else:
                label = "TOTAL ESTIMATIV DEBITOR / CONSTITUITOR" if set(acts)=={"mortgage"} else ("TOTAL ESTIMATIV SOLICITANT" if set(acts) <= {"opinion", "radiere"} else "TOTAL ESTIMATIV CUMPĂRĂTOR")
                add_total(label, buyer_without)

    # PATCH V4.20 (am.169): serviciile/taxele in sarcina vanzatorului (heading cu VÂNZĂTOR → partea seller, am.135)
    _svs_s_e = data.get("services_seller") or []
    _afs_s_e = [a for a in (comps.get("additional_fees") or []) if str(a.get("party") or "buyer") == "seller"]
    _rad_s_e = comps.get("radiere") if ("radiere" in comps and str(comps["radiere"].get("party") or "buyer") == "seller") else None
    if _svs_s_e or _afs_s_e or _rad_s_e:
        add_heading("VÂNZĂTOR — SERVICII ȘI TAXE ÎN SARCINA VÂNZĂTORULUI", 1)
        for _s in _svs_s_e:
            add_line(str(_s.get("label")), _s.get("amount"), note=quantity_note(_s.get("quantity"), str(_s.get("unit_singular")), str(_s.get("unit_label")), _s.get("unit_amount")))
        for _a in _afs_s_e:
            add_line(f"{_a.get('label')} (vânzător)", _a.get("amount"), note="declarată de operator")
        if _rad_s_e:
            add_line("Declarație de radiere (vânzător)", _rad_s_e.get("total"), note="onorariu + TVA + extras + taxa ANCPI de radiere")
        add_total("TOTAL SERVICII ȘI TAXE ÎN SARCINA VÂNZĂTORULUI", totals.get("seller_extra_total"))
    _cur["party"] = "seller"  # am.135: totalul general al vânzătorului
    global_seller = totals.get("seller")
    if global_seller is not None and (("antecontract" in comps and "sale" in comps) or totals.get("seller_extra_total") is not None):
        add_total("TOTAL GENERAL ESTIMATIV VÂNZĂTOR", global_seller)
    elif totals.get("seller_extra_total") is not None and totals.get("seller_tax_1") is not None:
        add_total("TOTAL GENERAL ESTIMATIV VÂNZĂTOR — VARIANTA 1%", totals.get("seller_tax_1"))
        add_total("TOTAL GENERAL ESTIMATIV VÂNZĂTOR — VARIANTA 3%", totals.get("seller_tax_3"))
    _cur["party"] = None

    add_body("Calculul detaliat și modul de determinare a fiecărei componente se regăsesc în oferta PDF atașată.")
    if _email_scope != "seller":  # am.135: fraza onorariilor privește totalul cumpărătorului/solicitantului
        add_body("Precizăm că totalurile includ atât onorariile aferente serviciilor notariale, cât și TVA, impozite, taxe de publicitate imobiliară și tarife pentru verificări ori formalități, datorate statului sau altor instituții și evidențiate distinct mai sus.")
    add_body("Valorile sunt calculate pe baza datelor furnizate și a cursului indicat.")
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(1)
    p.add_run("Cu stimă,\n")
    r = p.add_run("SPN STOICA S. EDUARD & ASOCIAȚII")
    r.bold = True
    r.font.color.rgb = RGBColor.from_string(NAVY)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(0)
    p.add_run("Telefon: +40 722 222 281   |   E-mail: contact@notariatstoica.ro")

    footer = sec.footer.paragraphs[0]
    footer.text = ""

    doc.save(output_path)


def _email_qa(data: Dict[str, Any], email_docx_path: Path) -> Dict[str, Any]:
    """Fast run-time QA for the email DOCX; visual regression is performed by the patch suite."""
    import zipfile

    text = _extract_docx_text(email_docx_path)
    lower = text.lower()
    totals = data.get("totals", {})
    _scope = _offer_scope(data)
    if _scope == "both":
        expected: List[str] = []
        for key in ("buyer_without_optional_notation", "buyer_with_optional_notation", "seller_tax_1", "seller_tax_3", "seller_total", "seller"):
            if totals.get(key) is not None:
                value = num(totals.get(key))
                if value not in expected:
                    expected.append(value)
        comps = data.get("components", {})
        for component in comps.values():
            if isinstance(component, dict):
                for key in ("buyer_total", "buyer_without_notation", "buyer_with_notation", "seller_total", "total"):
                    if component.get(key) is not None:
                        value = num(component.get(key))
                        if value not in expected:
                            expected.append(value)
    else:
        # PATCH V4.17 (am.135): pe oferta individuală, e-mailul poartă numai totalurile părții
        expected = _expected_totals(data, _scope)
    missing = [value for value in expected if value not in text]
    if _scope == "seller":
        # PATCH V4.17 (am.135): e-mailul vânzătorului nu are titlurile de onorariu ale cumpărătorului
        required = ["Vă mulțumim pentru solicitare", "Calculul detaliat", "VÂNZĂTOR"] + (["Taxe datorate statului"] if "sale" in (data.get("components") or {}) else [])
    else:
        required = [
            "Vă mulțumim pentru solicitare",
            "Sume aferente serviciului notarial",
            "Taxe și formalități",
            "Calculul detaliat",
        ]
    missing_required = [phrase for phrase in required if phrase.lower() not in lower]
    forbidden = [token for token in ("ENGINE_RESULT", "PIPELINE_RESULT", "run_id", "CALCULATION_PASS_INTERNAL_DRAFT", "traceback") if token.lower() in lower]
    zip_ok = False
    zip_error = None
    try:
        with zipfile.ZipFile(email_docx_path) as archive:
            zip_ok = archive.testzip() is None and "word/document.xml" in archive.namelist()
    except Exception as exc:
        zip_error = str(exc)
    checks = {
        "email_docx_exists": email_docx_path.is_file() and email_docx_path.stat().st_size > 0,
        "email_docx_zip_integrity": zip_ok,
        "email_totals_present": not missing,
        "email_required_sections_present": not missing_required,
        "email_no_internal_tokens": not forbidden,
    }
    return {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "details": {
            "missing_totals": missing,
            "missing_required": missing_required,
            "forbidden_tokens": forbidden,
            "zip_error": zip_error,
        },
    }

def _pdf_generator(data: Dict[str, Any], output_path: Path, logo_path: Path,
                   compact: float = 1.0, measure_only: bool = False, model: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Desenează oferta PDF. `model` (am.368): None = oferta completa (`_full_layout_model`), altfel setul scurt.

    `compact` scalează exclusiv spațierea verticală (padding de celulă, spacer-e
    și interlinie). Dimensiunile de font, coloanele, culorile și conținutul rămân
    neschimbate: compactarea nu poate altera ce scrie în ofertă.

    Cu `measure_only=True` nu se scrie niciun fișier; se returnează înălțimea
    totală a conținutului și înălțimea utilă a paginii, pentru decizia de layout.
    """
    model = model or _full_layout_model(data)
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_RIGHT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import (
        BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer, Table, TableStyle,
        Image, PageBreak, KeepTogether
    )

    font_regular = None
    font_bold = None
    candidates = [
        ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        ("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf", "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"),
    ]
    for r, b in candidates:
        if os.path.exists(r) and os.path.exists(b):
            font_regular, font_bold = r, b
            break
    if font_regular:
        pdfmetrics.registerFont(TTFont("SPN", font_regular))
        pdfmetrics.registerFont(TTFont("SPN-Bold", font_bold))
        regular_name, bold_name = "SPN", "SPN-Bold"
    else:
        regular_name, bold_name = "Helvetica", "Helvetica-Bold"

    navy = colors.HexColor("#" + NAVY)
    beige = colors.HexColor("#" + BEIGE)
    light_beige = colors.HexColor("#" + LIGHT_BEIGE)
    grey = colors.HexColor("#" + MID_GREY)

    class NumberedDoc(BaseDocTemplate):
        pass

    AM388_LATIME_CONTINUT = 17*cm  # am.388: latimea tabelelor = a antetului = a subsolului
    doc = NumberedDoc(str(output_path), pagesize=A4, rightMargin=1.35*cm, leftMargin=1.35*cm,
                      topMargin=1.2*cm, bottomMargin=1.45*cm)
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="normal")

    def footer(canvas, doc_obj):
        canvas.saveState()
        # Logo redus pe paginile următoare, conform regulii multipagină.
        if doc_obj.page > 1:
            try:
                canvas.drawImage(str(logo_path), 1.35*cm, A4[1] - 1.02*cm, width=1.25*cm, height=0.70*cm, preserveAspectRatio=True, mask="auto")
            except Exception:
                pass
        # AM388_SUBSOL (T56y): banda scurtata stanga-dreapta, aliniata cu tabelele si antetul (17 cm, centrate)
        _x0 = (A4[0] - AM388_LATIME_CONTINUT) / 2
        canvas.setFillColor(beige)
        canvas.rect(_x0, 0.55*cm, AM388_LATIME_CONTINUT, 0.55*cm, fill=1, stroke=0)
        canvas.setFillColor(navy)
        canvas.rect(A4[0]/2 - 1.6*cm, 0.55*cm, 3.2*cm, 0.55*cm, fill=1, stroke=0)
        canvas.setFont(regular_name, 7)
        canvas.setFillColor(colors.HexColor("#333333"))
        canvas.drawString(_x0 + 0.25*cm, 0.73*cm, CONTACT)
        canvas.drawRightString(_x0 + AM388_LATIME_CONTINUT - 0.25*cm, 0.73*cm, FOOTER_OFFICE)
        canvas.setFillColor(colors.white)
        canvas.drawCentredString(A4[0]/2, 0.73*cm, f"Pagina {doc_obj.page}")
        canvas.restoreState()

    doc.addPageTemplates([PageTemplate(id="all", frames=frame, onPage=footer)])
    styles = getSampleStyleSheet()
    base = ParagraphStyle("base", parent=styles["Normal"], fontName=regular_name, fontSize=7.2, leading=9.0, textColor=colors.HexColor("#"+DARK))
    # leading-ul efectiv se ajusteaza mai jos, dupa calculul factorului de compactare
    small = ParagraphStyle("small", parent=base, fontSize=6.7, leading=8.2)
    title = ParagraphStyle("title", parent=base, fontName=bold_name, fontSize=17, leading=20, alignment=TA_CENTER, textColor=navy, spaceAfter=2)
    subtitle = ParagraphStyle("subtitle", parent=base, fontName=bold_name, fontSize=9, leading=11, alignment=TA_CENTER, textColor=colors.HexColor("#B28B45"), spaceAfter=5)
    chapter = ParagraphStyle("chapter", parent=base, fontName=bold_name, fontSize=8.2, leading=10, textColor=navy, spaceBefore=3, spaceAfter=2)
    table_head = ParagraphStyle("table_head", parent=small, fontName=bold_name, textColor=colors.white)
    table_white = ParagraphStyle("table_white", parent=small, fontName=bold_name, textColor=colors.white)

    story = []
    # Pentru oferte cu mai multe acte folosim o compactare verticală moderată,
    # fără reducerea lizibilității, astfel încât conținutul să curgă continuu
    # și să evităm pagini aproape goale generate doar de câțiva milimetri.
    multi_act_layout = len(data.get("components", {})) >= 2
    # Compactarea acționează numai pe spațiul alb vertical. Pragurile minime de
    # mai jos păstrează lizibilitatea chiar la factorul cel mai agresiv.
    table_vpad = max(1.3, (2.2 if multi_act_layout else 3.0) * compact)
    cfg_vpad = max(1.2, (2.0 if multi_act_layout else 2.5) * compact)
    gap_small = max(2.0, (3 if multi_act_layout else 5) * compact)
    gap_tiny = max(1.5, (2 if multi_act_layout else 4) * compact)
    body_leading = max(8.0, 9.0 * compact)

    base.leading = body_leading
    small.leading = max(7.4, 8.2 * compact)

    head = Table([
        [Image(str(logo_path), width=2.4*cm, height=1.5*cm), Paragraph(
            f"<b>{OFFICE}</b><br/>{ADDRESS}<br/>{ACCOUNT}<br/>{CIF}<br/>{LICENSE}", small)]
    ], colWidths=[3.0*cm, 14.0*cm])  # am.388: antetul pe latimea tabelelor (17 cm, era 17,3)
    head.setStyle(TableStyle([("VALIGN", (0,0), (-1,-1), "MIDDLE"), ("BOX", (0,0), (-1,-1), 0, colors.white)]))
    story += [head, Spacer(1, 4), Paragraph(model["title"], title), Paragraph(model["subtitle"], subtitle)]

    cfg_rows = model["cfg_rows"]
    cfg_data = []
    for i in range(0, len(cfg_rows), 2):
        pair = cfg_rows[i:i+2]
        while len(pair) < 2:
            pair.append(("", ""))
        cfg_data.append([Paragraph(f"<b>{pair[0][0]}</b>", small), Paragraph(str(pair[0][1]), small), Paragraph(f"<b>{pair[1][0]}</b>", small), Paragraph(str(pair[1][1]), small)])
    cfg_table = Table(cfg_data, colWidths=[3.0*cm, 5.5*cm, 3.0*cm, 5.5*cm])
    cfg_table.setStyle(TableStyle([
        ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#BFC4C8")),
        ("BACKGROUND", (0,0), (0,-1), grey), ("BACKGROUND", (2,0), (2,-1), grey),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"), ("LEFTPADDING", (0,0), (-1,-1), 4), ("RIGHTPADDING", (0,0), (-1,-1), 4),
        ("TOPPADDING", (0,0), (-1,-1), cfg_vpad), ("BOTTOMPADDING", (0,0), (-1,-1), cfg_vpad),
    ]))
    story += [cfg_table, Spacer(1, gap_small)]
    if model.get("summary") is not None:  # am.368: setul scurt nu are sinteza
      from reportlab.lib.styles import ParagraphStyle as _PS388r
      story += [Paragraph("REZUMAT EXECUTIV AL COSTURILOR", _PS388r("am388_rezumat", parent=chapter,
                                                                     leftIndent=max(0.0, (frame._width - frame._leftPadding - frame._rightPadding - AM388_LATIME_CONTINUT) / 2)))]  # am.388 (D7)
      sum_data = [[Paragraph("Capitol / act", table_head), Paragraph("Bază / explicație", table_head), Paragraph("Parte", table_head), Paragraph("Subtotal / total", table_head)]]
      for act, basis, party, total in model["summary"]:
        sum_data.append([Paragraph(act, small), Paragraph(basis, small), Paragraph(party, small), Paragraph(total, small)])
      sum_table = Table(sum_data, colWidths=[6.0*cm, 4.5*cm, 2.8*cm, 3.7*cm], repeatRows=1)
      style = [("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#AEB4B9")), ("BACKGROUND", (0,0), (-1,0), navy),
             ("TEXTCOLOR", (0,0), (-1,0), colors.white), ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
             ("ALIGN", (-1,1), (-1,-1), "RIGHT"), ("TOPPADDING", (0,0), (-1,-1), table_vpad), ("BOTTOMPADDING", (0,0), (-1,-1), table_vpad)]
      for idx, row in enumerate(model["summary"], start=1):
        if row[0].startswith("TOTAL"):
            style.append(("BACKGROUND", (0,idx), (-1,idx), light_beige))
            style.append(("FONTNAME", (0,idx), (-1,idx), bold_name))
      sum_table.setStyle(TableStyle(style))
      story += [sum_table, Spacer(1, gap_small)]

    sections = model["sections"]
    for idx, (section_title, rows, subtotal) in enumerate(sections):
        # Politică de layout continuu: fără PageBreak forțat între capitole.
        # Tabelele se lasă să curgă natural și să se împartă numai când
        # spațiul fizic al paginii o impune.
        chapter_header = Table([[Paragraph(section_title, chapter)]], colWidths=[17*cm])
        chapter_header.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), beige), ("LEFTPADDING", (0,0), (-1,-1), 5), ("RIGHTPADDING", (0,0), (-1,-1), 5), ("TOPPADDING", (0,0), (-1,-1), 0), ("BOTTOMPADDING", (0,0), (-1,-1), 0)]))
        d = [[Paragraph("Componentă", table_head), Paragraph("Mod de calcul", table_head), Paragraph("Valoare", table_head)]]
        for comp, mode, val in rows:
            d.append([Paragraph(comp, small), Paragraph(mode, small), Paragraph(val, small)])
        if subtotal:
            d.append([Paragraph("SUBTOTAL", table_white), "", Paragraph(subtotal, table_white)])
        tbl = Table(d, colWidths=[6.1*cm, 7.2*cm, 3.7*cm], repeatRows=1)
        ts = [("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#AEB4B9")), ("BACKGROUND", (0,0), (-1,0), navy),
              ("TEXTCOLOR", (0,0), (-1,0), colors.white), ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
              ("ALIGN", (-1,1), (-1,-1), "RIGHT"), ("TOPPADDING", (0,0), (-1,-1), table_vpad), ("BOTTOMPADDING", (0,0), (-1,-1), table_vpad)]
        if subtotal:
            last = len(d)-1
            ts += [("BACKGROUND", (0,last), (-1,last), navy), ("TEXTCOLOR", (0,last), (-1,last), colors.white), ("SPAN", (0,last), (1,last))]
        for rix, (comp, _, _) in enumerate(rows, start=1):
            if comp.startswith("TOTAL"):
                ts.append(("BACKGROUND", (0,rix), (-1,rix), light_beige))
                ts.append(("FONTNAME", (0,rix), (-1,rix), bold_name))
        tbl.setStyle(TableStyle(ts))
        # Nu ținem întreg capitolul într-un KeepTogether: acesta poate muta
        # inutil un capitol complet pe pagina următoare și lăsa spațiu alb.
        # Titlul și tabelul sunt consecutive, iar tabelul poate continua
        # natural pe pagina următoare dacă este necesar.
        story += [chapter_header, tbl, Spacer(1, gap_tiny)]
    from reportlab.lib.styles import ParagraphStyle as _PS388
    _ind388 = max(0.0, (frame._width - frame._leftPadding - frame._rightPadding - AM388_LATIME_CONTINUT) / 2)  # am.388: textul de sub tabel aliniat cu tabelele, antetul, subsolul
    _sub_tabel388 = _PS388("am388_sub_tabel", parent=small, leftIndent=_ind388, rightIndent=_ind388)
    for _lab, _txt in model["closing"]:  # am.368
        story += [Spacer(1, gap_tiny), Paragraph((f"<b>{_lab}</b>" if _lab else "") + _txt, _sub_tabel388)]
    if measure_only:
        total_height = 0.0
        for flowable in story:
            try:
                _, h = flowable.wrap(doc.width, doc.height)
                total_height += float(h)
            except Exception:
                # Un flowable nemăsurabil nu invalidează estimarea; se ignoră.
                continue
        return {"content_height": total_height, "page_height": float(doc.height)}

    doc.build(story)
    return {"pages": getattr(doc, "page", 1)}


# Praguri de layout. `MIN_LAST_PAGE_FILL` este fracțiunea minimă din înălțimea
# utilă pe care ultima pagină trebuie să o ocupe pentru a fi considerată o
# pagină legitimă. Sub acest prag se încearcă recuperarea prin compactare.
MIN_LAST_PAGE_FILL = 0.28
COMPACT_STEPS = (1.0, 0.94, 0.88, 0.82, 0.76, 0.70)


def _choose_compact_factor(data: Dict[str, Any], logo_path: Path, model: Dict[str, Any] | None = None) -> Tuple[float, Dict[str, Any]]:
    """Alege cel mai puțin agresiv factor de compactare care evită o ultimă
    pagină aproape goală. Returnează (factor, diagnostic)."""
    diagnostic: Dict[str, Any] = {"steps": []}
    sink = Path(tempfile.gettempdir()) / "m1c01_layout_probe.pdf"
    for factor in COMPACT_STEPS:
        try:
            measured = _pdf_generator(data, sink, logo_path, compact=factor, measure_only=True, model=model)
        except Exception as exc:
            diagnostic["steps"].append({"compact": factor, "error": str(exc)})
            continue
        content = measured["content_height"]
        page = measured["page_height"]
        if page <= 0:
            break
        pages = max(1, math.ceil(content / page))
        last_fill = (content - (pages - 1) * page) / page if pages >= 1 else 1.0
        step = {"compact": factor, "estimated_pages": pages, "last_page_fill": round(last_fill, 4)}
        diagnostic["steps"].append(step)
        if pages == 1 or last_fill >= MIN_LAST_PAGE_FILL:
            diagnostic["selected"] = factor
            diagnostic["reason"] = "PAGINA_FINALA_ACCEPTABILA" if pages > 1 else "INCAPE_PE_O_PAGINA"
            return factor, diagnostic
    # Nicio treaptă nu produce o ultimă pagină acceptabilă: păstrăm aspectul
    # normal și lăsăm ruptura, dar fără compactare inutilă a lizibilității.
    diagnostic["selected"] = 1.0
    diagnostic["reason"] = "RUPTURA_INEVITABILA_FARA_COMPACTARE"
    return 1.0, diagnostic


def _pdf_generator_autofit(data: Dict[str, Any], output_path: Path, logo_path: Path,
                           chosen: Tuple[float, Dict[str, Any]] | None = None, model: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Punct de intrare pentru generarea PDF. Alege factorul de layout, apoi desenează.

    PATCH V4.17 (am.135b): dacă numărul real de pagini depășește estimarea (estimarea măsoară înălțimea conținutului,
    nu ruperile reale de tabel), se încearcă treptele următoare de compactare până când paginile reale ajung la
    estimare; altfel se păstrează prima variantă. Nu se schimbă niciun text — doar spațierea verticală."""
    factor, diagnostic = chosen if chosen is not None else _choose_compact_factor(data, logo_path, model=model)
    result = _pdf_generator(data, output_path, logo_path, compact=factor, model=model)
    diagnostic["applied_compact"] = factor
    diagnostic["actual_pages"] = result.get("pages")
    estimated = next((st.get("estimated_pages") for st in diagnostic.get("steps", []) if st.get("compact") == factor), None)
    if estimated is not None and (result.get("pages") or 0) > estimated and diagnostic.get("reason") != "RUPTURA_INEVITABILA_FARA_COMPACTARE":
        retries = []
        for nxt in [f for f in COMPACT_STEPS if f < factor]:
            r2 = _pdf_generator(data, output_path, logo_path, compact=nxt, model=model)
            retries.append({"compact": nxt, "actual_pages": r2.get("pages")})
            if (r2.get("pages") or 0) <= estimated:
                diagnostic["applied_compact"] = nxt
                diagnostic["actual_pages"] = r2.get("pages")
                diagnostic["retry_reason"] = "PAGINI_REALE_PESTE_ESTIMARE"
                break
        else:
            # nicio treaptă nu aduce paginile reale la estimare → ruptura e inevitabilă: fără compactare inutilă
            # (aceeași filosofie ca în _choose_compact_factor), iar QA-ul aplică regula ultimei pagini (tichet 15.08.2026)
            r0 = _pdf_generator(data, output_path, logo_path, compact=1.0, model=model)
            diagnostic["applied_compact"] = 1.0
            diagnostic["actual_pages"] = r0.get("pages")
            diagnostic["reason"] = "RUPTURA_INEVITABILA_FARA_COMPACTARE"
            diagnostic["retry_reason"] = "PAGINI_REALE_PESTE_ESTIMARE_LA_TOATE_TREPTELE"
        diagnostic["retries"] = retries
    return diagnostic


def _extract_docx_text(path: Path) -> str:
    from docx import Document
    doc = Document(path)
    parts = []
    for p in doc.paragraphs:
        parts.append(p.text)
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                parts.append(cell.text)
    return "\n".join(parts)


def _pdf_reader_backend() -> str:
    """Alege extractorul PDF disponibil. PyMuPDF este preferat; pypdf este suficient."""
    try:
        import fitz  # noqa: F401
        return "PyMuPDF"
    except Exception:
        pass
    try:
        import pypdf  # noqa: F401
        return "pypdf"
    except Exception:
        return "none"


def _inspect_pdf_layout_pypdf(path: Path) -> Dict[str, Any]:
    """Degradare fără PyMuPDF. Numărul de pagini, textul și imaginile sunt exacte;
    acoperirea verticală este estimată din volumul de text, nu din coordonate."""
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    text = ""
    near_empty_pages: List[int] = []
    page_image_counts: List[int] = []
    body_coverage: List[float] = []
    total = len(reader.pages)
    for i, page in enumerate(reader.pages):
        txt = page.extract_text() or ""
        text += txt + "\n"
        try:
            resources = page.get("/Resources") or {}
            xobjects = resources.get("/XObject")
            if xobjects is None:
                page_image_counts.append(0)
            else:
                xobjects = xobjects.get_object()
                page_image_counts.append(
                    sum(1 for k in xobjects if xobjects[k].get_object().get("/Subtype") == "/Image")
                )
        except Exception:
            page_image_counts.append(0)
        compact_len = len(re.sub(r"\s+", "", txt))
        # Estimare de acoperire: raportul dintre volumul de text al paginii și
        # volumul tipic al unei pagini pline din acest layout (~2900 caractere).
        coverage = max(0.0, min(1.0, compact_len / 2400.0))
        body_coverage.append(round(coverage, 4))
        if compact_len < 120 or (total > 1 and coverage < 0.20 and compact_len < 500):
            near_empty_pages.append(i + 1)
    return {
        "text": text,
        "page_count": total,
        "near_empty_pages": near_empty_pages,
        "page_image_counts": page_image_counts,
        "body_coverage": body_coverage,
    }


def _inspect_pdf_layout(path: Path) -> Dict[str, Any]:
    backend = _pdf_reader_backend()
    if backend == "pypdf":
        return _inspect_pdf_layout_pypdf(path)
    if backend == "none":
        raise RuntimeError(
            "Nu există extractor PDF disponibil. Instalați PyMuPDF sau pypdf."
        )
    import fitz

    pdf = fitz.open(path)
    text = ""
    near_empty_pages: List[int] = []
    page_image_counts: List[int] = []
    body_coverage: List[float] = []
    for i, page in enumerate(pdf):
        txt = page.get_text("text")
        text += txt + "\n"
        page_image_counts.append(len(page.get_images(full=True)))
        words = page.get_text("words")
        h = float(page.rect.height)
        body_words = [w for w in words if w[1] > 55 and w[3] < h - 60]
        if body_words:
            ymin = min(w[1] for w in body_words)
            ymax = max(w[3] for w in body_words)
            coverage = max(0.0, min(1.0, (ymax - ymin) / h))
        else:
            coverage = 0.0
        body_coverage.append(round(coverage, 4))
        compact_len = len(re.sub(r"\s+", "", txt))
        # A multipage page is near-empty only when both its vertical coverage
        # and substantive text volume are low. This prevents false FAIL on
        # valid combined sale + mortgage offers whose second page is compact.
        if compact_len < 120 or (len(pdf) > 1 and coverage < 0.20 and compact_len < 500):
            near_empty_pages.append(i + 1)
    return {
        "text": text,
        "page_count": len(pdf),
        "near_empty_pages": near_empty_pages,
        "page_image_counts": page_image_counts,
        "body_coverage": body_coverage,
    }


def _render_docx_to_pdf_for_qa(docx_path: Path) -> Tuple[Path | None, str | None]:
    office = shutil.which("libreoffice") or shutil.which("soffice")
    if not office:
        return None, "LibreOffice/soffice indisponibil"
    tmp_root = Path(tempfile.mkdtemp(prefix="m1c01_docx_qa_"))
    out_dir = tmp_root / "out"
    out_dir.mkdir(parents=True, exist_ok=True)
    home_dir = tmp_root / "home"
    home_dir.mkdir(parents=True, exist_ok=True)
    profile = tmp_root / "profile"
    env = dict(os.environ)
    env["HOME"] = str(home_dir)
    cmd = [
        office,
        "--headless",
        f"-env:UserInstallation=file://{profile}",
        "--convert-to",
        "pdf",
        "--outdir",
        str(out_dir),
        str(docx_path),
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=90, env=env)
    except Exception as exc:
        return None, f"Randare DOCX eșuată: {exc}"
    rendered = out_dir / f"{docx_path.stem}.pdf"
    if proc.returncode != 0 or not rendered.exists() or rendered.stat().st_size == 0:
        msg = (proc.stderr or proc.stdout or "randare fără rezultat").strip()
        return None, f"Randare DOCX eșuată: {msg}"
    return rendered, None


def _tail_break_tolerated(layout_diagnostic: Dict[str, Any] | None,
                          near_empty_pages: List[int], page_count: int,
                          body_coverage: List[float]) -> bool:
    """PATCH V3.2 (tichet 15.08.2026, run M1C01_RUN_20260815T100959759168Z_9615a630d5):
    cand autofit-ul a demonstrat ca ruptura de pagina e INEVITABILA (nicio treapta de
    compactare 1.0->0.70 nu incape si nu atinge pragul ultimei pagini), o ULTIMA pagina
    sub pragul de umplere nu mai respinge o oferta corecta - conditii stricte:
    (1) diagnosticul autofit poarta exact motivul RUPTURA_INEVITABILA_FARA_COMPACTARE;
    (2) singura pagina aproape goala e ULTIMA;
    (3) acoperirea ei e >= 0.10 (o pagina practic goala ramane FAIL).
    Orice alta pagina aproape goala (prima, una din mijloc, mai multe) ramane FAIL."""
    if not layout_diagnostic:
        return False
    if layout_diagnostic.get("reason") != "RUPTURA_INEVITABILA_FARA_COMPACTARE":
        return False
    if not near_empty_pages or near_empty_pages != [page_count] or page_count < 2:
        return False
    tail_cov = body_coverage[-1] if body_coverage else 0.0
    return tail_cov >= 0.10


def _qa(data: Dict[str, Any], docx_path: Path, pdf_path: Path, email_docx_path: Path,
        layout_diagnostic: Dict[str, Any] | None = None) -> Dict[str, Any]:
    _scope = _offer_scope(data)  # PATCH V4.17 (am.135)
    expected = []
    totals = data.get("totals", {})
    if _scope == "both":
        for key in ("buyer_without_optional_notation", "buyer_with_optional_notation", "seller_tax_1", "seller_tax_3", "seller_total", "seller"):
            if totals.get(key) is not None:
                value = num(totals[key])
                if value not in expected:
                    expected.append(value)
    else:
        expected = _expected_totals(data, _scope)
    comps = data.get("components", {})
    has_ante = "antecontract" in comps
    has_mortgage = "mortgage" in comps
    standalone_ante = has_ante and "sale" not in comps and not has_mortgage and "opinion" not in comps and "radiere" not in comps
    standalone_opinion = (("opinion" in comps or "radiere" in comps) and all(a in ("opinion", "radiere") for a in comps))
    standalone_mortgage = "mortgage" in comps and len(comps) == 1
    sale_seller = (comps.get("sale") or {}).get("seller", {}) or {}

    docx_text = _extract_docx_text(docx_path)
    renderer = _pdf_reader_backend()
    try:
        pdf_layout = _inspect_pdf_layout(pdf_path)
    except Exception as exc:
        return {"status": "FAIL", "error": f"PDF text/layout extraction failed: {exc}"}

    pdf_text = pdf_layout["text"]
    page_count = pdf_layout["page_count"]
    near_empty_pages = pdf_layout["near_empty_pages"]
    page_image_counts = pdf_layout["page_image_counts"]
    body_coverage = pdf_layout["body_coverage"]

    docx_rendered_pdf, docx_render_error = _render_docx_to_pdf_for_qa(docx_path)
    docx_page_count = 0
    docx_near_empty_pages: List[int] = []
    docx_body_coverage: List[float] = []
    if docx_rendered_pdf is not None:
        try:
            docx_layout = _inspect_pdf_layout(docx_rendered_pdf)
            docx_page_count = docx_layout["page_count"]
            docx_near_empty_pages = docx_layout["near_empty_pages"]
            docx_body_coverage = docx_layout["body_coverage"]
        except Exception as exc:
            docx_render_error = f"Inspecție randare DOCX eșuată: {exc}"

    combined = docx_text + "\n" + pdf_text
    combined_lower = combined.lower()
    missing_docx = [x for x in expected if x not in docx_text]
    missing_pdf = [x for x in expected if x not in pdf_text]
    # PATCH V4.15 (am.130, T8, 26.08.2026 — TIC-017 Vasile–Chen): tokenii interni se caută pe CUVÂNT ÎNTREG (limite de cuvânt),
    # nu ca substring — «BARCA»/«BÂRCĂ»/«MARCA» nu mai declanșează fals pozitiv pe «RC». Frazele multi-cuvânt rămân pe potrivire exactă.
    bad_tokens = [x for x in ("ENGINE", "SHADOW", "RC", "draft tehnic", "CALCULATION_PASS_INTERNAL_DRAFT")
                  if re.search(r"(?<![0-9A-Za-zĂÂÎȘȚăâîșț_])" + re.escape(x.lower()) + r"(?![0-9A-Za-zĂÂÎȘȚăâîșț_])", combined_lower)]
    bad_glyphs = any(ch in pdf_text for ch in ("■", "�"))
    required_phrases = ["OFERTĂ DE PREȚ", "REZUMAT EXECUTIV", "Client", "Observații"] + (["Broker"] if _broker_included(data) else [])
    missing_phrases = [p for p in required_phrases if p.lower() not in combined_lower]

    forbidden_phrases: List[str] = []
    any_notation_present = any(
        str((comps.get(act) or {}).get(key, "0")) not in ("0", "0.00", "None")
        for act, key in (
            ("opinion", "land_book_notation"),
            ("antecontract", "optional_notation"),
            ("sale", "land_book_notation"),
            ("mortgage", "land_book_notation"),
            # V4.14 (am.110): radierea NU mai poarta cuvantul «notare» — randul ei spune «radiere»; «notare» ramane interzis fara alt act
        )
    )
    any_notation_present = any_notation_present or any(str(s.get("catalog_key") or s.get("key")) == "service_land_book_notations" for s in ((data.get("services") or []) + (data.get("services_seller") or [])))  # am.133 + am.169
    branch_required: List[str] = []  # (mutat inainte de am.169)
    _ext_ded = str(((data.get("components") or {}).get("sale") or {}).get("antecontract_deduction_source") or "") == "operator_extern"  # am.169
    if not has_ante and not _ext_ded:
        forbidden_phrases.append("antecontract")
    elif not has_ante and _ext_ded:
        # am.169: randul «Deducere onorariu antecontract achitat anterior» e singura aparitie permisa a cuvantului fara antecontract in calcul
        branch_required.append("Deducere onorariu antecontract achitat anterior")
        if not any_notation_present:
            forbidden_phrases.append("notare")
    if not has_mortgage:
        forbidden_phrases.extend(["vânzare + ipotecă", "contract de ipotecă"])
    if sale_seller.get("tax") is not None:
        pct = str(sale_seller.get("tax_percent"))
        if pct == "1":
            forbidden_phrases.extend(["impozit 3%", "variantele de impozit de 1% și 3%"])
        elif pct == "3":
            forbidden_phrases.extend(["impozit 1%", "variantele de impozit de 1% și 3%"])
    if standalone_ante:
        branch_required.extend([
            "Promitent-cumpărător",
            "Promitent-vânzător",
            "CAPITOLUL 1 - COSTURI PROMITENT-CUMPĂRĂTOR",
            "CAPITOLUL 2 - TOTAL GENERAL PROMITENT-CUMPĂRĂTOR",
            "CAPITOLUL 3 - COSTURI PROMITENT-VÂNZĂTOR",
            "Onorariul net al antecontractului se deduce ulterior",
        ])
        forbidden_phrases.extend(["CAPITOLUL 5 - TOTAL GENERAL CUMPĂRĂTOR", "CAPITOLUL 6A"])
    if standalone_opinion:
        branch_required.extend([
            "Solicitant",
            "TOTAL SOLICITANT",
            "TOTAL GENERAL SOLICITANT",
        ])
        if "opinion" in comps:
            branch_required.append("CAPITOLUL 1 - OPINIE NOTARIALĂ")
        if "radiere" in comps:
            branch_required.append("DECLARAȚIE DE RADIERE")
        forbidden_phrases.extend([
            "TOTAL CUMPĂRĂTOR",
            "TOTAL GENERAL CUMPĂRĂTOR",
            "CAPITOLUL 5 - TOTAL GENERAL CUMPĂRĂTOR",
            "Vânzător",
        ])
    if standalone_mortgage:
        branch_required.extend([
            "Contract de ipotecă / refinanțare",
            "Debitor / constituitor",
            "TOTAL DEBITOR / CONSTITUITOR",
            "CAPITOLUL 1 - COSTURI DEBITOR / CONSTITUITOR - CONTRACT DE IPOTECĂ / REFINANȚARE",
            "CAPITOLUL 2 - TOTAL GENERAL DEBITOR / CONSTITUITOR",
            "TOTAL GENERAL DEBITOR / CONSTITUITOR",
            "Extras de autentificare",
            "Verificări procuri bancare",
            "Legalizare procură bancară",
            "Taxă OCPI",
        ])
        forbidden_phrases.extend([
            "TOTAL CUMPĂRĂTOR",
            "TOTAL GENERAL CUMPĂRĂTOR",
            "CAPITOLUL 5 - TOTAL GENERAL CUMPĂRĂTOR",
            "Vânzător",
        ])
    # PATCH V4.17 (am.135): pe oferta individuală capitolele sunt renumerotate și cealaltă parte lipsește cu totul
    if _scope != "both":
        branch_required = [p for p in branch_required if not p.upper().startswith("CAPITOLUL ") and _party_of_label(p) == _scope]
        forbidden_phrases = [p for p in forbidden_phrases if not p.upper().startswith("CAPITOLUL ")]
        if _scope == "buyer":
            forbidden_phrases.extend(["TOTAL VÂNZĂTOR", "COSTURI VÂNZĂTOR", "PROMITENT-VÂNZĂTOR", "Impozit -", "TOTAL GENERAL VÂNZĂTOR", "Variantele de impozit"])
            branch_required.append("TOTAL GENERAL SOLICITANT" if standalone_opinion else ("TOTAL GENERAL DEBITOR / CONSTITUITOR" if standalone_mortgage else ("TOTAL GENERAL PROMITENT-CUMPĂRĂTOR" if standalone_ante else "TOTAL GENERAL CUMPĂRĂTOR")))
        else:
            forbidden_phrases.extend(["TOTAL CUMPĂRĂTOR", "COSTURI CUMPĂRĂTOR", "TOTAL GENERAL CUMPĂRĂTOR", "PROMITENT-CUMPĂRĂTOR", "SERVICII SUPLIMENTARE", "DEBITOR / CONSTITUITOR", "TOTAL SOLICITANT", "Taxă opțională de notare"])
            branch_required.append("PROMITENT-VÂNZĂTOR" if standalone_ante else "VÂNZĂTOR")
    if not _broker_included(data):
        forbidden_phrases.append("Broker")
    forbidden_found = [p for p in forbidden_phrases if p.lower() in combined_lower]
    missing_branch_required = [p for p in branch_required if p.lower() not in combined_lower]

    semantic_parity = all(x in docx_text and x in pdf_text for x in expected)
    checks = {
        "docx_exists": docx_path.exists() and docx_path.stat().st_size > 0,
        "pdf_exists": pdf_path.exists() and pdf_path.stat().st_size > 0,
        "all_totals_in_docx": not missing_docx,
        "all_totals_in_pdf": not missing_pdf,
        "semantic_parity": semantic_parity,
        "no_internal_tokens": not bad_tokens,
        "no_broken_glyphs_detected": not bad_glyphs,
        "required_sections_present": not missing_phrases,
        "branch_specific_vocabulary": not forbidden_found and not missing_branch_required,
        "no_near_empty_pages": (not near_empty_pages) or _tail_break_tolerated(
            layout_diagnostic, near_empty_pages, page_count, body_coverage),
        "page_count_reasonable": 1 <= page_count <= 8,
        "docx_visual_qa_available": docx_render_error is None and docx_rendered_pdf is not None,
        "docx_no_near_empty_pages": docx_render_error is None and (
            (not docx_near_empty_pages) or _tail_break_tolerated(
                layout_diagnostic, docx_near_empty_pages, docx_page_count, docx_body_coverage)),
        "docx_page_count_reasonable": docx_render_error is None and 1 <= docx_page_count <= 8,
        "docx_pdf_page_count_parity": docx_render_error is None and (
            docx_page_count == page_count
            # am.135b: pe oferta individuală, când ruptura PDF-ului e inevitabilă (toate treptele) iar DOCX-ul compactat
            # încape cu o pagină mai puțin și fără coadă, diferența de o pagină e acceptată (conținutul: semantic_parity)
            or (_scope != "both" and docx_page_count == page_count - 1 and not docx_near_empty_pages
                and (layout_diagnostic or {}).get("reason") == "RUPTURA_INEVITABILA_FARA_COMPACTARE")),
        "logo_image_on_every_pdf_page": (all(x > 0 for x in page_image_counts) if page_image_counts and all(x >= 0 for x in page_image_counts) else True),
    }
    email_qa = _email_qa(data, email_docx_path)
    checks["email_docx_qa_pass"] = email_qa.get("status") == "PASS"
    return {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "email_qa": email_qa,
        "details": {
            "page_count": page_count,
            "pdf_text_extractor": renderer,
            "missing_totals_docx": missing_docx,
            "missing_totals_pdf": missing_pdf,
            "missing_required_phrases": missing_phrases,
            "internal_tokens_found": bad_tokens,
            "forbidden_phrases_found": forbidden_found,
            "missing_branch_required": missing_branch_required,
            "near_empty_pages": near_empty_pages,
            "near_empty_tail_tolerated": bool(near_empty_pages) and _tail_break_tolerated(
                layout_diagnostic, near_empty_pages, page_count, body_coverage),
            "docx_near_empty_tail_tolerated": bool(docx_near_empty_pages) and _tail_break_tolerated(
                layout_diagnostic, docx_near_empty_pages, docx_page_count, docx_body_coverage),
            "body_coverage_by_page": body_coverage,
            "docx_page_count": docx_page_count,
            "docx_near_empty_pages": docx_near_empty_pages,
            "docx_body_coverage_by_page": docx_body_coverage,
            "docx_render_error": docx_render_error,
            "page_image_counts": page_image_counts,
        },
        "offer_for": _scope,
        "include_broker": _broker_included(data),
        "core_modified": False,
        "automatic_send": False,
        "automatic_propagation": False,
        "human_approval_required": True,
    }



# ---------------------------------------------------------------------------------------------------------------------
# PATCH V4.25 (am.367, R-FORMAT-OFERTA, titular 09.09.2026): FORMATUL SCURT al ofertei — litera titularului
# («oferta_minimalista_taxe_vanzare.docx»), pe langa oferta completa (care se produce si se verifica in continuare).
# Aceleasi sume, acelasi ENGINE_RESULT / run_id. Trei fisiere: `<basename>_SCURT.docx`, `<basename>_SCURT.pdf`
# (DOCX randat prin LibreOffice — fara LibreOffice cade fail-closed), `EMAIL_SCURT_M1-C01.docx`.
# Abateri de la litera minimalista, declarate (TIC-T55Z-OFERTA-SCURTA-LITERA): serviciile/taxele cerute explicit de operator
# si randul de TOTAL pe parte. am.368 (titular 09.09.2026): randul arhivarii IESE; suma ramane in «Onorariu + TVA».
# ---------------------------------------------------------------------------------------------------------------------
_MENTIUNE_SCURT_1 = ("Sumele de mai sus sunt estimative și sunt calculate pe baza informațiilor comunicate la data ofertei. "
                     "Calculul final se va efectua la cursul BNR aplicabil la data autentificării.")
_MENTIUNE_SCURT_2 = ("În funcție de situația juridică a imobilului și de particularitățile dosarului, pot deveni aplicabile și alte "
                     "costuri aferente unor operațiuni sau verificări suplimentare, inclusiv taxe datorate ANCPI, Camerei Notarilor "
                     "ori altor instituții. Dacă astfel de costuri sunt necesare, acestea vor fi comunicate înainte de semnare.")


def _vat_label(comp: Dict[str, Any]) -> str:
    """Eticheta TVA din cifrele motorului (21% pe onorariu + arhivare); fara baza -> «TVA»."""
    try:
        base = float(str(comp.get("honorarium_net") or 0)) + float(str(comp.get("archive") or 0))
        vat = float(str(comp.get("vat") or 0))
        if base > 0:
            return f"TVA {round(vat / base * 100):d}%"
    except Exception:
        pass
    return "TVA"


def _short_offer_model(data: Dict[str, Any]) -> Dict[str, Any]:
    """Modelul ofertei scurte: sectiuni [(titlu, [(eticheta, mod_de_calcul, suma_text, bold)])], antet si totaluri asteptate (QA).
    am.368: fara randul «Taxa de arhivare» — arhivarea ramane in suma «Onorariu + TVA» (totalul inchide cu motorul)."""
    cfg = data.get("configuration", {}) or {}
    comps = data.get("components", {}) or {}
    totals = data.get("totals", {}) or {}
    fx = cfg.get("fx", {}) or {}
    acts = list(cfg.get("acts", []) or [])
    scope = _offer_scope(data)
    currency = cfg.get("currency", "RON")
    sections: List[Tuple[str, List[Tuple[str, str, bool]]]] = []
    expected: List[str] = []

    def _exp(v: Any) -> None:
        if v is None:
            return
        t = num(v)
        if t not in expected:
            expected.append(t)

    def _sum(*vals: Any) -> str:
        return format(sum((_D(str(v or "0")) for v in vals), _D("0")), "f")

    header: List[str] = [f"Acte: {_acts_title(acts)}"]
    if "sale" in comps:
        if currency == "EUR" and fx.get("rate"):
            eur = float(str(comps["sale"].get("price_lei"))) / float(str(fx.get("rate")))
            header.append(f"Prețul vânzării: {eur:,.0f}".replace(",", ".") + f" {currency} (curs BNR {fx.get('rate')} lei/{currency})")
        else:
            header.append(f"Prețul vânzării: {money(comps['sale'].get('price_lei'))}")
    if "mortgage" in comps and scope != "seller":
        if currency == "EUR" and fx.get("rate"):
            eur = float(str(comps["mortgage"].get("credit_lei"))) / float(str(fx.get("rate")))
            header.append(f"Creditul: {eur:,.0f}".replace(",", ".") + f" {currency}")
        else:
            header.append(f"Creditul: {money(comps['mortgage'].get('credit_lei'))}")

    # ---------------- CUMPARATOR / SOLICITANT ----------------
    if scope != "seller":
        if "sale" in comps:
            c = comps["sale"]
            rows: List[Tuple[str, str, str, bool]] = [
                ("Onorariu notarial", "potrivit tranșei aplicabile valorii în lei", money(c.get("honorarium_net")), False),
                (_vat_label(c), "la onorariu și arhivare", money(c.get("vat")), False),
                ("Onorariu + TVA", "onorariu, arhivare și TVA", money(_sum(c.get("honorarium_net"), c.get("archive"), c.get("vat"))), True),
                ("Taxă OCPI pentru intabularea dreptului de proprietate", "0,15% PF / 0,5% PJ din preț", money(c.get("ancpi")), False),
            ]
            if c.get("buyer_verification") not in (None, "0", "0.00"):
                q = c.get("buyer_verification_quantity")
                rows.append(("Verificare regim matrimonial cumpărător", f"{q} × {money(c.get('buyer_verification_unit'))}", money(c.get("buyer_verification")), False))
            if c.get("land_book_notation") not in (None, "0", "0.00"):
                rows.append(("Taxă notare în cartea funciară", f"{c.get('notation_quantity')} × {money(c.get('notation_unit'))}", money(c.get("land_book_notation")), False))
            rows.append(("Subtotal contract de vânzare", "", money(c.get("buyer_total")), True)); _exp(c.get("buyer_total"))
            sections.append(("Cumpărător", rows))
        if "mortgage" in comps:
            c = comps["mortgage"]
            rows = [
                ("Onorariu notarial", "potrivit tranșei aplicabile valorii creditului", money(c.get("honorarium_net")), False),
                (_vat_label(c), "la onorariu și arhivare", money(c.get("vat")), False),
                ("Onorariu + TVA", "onorariu, arhivare și TVA", money(_sum(c.get("honorarium_net"), c.get("archive"), c.get("vat"))), True),
                ("Taxă OCPI pentru înscrierea ipotecii", "tarif ANCPI", money(c.get("ocpi")), False),
            ]
            for key, label, qkey, ukey in (("bank_proxy_checks", "Verificări procuri bancare", "bank_proxy_check_quantity", "bank_proxy_check_unit"),
                                            ("bank_proxy_legalization", "Legalizări copii procuri bancare", "legalized_copy_quantity", "legalized_copy_unit"),
                                            ("buyer_verification", "Verificare regim matrimonial debitor", "buyer_verification_quantity", "buyer_verification_unit"),
                                            ("authentication_extract", "Extras de carte funciară pentru autentificare", "authentication_extract_quantity", "authentication_extract_unit"),
                                            ("additional_collateral_property_fee", "Imobile suplimentare în garanție", "additional_collateral_property_quantity", "additional_collateral_property_unit"),
                                            ("land_book_notation", "Taxă notare în cartea funciară", "notation_quantity", "notation_unit")):
                if c.get(key) not in (None, "0", "0.00"):
                    rows.append((label, f"{c.get(qkey)} × {money(c.get(ukey))}", money(c.get(key)), False))
            rows.append(("Subtotal contract de ipotecă", "", money(c.get("buyer_total")), True)); _exp(c.get("buyer_total"))
            sections.append(("Contract de ipotecă", rows))
        if "opinion" in comps:
            c = comps["opinion"]
            rows = [("Opinie notarială, dacă este solicitată de bancă", "onorariu + TVA", f"{money(c.get('honorarium_net'))} + TVA {money(c.get('vat'))}", False)]
            if c.get("information_extract") not in (None, "0", "0.00"):
                rows.append(("Extrase de informare", f"{c.get('information_extract_quantity')} × {money(c.get('information_extract_unit'))}", money(c.get("information_extract")), False))
            if c.get("land_book_notation") not in (None, "0", "0.00"):
                rows.append(("Taxă notare în cartea funciară", f"{c.get('notation_quantity')} × {money(c.get('notation_unit'))}", money(c.get("land_book_notation")), False))
            rows.append(("Total opinie notarială", "", money(c.get("total")), True))
            _exp(c.get("total"))
            sections.append(("Opinie notarială", rows))
        c = comps.get("antecontract")
        if isinstance(c, dict):
            rows = [("Onorariu notarial", "1% din suma achitată, minimum operațional 500 lei", money(c.get("honorarium_net")), False)]
            rows.append((_vat_label(c), "la onorariu și arhivare" if c.get("archive") not in (None, "0", "0.00") else "aplicată onorariului", money(c.get("vat")), False))
            rows.append(("Onorariu + TVA", "onorariu, arhivare și TVA" if c.get("archive") not in (None, "0", "0.00") else "onorariu și TVA", money(_sum(c.get("honorarium_net"), c.get("archive"), c.get("vat"))), True))
            if c.get("buyer_verification") not in (None, "0", "0.00"):
                rows.append(("Verificare regim matrimonial promitent-cumpărător", f"{c.get('buyer_verification_quantity')} × {money(c.get('buyer_verification_unit'))}", money(c.get("buyer_verification")), False))
            rows.append(("Subtotal antecontract — fără notarea în cartea funciară", "", money(c.get("buyer_without_notation")), True)); _exp(c.get("buyer_without_notation"))
            if c.get("optional_notation") not in (None, "0", "0.00"):
                rows.append(("Notarea antecontractului în cartea funciară, opțional", f"{c.get('notation_quantity')} × {money(c.get('notation_unit'))}", money(c.get("optional_notation")), False))
                rows.append(("Subtotal antecontract — cu notare", "", money(c.get("buyer_with_notation")), True)); _exp(c.get("buyer_with_notation"))
            sections.append(("Antecontract de vânzare (promitent-cumpărător)", rows))
        c = comps.get("radiere")
        if isinstance(c, dict) and str(c.get("party") or "buyer") != "seller":
            rows = [("Onorariu notarial", "tarif standard", money(c.get("honorarium_net")), False), (_vat_label(c), "aplicată onorariului", money(c.get("vat")), False)]
            if c.get("information_extract") not in (None, "0", "0.00"):
                rows.append(("Extrase de informare", f"{c.get('information_extract_quantity')} × {money(c.get('information_extract_unit'))}", money(c.get("information_extract")), False))
            for _l, _n, _v in _ancpi_radiere_randuri_am374(c):  # PATCH V4.27 (am.374)
                rows.append((_l, _n, money(_v), False))
            rows.append(("Total declarație de radiere", "", money(c.get("total")), True)); _exp(c.get("total"))
            sections.append(("Declarație de radiere", rows))
        svs = data.get("services") or []
        afs = [a for a in (comps.get("additional_fees") or []) if str(a.get("party") or "buyer") != "seller"]
        if svs or afs:
            rows = []
            for s in svs:
                rows.append((str(s.get("label")), f"{s.get('quantity')} × {money(s.get('unit_amount'))}", money(s.get("amount")), False))
            for a in afs:
                rows.append((str(a.get("label")), "declarată de operator", money(a.get("amount")), False))
            sections.append(("Servicii și taxe suplimentare", rows))
        bw = totals.get("buyer_without_optional_notation")
        bwn = totals.get("buyer_with_optional_notation")
        if bw is not None:
            who = "debitor" if set(acts) == {"mortgage"} else ("solicitant" if set(acts) <= {"opinion", "radiere"} else "cumpărător")
            if bwn is not None and str(bwn) != str(bw):
                sections.append((f"Total estimativ {who}", [(f"TOTAL ESTIMATIV {who.upper()} — FĂRĂ NOTAREA ANTECONTRACTULUI", "", money(bw), True), (f"TOTAL ESTIMATIV {who.upper()} — CU NOTAREA ANTECONTRACTULUI", "", money(bwn), True)]))
                _exp(bw); _exp(bwn)
            else:
                sections.append((f"Total estimativ {who}", [(f"TOTAL ESTIMATIV {who.upper()}", "", money(bw), True)]))
                _exp(bw)

    # ---------------- VANZATOR ----------------
    if scope != "buyer":
        rows = []
        if "sale" in comps and isinstance(comps["sale"].get("seller"), dict):
            s = comps["sale"]["seller"]
            if s.get("authentication_extract") not in (None, "0", "0.00"):
                rows.append(("Extras de carte funciară pentru autentificare", f"{s.get('authentication_extract_quantity')} × {money(s.get('authentication_extract_unit'))} / fiecare număr cadastral", money(s.get("authentication_extract")), False))
            if s.get("information_extract") not in (None, "0", "0.00"):
                rows.append(("Extrase de informare", f"{s.get('information_extract_quantity')} × {money(s.get('information_extract_unit'))}", money(s.get("information_extract")), False))
            if s.get("seller_verification") not in (None, "0", "0.00"):
                rows.append(("Verificare regim matrimonial vânzător", f"{s.get('seller_verification_quantity')} × {money(s.get('seller_verification_unit'))}", money(s.get("seller_verification")), False))
            if s.get("tax_shares"):
                rows.append(("Impozit datorat statului pentru transferul proprietății", f"MIXT pe cote ({s.get('tax_percent_label')})", money(s.get("tax")), False))
            elif s.get("tax") is not None:
                rows.append(("Impozit datorat statului pentru transferul proprietății", f"{s.get('tax_percent')}% din preț", money(s.get("tax")), False))
            else:
                if s.get("tax_1") is not None:
                    rows.append(("Impozit pentru transferul proprietății — varianta 1%", "imobil deținut peste 3 ani", money(s.get("tax_1")), False))
                if s.get("tax_3") is not None:
                    rows.append(("Impozit pentru transferul proprietății — varianta 3%", "imobil deținut sub 3 ani", money(s.get("tax_3")), False))
        c = comps.get("antecontract")
        if isinstance(c, dict) and c.get("seller_total") is not None:
            rows.append(("Antecontract — costuri vânzător", "detaliat în varianta completă", money(c.get("seller_total")), False))
        for s in (data.get("services_seller") or []):
            rows.append((str(s.get("label")), f"{s.get('quantity')} × {money(s.get('unit_amount'))}", money(s.get("amount")), False))
        for a in [a for a in (comps.get("additional_fees") or []) if str(a.get("party") or "buyer") == "seller"]:
            rows.append((str(a.get("label")), "declarată de operator", money(a.get("amount")), False))
        r = comps.get("radiere")
        if isinstance(r, dict) and str(r.get("party") or "buyer") == "seller":
            rows.append(("Declarație de radiere (vânzător)", "onorariu + TVA + extras + taxa ANCPI de radiere", money(r.get("total")), False))
        if totals.get("seller") is not None and totals.get("seller_tax_1") is None:
            rows.append(("TOTAL ESTIMATIV VÂNZĂTOR", "", money(totals.get("seller")), True)); _exp(totals.get("seller"))
        else:
            if totals.get("seller_tax_1") is not None:
                rows.append(("TOTAL ESTIMATIV VÂNZĂTOR — VARIANTA 1%", "", money(totals.get("seller_tax_1")), True)); _exp(totals.get("seller_tax_1"))
            if totals.get("seller_tax_3") is not None:
                rows.append(("TOTAL ESTIMATIV VÂNZĂTOR — VARIANTA 3%", "", money(totals.get("seller_tax_3")), True)); _exp(totals.get("seller_tax_3"))
        if rows:
            sections.append(("Vânzător", rows))
    return {"header": header, "sections": sections, "expected": expected, "scope": scope}


def _short_layout_model(data: Dict[str, Any]) -> Dict[str, Any]:
    """am.388: modelul scurt al am.368, fara verificari (AM388_SCURT_FARA) — aceeasi forma pe PDF-ul scurt, DOCX-ul scurt si e-mailul scurt."""
    return _am388_fara_verificari(_short_layout_model_am368(data))


def _short_layout_model_am368(data: Dict[str, Any]) -> Dict[str, Any]:
    """am.368: modelul scurt in forma layoutului ofertei complete — antetul biroului, «Datele utilizate pentru calcul»
    (acelasi bloc de configurare: client, broker, parti, acte, moneda, curs, valori), tabele eticheta / mod de calcul / suma
    (randurile TOTAL* colorate ca in oferta completa), fara sinteza, Mentiunea verbatim a titularului in loc de Observatii."""
    m = _short_offer_model(data)
    sections: List[Tuple[str, List[Tuple[str, str, str]], str | None]] = []
    for title, rows in m["sections"]:
        sections.append((title, [(lab, mode, amt) for (lab, mode, amt, _b) in rows], None))
    return {"title": "OFERTĂ ORIENTATIVĂ DE COST", "subtitle": _acts_title(list((data.get("configuration") or {}).get("acts", []))),
            "cfg_rows": _configuration_rows(data), "summary": None, "sections": sections,
            "closing": [("Mențiune: ", _MENTIUNE_SCURT_1), ("", _MENTIUNE_SCURT_2)], "closing_size": 7.4,
            "expected": m["expected"], "scope": m["scope"]}


# am.388 (T56y, decizia titularului 10.09.2026): din varianta SCURTA (PDF-ul scurt = oferta.pdf si e-mailul scurt)
# pleaca verificarea regimului matrimonial (cumparator si vanzator) si, la ipoteca, verificarile si legalizarile procurilor
# bancare. Sumele NU se schimba (subtotalurile si totalurile raman cele calculate); PDF-ul extins si e-mailul complet sunt neatinse.
AM388_SCURT_FARA = ("Verificare regim matrimonial", "Verificări procuri bancare", "Legalizări copii procuri bancare")


def _am388_fara_verificari(model: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(model)
    sections = []
    for title, rows, extra in model["sections"]:
        rows2 = [r for r in rows if not str(r[0]).startswith(AM388_SCURT_FARA)]
        sections.append((title, rows2, extra))
    out["sections"] = sections
    return out


def _short_docx_generator(data: Dict[str, Any], output_path: Path, logo_path: Path, *, email: bool = False,
                          compact: float = 1.0) -> None:
    """am.368: oferta scurta (DOCX) prin `_docx_generator(model=scurt)`; e-mailul scurt prin `_email_docx_generator(short_model=)`."""
    model = _short_layout_model(data)
    if email:
        _email_docx_generator(data, output_path, logo_path, short_model=model)
    else:
        _docx_generator(data, output_path, logo_path, compact=compact, model=model)


def _short_qa(data: Dict[str, Any], docx_path: Path, pdf_path: Path, email_path: Path) -> Dict[str, Any]:
    """QA-ul setului scurt: toate totalurile partii in DOCX si in e-mail, fara tokeni interni, PDF randat, arhive DOCX intacte;
    am.368: PDF-ul scurt pe o singura pagina (`short_pdf_one_page`), randul arhivarii absent (`short_docx_no_archive_row`)."""
    import zipfile
    model = _short_offer_model(data)
    expected = list(model["expected"])
    for v in _expected_totals(data, model["scope"]):
        if v not in expected:
            expected.append(v)
    checks: Dict[str, bool] = {}
    details: Dict[str, Any] = {"expected_totals": expected}
    for name, path in (("docx", docx_path), ("email", email_path)):
        text = _extract_docx_text(path) if path.is_file() else ""
        lower = text.lower()
        missing = [v for v in expected if v not in text]
        forbidden = [t for t in ("ENGINE_RESULT", "PIPELINE_RESULT", "run_id", "CALCULATION_PASS_INTERNAL_DRAFT", "traceback") if t.lower() in lower]
        zip_ok = False
        try:
            with zipfile.ZipFile(path) as archive:
                zip_ok = archive.testzip() is None and "word/document.xml" in archive.namelist()
        except Exception:
            zip_ok = False
        checks[f"short_{name}_exists"] = path.is_file() and path.stat().st_size > 0
        checks[f"short_{name}_zip_integrity"] = zip_ok
        checks[f"short_{name}_totals_present"] = not missing
        checks[f"short_{name}_no_internal_tokens"] = not forbidden
        checks[f"short_{name}_mentiune_present"] = "Sumele de mai sus sunt estimative" in text
        checks[f"short_{name}_no_archive_row"] = "Taxă de arhivare" not in text  # am.368
        checks[f"short_{name}_data_block_present"] = ("Acte" in text) and ("Client" in text if name == "docx" else True)  # am.368
        details[f"short_{name}_missing_totals"] = missing
    checks["short_pdf_exists"] = pdf_path.is_file() and pdf_path.stat().st_size > 0
    try:
        checks["short_pdf_header_ok"] = pdf_path.read_bytes()[:5] == b"%PDF-"
    except Exception:
        checks["short_pdf_header_ok"] = False
    try:  # am.368: o singura pagina + totalurile partii in PDF
        _lay = _inspect_pdf_layout(pdf_path)
        checks["short_pdf_one_page"] = int(_lay.get("page_count") or 0) == 1
        _ptxt = str(_lay.get("text") or "")
        checks["short_pdf_totals_present"] = all(v in _ptxt for v in expected)
        details["short_pdf_pages"] = _lay.get("page_count")
    except Exception as exc:
        checks["short_pdf_one_page"] = False
        checks["short_pdf_totals_present"] = False
        details["short_pdf_error"] = str(exc)
    return {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "details": details}


def _generate_short_set(data: Dict[str, Any], out: Path, logo_path: Path, basename: str, email_name: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """am.368: produce setul scurt (DOCX + PDF + e-mail) pe layoutul ofertei complete, langa cea completa.
    PDF-ul prin `_pdf_generator_autofit` cu modelul scurt (acelasi desen ca oferta completa), nu DOCX -> LibreOffice."""
    docx_path = out / f"{basename}_SCURT.docx"
    pdf_path = out / f"{basename}_SCURT.pdf"
    email_path = out / email_name
    model = _short_layout_model(data)
    chosen = _choose_compact_factor(data, logo_path, model=model)
    layout_diagnostic = _pdf_generator_autofit(data, pdf_path, logo_path, chosen=chosen, model=model)
    _short_docx_generator(data, docx_path, logo_path, email=False, compact=float(layout_diagnostic.get("applied_compact", 1.0)))
    _short_docx_generator(data, email_path, logo_path, email=True)
    qa = _short_qa(data, docx_path, pdf_path, email_path)
    qa.setdefault("details", {})["short_pdf_layout_autofit"] = layout_diagnostic
    paths = {"docx_scurt": str(docx_path), "pdf_scurt": str(pdf_path), "email_docx_scurt": str(email_path)}
    qa.update(paths)
    return qa, paths


def _generate_one(data: Dict[str, Any], out: Path, logo_path: Path, basename: str, email_name: str,
                  input_path: Path, offer_format: str = "complet") -> Tuple[Dict[str, Any], Dict[str, Any]]:
    docx_path = out / f"{basename}.docx"
    pdf_path = out / f"{basename}.pdf"
    email_docx_path = out / email_name
    chosen = _choose_compact_factor(data, logo_path)
    layout_diagnostic = _pdf_generator_autofit(data, pdf_path, logo_path, chosen=chosen)
    # am.135: pe oferta individuală DOCX-ul urmează factorul aplicat PDF-ului; pe both rămâne bit-identic cu V3.8
    _docx_factor = 1.0
    if _offer_scope(data) != "both":
        _docx_factor = float(layout_diagnostic.get("applied_compact", 1.0))
        if layout_diagnostic.get("retry_reason") == "PAGINI_REALE_PESTE_ESTIMARE_LA_TOATE_TREPTELE":
            _docx_factor = float(chosen[0])  # DOCX-ul (fără rupere de tabel) încape la factorul estimat; PDF-ul rămâne cu coadă tolerată
    _docx_generator(data, docx_path, logo_path, compact=_docx_factor)
    _email_docx_generator(data, email_docx_path, logo_path)
    qa = _qa(data, docx_path, pdf_path, email_docx_path, layout_diagnostic=layout_diagnostic)
    # PATCH V4.20 (am.169, fix de executie): pe oferta comuna DOCX-ul ramane la 1.0 (bit-identic) CAT TIMP incape; daca PDF-ul a fost
    # compactat iar DOCX-ul la 1.0 varsa o ultima pagina aproape goala, DOCX-ul urmeaza factorul PDF-ului (a doua incercare, apoi QA din nou)
    if (_offer_scope(data) == "both" and _docx_factor == 1.0 and qa.get("status") != "PASS"
            and qa.get("checks", {}).get("docx_no_near_empty_pages") is False
            and float(layout_diagnostic.get("applied_compact", 1.0)) < 1.0):
        _docx_factor = float(layout_diagnostic.get("applied_compact", 1.0))
        _docx_generator(data, docx_path, logo_path, compact=_docx_factor)
        qa = _qa(data, docx_path, pdf_path, email_docx_path, layout_diagnostic=layout_diagnostic)
        qa.setdefault("details", {})["docx_compact_retry"] = _docx_factor
    qa.setdefault("details", {})["pdf_layout_autofit"] = layout_diagnostic
    qa.update({"docx": str(docx_path), "pdf": str(pdf_path), "email_docx": str(email_docx_path), "source": str(input_path)})
    paths = {"docx": str(docx_path), "pdf": str(pdf_path), "email_docx": str(email_docx_path)}
    if offer_format == "scurt":  # am.367: setul scurt langa cel complet; QA-ul lui intra in verdict
        short_email = email_name.replace("EMAIL_REZUMAT_M1-C01", "EMAIL_SCURT_M1-C01")
        short_qa, short_paths = _generate_short_set(data, out, logo_path, basename, short_email)
        qa.setdefault("checks", {}).update(short_qa["checks"])
        qa.setdefault("details", {})["short_qa"] = short_qa["details"]
        if short_qa["status"] != "PASS":
            qa["status"] = "FAIL"
        qa.update(short_paths)
        paths.update(short_paths)
    return qa, paths


def generate(engine_result_path: str, output_dir: str = "/mnt/data", basename: str = "OFERTA_M1-C01_CANONICA",
             offer_for: str | None = None, include_broker: bool | None = None, offer_format: str | None = None) -> Dict[str, Any]:
    """PATCH V4.17 (am.135): `offer_for` ∈ {both, buyer, seller, split}; `include_broker` implicit True.
    both = un set de documente, bit-identic cu V3.8 (nume interne neschimbate);
    buyer / seller = un set de documente pe scope (nume interne neschimbate; sufixul îl pune orchestratorul la livrare);
    split = două seturi (`{basename}_CUMPARATOR.*` + `{basename}_VANZATOR.*`, e-mailurile sufixate la fel) dintr-un singur
    ENGINE_RESULT; cheile `docx/pdf/email_docx` ale rezultatului indică setul cumpărătorului, `documents` le listează pe ambele.
    """
    input_path = Path(engine_result_path)
    if not input_path.exists():
        raise FileNotFoundError(f"ENGINE_RESULT.json indisponibil: {input_path}")
    data = json.loads(input_path.read_text(encoding="utf-8"))
    if data.get("status") != "CALCULATION_PASS_INTERNAL_DRAFT":
        raise ValueError(f"Status motor neacceptat: {data.get('status')}")
    scope = str(offer_for or (data.get("configuration") or {}).get("offer_for") or "both").strip().lower()
    if scope not in OFFER_SCOPES:
        raise ValueError(f"offer_for neacceptat: {scope} (permise: {', '.join(OFFER_SCOPES)})")
    broker_on = True if include_broker is None else bool(include_broker)
    fmt = str(offer_format or (data.get("configuration") or {}).get("offer_format") or "complet").strip().lower()  # am.367
    if fmt not in ("scurt", "complet"):
        raise ValueError(f"offer_format neacceptat: {fmt} (permise: scurt, complet)")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    logo_path = _write_logo(out)
    qa_path = out / "RAPORT_QA_GENERATOR.json"
    if scope != "split":
        qa, paths = _generate_one(_scoped_data(data, scope, broker_on), out, logo_path, basename, "EMAIL_REZUMAT_M1-C01.docx", input_path, offer_format=fmt)
        qa["offer_format"] = fmt
        qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding="utf-8")
        return {**paths, "qa": str(qa_path), "status": qa["status"], "offer_for": scope, "include_broker": broker_on, "offer_format": fmt,
                "documents": [{"party": scope, "suffix": OFFER_PARTY_SUFFIX.get(scope), **paths}]}
    documents = []
    sub_qa: Dict[str, Any] = {}
    for party in ("buyer", "seller"):
        suffix = OFFER_PARTY_SUFFIX[party]
        qa_p, paths = _generate_one(_scoped_data(data, party, broker_on), out, logo_path, f"{basename}_{suffix}",
                                    f"EMAIL_REZUMAT_M1-C01_{suffix}.docx", input_path, offer_format=fmt)
        sub_qa[party] = qa_p
        documents.append({"party": party, "suffix": suffix, **paths})
    status = "PASS" if all(q.get("status") == "PASS" for q in sub_qa.values()) else "FAIL"
    qa = {"status": status, "offer_for": "split", "offer_format": fmt, "include_broker": broker_on, "per_party": sub_qa,
          "checks": {f"{party}_qa_pass": q.get("status") == "PASS" for party, q in sub_qa.items()},
          "source": str(input_path), "core_modified": False, "automatic_send": False, "automatic_propagation": False,
          "human_approval_required": True}
    qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding="utf-8")
    primary = documents[0]
    return {"docx": primary["docx"], "pdf": primary["pdf"], "email_docx": primary["email_docx"], "qa": str(qa_path),
            "status": status, "offer_for": "split", "offer_format": fmt, "include_broker": broker_on, "documents": documents}


def main() -> None:
    parser = argparse.ArgumentParser(description="Generator canonic SPN STOICA M1-C01 V3.13")
    parser.add_argument("engine_result", help="Path to ENGINE_RESULT.json")
    parser.add_argument("--output-dir", default="/mnt/data")
    parser.add_argument("--basename", default="OFERTA_M1-C01_CANONICA")
    parser.add_argument("--offer-for", default=None, choices=list(OFFER_SCOPES))
    parser.add_argument("--no-broker", action="store_true")
    parser.add_argument("--offer-format", default=None, choices=["scurt", "complet"])  # am.367
    args = parser.parse_args()
    result = generate(args.engine_result, args.output_dir, args.basename, offer_for=args.offer_for, include_broker=not args.no_broker, offer_format=args.offer_format)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
